(function(){const a=document.createElement("link").relList;if(a&&a.supports&&a.supports("modulepreload"))return;for(const c of document.querySelectorAll('link[rel="modulepreload"]'))l(c);new MutationObserver(c=>{for(const f of c)if(f.type==="childList")for(const d of f.addedNodes)d.tagName==="LINK"&&d.rel==="modulepreload"&&l(d)}).observe(document,{childList:!0,subtree:!0});function o(c){const f={};return c.integrity&&(f.integrity=c.integrity),c.referrerPolicy&&(f.referrerPolicy=c.referrerPolicy),c.crossOrigin==="use-credentials"?f.credentials="include":c.crossOrigin==="anonymous"?f.credentials="omit":f.credentials="same-origin",f}function l(c){if(c.ep)return;c.ep=!0;const f=o(c);fetch(c.href,f)}})();function n1(n){return n&&n.__esModule&&Object.prototype.hasOwnProperty.call(n,"default")?n.default:n}var $u={exports:{}},Kr={};/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var ng;function J2(){if(ng)return Kr;ng=1;var n=Symbol.for("react.transitional.element"),a=Symbol.for("react.fragment");function o(l,c,f){var d=null;if(f!==void 0&&(d=""+f),c.key!==void 0&&(d=""+c.key),"key"in c){f={};for(var g in c)g!=="key"&&(f[g]=c[g])}else f=c;return c=f.ref,{$$typeof:n,type:l,key:d,ref:c!==void 0?c:null,props:f}}return Kr.Fragment=a,Kr.jsx=o,Kr.jsxs=o,Kr}var ig;function W2(){return ig||(ig=1,$u.exports=J2()),$u.exports}var h=W2(),Qu={exports:{}},ct={};/**
 * @license React
 * react.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var ag;function t3(){if(ag)return ct;ag=1;var n=Symbol.for("react.transitional.element"),a=Symbol.for("react.portal"),o=Symbol.for("react.fragment"),l=Symbol.for("react.strict_mode"),c=Symbol.for("react.profiler"),f=Symbol.for("react.consumer"),d=Symbol.for("react.context"),g=Symbol.for("react.forward_ref"),p=Symbol.for("react.suspense"),m=Symbol.for("react.memo"),x=Symbol.for("react.lazy"),A=Symbol.iterator;function b(T){return T===null||typeof T!="object"?null:(T=A&&T[A]||T["@@iterator"],typeof T=="function"?T:null)}var C={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},O=Object.assign,z={};function P(T,q,$){this.props=T,this.context=q,this.refs=z,this.updater=$||C}P.prototype.isReactComponent={},P.prototype.setState=function(T,q){if(typeof T!="object"&&typeof T!="function"&&T!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,T,q,"setState")},P.prototype.forceUpdate=function(T){this.updater.enqueueForceUpdate(this,T,"forceUpdate")};function R(){}R.prototype=P.prototype;function H(T,q,$){this.props=T,this.context=q,this.refs=z,this.updater=$||C}var V=H.prototype=new R;V.constructor=H,O(V,P.prototype),V.isPureReactComponent=!0;var X=Array.isArray,G={H:null,A:null,T:null,S:null,V:null},K=Object.prototype.hasOwnProperty;function F(T,q,$,Q,et,ht){return $=ht.ref,{$$typeof:n,type:T,key:q,ref:$!==void 0?$:null,props:ht}}function Z(T,q){return F(T.type,q,void 0,void 0,void 0,T.props)}function lt(T){return typeof T=="object"&&T!==null&&T.$$typeof===n}function vt(T){var q={"=":"=0",":":"=2"};return"$"+T.replace(/[=:]/g,function($){return q[$]})}var Bt=/\/+/g;function _t(T,q){return typeof T=="object"&&T!==null&&T.key!=null?vt(""+T.key):q.toString(36)}function Xe(){}function Le(T){switch(T.status){case"fulfilled":return T.value;case"rejected":throw T.reason;default:switch(typeof T.status=="string"?T.then(Xe,Xe):(T.status="pending",T.then(function(q){T.status==="pending"&&(T.status="fulfilled",T.value=q)},function(q){T.status==="pending"&&(T.status="rejected",T.reason=q)})),T.status){case"fulfilled":return T.value;case"rejected":throw T.reason}}throw T}function Kt(T,q,$,Q,et){var ht=typeof T;(ht==="undefined"||ht==="boolean")&&(T=null);var it=!1;if(T===null)it=!0;else switch(ht){case"bigint":case"string":case"number":it=!0;break;case"object":switch(T.$$typeof){case n:case a:it=!0;break;case x:return it=T._init,Kt(it(T._payload),q,$,Q,et)}}if(it)return et=et(T),it=Q===""?"."+_t(T,0):Q,X(et)?($="",it!=null&&($=it.replace(Bt,"$&/")+"/"),Kt(et,q,$,"",function(ce){return ce})):et!=null&&(lt(et)&&(et=Z(et,$+(et.key==null||T&&T.key===et.key?"":(""+et.key).replace(Bt,"$&/")+"/")+it)),q.push(et)),1;it=0;var Zt=Q===""?".":Q+":";if(X(T))for(var St=0;St<T.length;St++)Q=T[St],ht=Zt+_t(Q,St),it+=Kt(Q,q,$,ht,et);else if(St=b(T),typeof St=="function")for(T=St.call(T),St=0;!(Q=T.next()).done;)Q=Q.value,ht=Zt+_t(Q,St++),it+=Kt(Q,q,$,ht,et);else if(ht==="object"){if(typeof T.then=="function")return Kt(Le(T),q,$,Q,et);throw q=String(T),Error("Objects are not valid as a React child (found: "+(q==="[object Object]"?"object with keys {"+Object.keys(T).join(", ")+"}":q)+"). If you meant to render a collection of children, use an array instead.")}return it}function U(T,q,$){if(T==null)return T;var Q=[],et=0;return Kt(T,Q,"","",function(ht){return q.call($,ht,et++)}),Q}function Y(T){if(T._status===-1){var q=T._result;q=q(),q.then(function($){(T._status===0||T._status===-1)&&(T._status=1,T._result=$)},function($){(T._status===0||T._status===-1)&&(T._status=2,T._result=$)}),T._status===-1&&(T._status=0,T._result=q)}if(T._status===1)return T._result.default;throw T._result}var W=typeof reportError=="function"?reportError:function(T){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var q=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof T=="object"&&T!==null&&typeof T.message=="string"?String(T.message):String(T),error:T});if(!window.dispatchEvent(q))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",T);return}console.error(T)};function st(){}return ct.Children={map:U,forEach:function(T,q,$){U(T,function(){q.apply(this,arguments)},$)},count:function(T){var q=0;return U(T,function(){q++}),q},toArray:function(T){return U(T,function(q){return q})||[]},only:function(T){if(!lt(T))throw Error("React.Children.only expected to receive a single React element child.");return T}},ct.Component=P,ct.Fragment=o,ct.Profiler=c,ct.PureComponent=H,ct.StrictMode=l,ct.Suspense=p,ct.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=G,ct.__COMPILER_RUNTIME={__proto__:null,c:function(T){return G.H.useMemoCache(T)}},ct.cache=function(T){return function(){return T.apply(null,arguments)}},ct.cloneElement=function(T,q,$){if(T==null)throw Error("The argument must be a React element, but you passed "+T+".");var Q=O({},T.props),et=T.key,ht=void 0;if(q!=null)for(it in q.ref!==void 0&&(ht=void 0),q.key!==void 0&&(et=""+q.key),q)!K.call(q,it)||it==="key"||it==="__self"||it==="__source"||it==="ref"&&q.ref===void 0||(Q[it]=q[it]);var it=arguments.length-2;if(it===1)Q.children=$;else if(1<it){for(var Zt=Array(it),St=0;St<it;St++)Zt[St]=arguments[St+2];Q.children=Zt}return F(T.type,et,void 0,void 0,ht,Q)},ct.createContext=function(T){return T={$$typeof:d,_currentValue:T,_currentValue2:T,_threadCount:0,Provider:null,Consumer:null},T.Provider=T,T.Consumer={$$typeof:f,_context:T},T},ct.createElement=function(T,q,$){var Q,et={},ht=null;if(q!=null)for(Q in q.key!==void 0&&(ht=""+q.key),q)K.call(q,Q)&&Q!=="key"&&Q!=="__self"&&Q!=="__source"&&(et[Q]=q[Q]);var it=arguments.length-2;if(it===1)et.children=$;else if(1<it){for(var Zt=Array(it),St=0;St<it;St++)Zt[St]=arguments[St+2];et.children=Zt}if(T&&T.defaultProps)for(Q in it=T.defaultProps,it)et[Q]===void 0&&(et[Q]=it[Q]);return F(T,ht,void 0,void 0,null,et)},ct.createRef=function(){return{current:null}},ct.forwardRef=function(T){return{$$typeof:g,render:T}},ct.isValidElement=lt,ct.lazy=function(T){return{$$typeof:x,_payload:{_status:-1,_result:T},_init:Y}},ct.memo=function(T,q){return{$$typeof:m,type:T,compare:q===void 0?null:q}},ct.startTransition=function(T){var q=G.T,$={};G.T=$;try{var Q=T(),et=G.S;et!==null&&et($,Q),typeof Q=="object"&&Q!==null&&typeof Q.then=="function"&&Q.then(st,W)}catch(ht){W(ht)}finally{G.T=q}},ct.unstable_useCacheRefresh=function(){return G.H.useCacheRefresh()},ct.use=function(T){return G.H.use(T)},ct.useActionState=function(T,q,$){return G.H.useActionState(T,q,$)},ct.useCallback=function(T,q){return G.H.useCallback(T,q)},ct.useContext=function(T){return G.H.useContext(T)},ct.useDebugValue=function(){},ct.useDeferredValue=function(T,q){return G.H.useDeferredValue(T,q)},ct.useEffect=function(T,q,$){var Q=G.H;if(typeof $=="function")throw Error("useEffect CRUD overload is not enabled in this build of React.");return Q.useEffect(T,q)},ct.useId=function(){return G.H.useId()},ct.useImperativeHandle=function(T,q,$){return G.H.useImperativeHandle(T,q,$)},ct.useInsertionEffect=function(T,q){return G.H.useInsertionEffect(T,q)},ct.useLayoutEffect=function(T,q){return G.H.useLayoutEffect(T,q)},ct.useMemo=function(T,q){return G.H.useMemo(T,q)},ct.useOptimistic=function(T,q){return G.H.useOptimistic(T,q)},ct.useReducer=function(T,q,$){return G.H.useReducer(T,q,$)},ct.useRef=function(T){return G.H.useRef(T)},ct.useState=function(T){return G.H.useState(T)},ct.useSyncExternalStore=function(T,q,$){return G.H.useSyncExternalStore(T,q,$)},ct.useTransition=function(){return G.H.useTransition()},ct.version="19.1.0",ct}var rg;function pd(){return rg||(rg=1,Qu.exports=t3()),Qu.exports}var E=pd();const ie=n1(E);var Zu={exports:{}},$r={},Ju={exports:{}},Wu={};/**
 * @license React
 * scheduler.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var og;function e3(){return og||(og=1,function(n){function a(U,Y){var W=U.length;U.push(Y);t:for(;0<W;){var st=W-1>>>1,T=U[st];if(0<c(T,Y))U[st]=Y,U[W]=T,W=st;else break t}}function o(U){return U.length===0?null:U[0]}function l(U){if(U.length===0)return null;var Y=U[0],W=U.pop();if(W!==Y){U[0]=W;t:for(var st=0,T=U.length,q=T>>>1;st<q;){var $=2*(st+1)-1,Q=U[$],et=$+1,ht=U[et];if(0>c(Q,W))et<T&&0>c(ht,Q)?(U[st]=ht,U[et]=W,st=et):(U[st]=Q,U[$]=W,st=$);else if(et<T&&0>c(ht,W))U[st]=ht,U[et]=W,st=et;else break t}}return Y}function c(U,Y){var W=U.sortIndex-Y.sortIndex;return W!==0?W:U.id-Y.id}if(n.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var f=performance;n.unstable_now=function(){return f.now()}}else{var d=Date,g=d.now();n.unstable_now=function(){return d.now()-g}}var p=[],m=[],x=1,A=null,b=3,C=!1,O=!1,z=!1,P=!1,R=typeof setTimeout=="function"?setTimeout:null,H=typeof clearTimeout=="function"?clearTimeout:null,V=typeof setImmediate<"u"?setImmediate:null;function X(U){for(var Y=o(m);Y!==null;){if(Y.callback===null)l(m);else if(Y.startTime<=U)l(m),Y.sortIndex=Y.expirationTime,a(p,Y);else break;Y=o(m)}}function G(U){if(z=!1,X(U),!O)if(o(p)!==null)O=!0,K||(K=!0,_t());else{var Y=o(m);Y!==null&&Kt(G,Y.startTime-U)}}var K=!1,F=-1,Z=5,lt=-1;function vt(){return P?!0:!(n.unstable_now()-lt<Z)}function Bt(){if(P=!1,K){var U=n.unstable_now();lt=U;var Y=!0;try{t:{O=!1,z&&(z=!1,H(F),F=-1),C=!0;var W=b;try{e:{for(X(U),A=o(p);A!==null&&!(A.expirationTime>U&&vt());){var st=A.callback;if(typeof st=="function"){A.callback=null,b=A.priorityLevel;var T=st(A.expirationTime<=U);if(U=n.unstable_now(),typeof T=="function"){A.callback=T,X(U),Y=!0;break e}A===o(p)&&l(p),X(U)}else l(p);A=o(p)}if(A!==null)Y=!0;else{var q=o(m);q!==null&&Kt(G,q.startTime-U),Y=!1}}break t}finally{A=null,b=W,C=!1}Y=void 0}}finally{Y?_t():K=!1}}}var _t;if(typeof V=="function")_t=function(){V(Bt)};else if(typeof MessageChannel<"u"){var Xe=new MessageChannel,Le=Xe.port2;Xe.port1.onmessage=Bt,_t=function(){Le.postMessage(null)}}else _t=function(){R(Bt,0)};function Kt(U,Y){F=R(function(){U(n.unstable_now())},Y)}n.unstable_IdlePriority=5,n.unstable_ImmediatePriority=1,n.unstable_LowPriority=4,n.unstable_NormalPriority=3,n.unstable_Profiling=null,n.unstable_UserBlockingPriority=2,n.unstable_cancelCallback=function(U){U.callback=null},n.unstable_forceFrameRate=function(U){0>U||125<U?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):Z=0<U?Math.floor(1e3/U):5},n.unstable_getCurrentPriorityLevel=function(){return b},n.unstable_next=function(U){switch(b){case 1:case 2:case 3:var Y=3;break;default:Y=b}var W=b;b=Y;try{return U()}finally{b=W}},n.unstable_requestPaint=function(){P=!0},n.unstable_runWithPriority=function(U,Y){switch(U){case 1:case 2:case 3:case 4:case 5:break;default:U=3}var W=b;b=U;try{return Y()}finally{b=W}},n.unstable_scheduleCallback=function(U,Y,W){var st=n.unstable_now();switch(typeof W=="object"&&W!==null?(W=W.delay,W=typeof W=="number"&&0<W?st+W:st):W=st,U){case 1:var T=-1;break;case 2:T=250;break;case 5:T=1073741823;break;case 4:T=1e4;break;default:T=5e3}return T=W+T,U={id:x++,callback:Y,priorityLevel:U,startTime:W,expirationTime:T,sortIndex:-1},W>st?(U.sortIndex=W,a(m,U),o(p)===null&&U===o(m)&&(z?(H(F),F=-1):z=!0,Kt(G,W-st))):(U.sortIndex=T,a(p,U),O||C||(O=!0,K||(K=!0,_t()))),U},n.unstable_shouldYield=vt,n.unstable_wrapCallback=function(U){var Y=b;return function(){var W=b;b=Y;try{return U.apply(this,arguments)}finally{b=W}}}}(Wu)),Wu}var lg;function n3(){return lg||(lg=1,Ju.exports=e3()),Ju.exports}var tf={exports:{}},de={};/**
 * @license React
 * react-dom.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var sg;function i3(){if(sg)return de;sg=1;var n=pd();function a(p){var m="https://react.dev/errors/"+p;if(1<arguments.length){m+="?args[]="+encodeURIComponent(arguments[1]);for(var x=2;x<arguments.length;x++)m+="&args[]="+encodeURIComponent(arguments[x])}return"Minified React error #"+p+"; visit "+m+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function o(){}var l={d:{f:o,r:function(){throw Error(a(522))},D:o,C:o,L:o,m:o,X:o,S:o,M:o},p:0,findDOMNode:null},c=Symbol.for("react.portal");function f(p,m,x){var A=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:c,key:A==null?null:""+A,children:p,containerInfo:m,implementation:x}}var d=n.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function g(p,m){if(p==="font")return"";if(typeof m=="string")return m==="use-credentials"?m:""}return de.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=l,de.createPortal=function(p,m){var x=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!m||m.nodeType!==1&&m.nodeType!==9&&m.nodeType!==11)throw Error(a(299));return f(p,m,null,x)},de.flushSync=function(p){var m=d.T,x=l.p;try{if(d.T=null,l.p=2,p)return p()}finally{d.T=m,l.p=x,l.d.f()}},de.preconnect=function(p,m){typeof p=="string"&&(m?(m=m.crossOrigin,m=typeof m=="string"?m==="use-credentials"?m:"":void 0):m=null,l.d.C(p,m))},de.prefetchDNS=function(p){typeof p=="string"&&l.d.D(p)},de.preinit=function(p,m){if(typeof p=="string"&&m&&typeof m.as=="string"){var x=m.as,A=g(x,m.crossOrigin),b=typeof m.integrity=="string"?m.integrity:void 0,C=typeof m.fetchPriority=="string"?m.fetchPriority:void 0;x==="style"?l.d.S(p,typeof m.precedence=="string"?m.precedence:void 0,{crossOrigin:A,integrity:b,fetchPriority:C}):x==="script"&&l.d.X(p,{crossOrigin:A,integrity:b,fetchPriority:C,nonce:typeof m.nonce=="string"?m.nonce:void 0})}},de.preinitModule=function(p,m){if(typeof p=="string")if(typeof m=="object"&&m!==null){if(m.as==null||m.as==="script"){var x=g(m.as,m.crossOrigin);l.d.M(p,{crossOrigin:x,integrity:typeof m.integrity=="string"?m.integrity:void 0,nonce:typeof m.nonce=="string"?m.nonce:void 0})}}else m==null&&l.d.M(p)},de.preload=function(p,m){if(typeof p=="string"&&typeof m=="object"&&m!==null&&typeof m.as=="string"){var x=m.as,A=g(x,m.crossOrigin);l.d.L(p,x,{crossOrigin:A,integrity:typeof m.integrity=="string"?m.integrity:void 0,nonce:typeof m.nonce=="string"?m.nonce:void 0,type:typeof m.type=="string"?m.type:void 0,fetchPriority:typeof m.fetchPriority=="string"?m.fetchPriority:void 0,referrerPolicy:typeof m.referrerPolicy=="string"?m.referrerPolicy:void 0,imageSrcSet:typeof m.imageSrcSet=="string"?m.imageSrcSet:void 0,imageSizes:typeof m.imageSizes=="string"?m.imageSizes:void 0,media:typeof m.media=="string"?m.media:void 0})}},de.preloadModule=function(p,m){if(typeof p=="string")if(m){var x=g(m.as,m.crossOrigin);l.d.m(p,{as:typeof m.as=="string"&&m.as!=="script"?m.as:void 0,crossOrigin:x,integrity:typeof m.integrity=="string"?m.integrity:void 0})}else l.d.m(p)},de.requestFormReset=function(p){l.d.r(p)},de.unstable_batchedUpdates=function(p,m){return p(m)},de.useFormState=function(p,m,x){return d.H.useFormState(p,m,x)},de.useFormStatus=function(){return d.H.useHostTransitionStatus()},de.version="19.1.0",de}var cg;function a3(){if(cg)return tf.exports;cg=1;function n(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)}catch(a){console.error(a)}}return n(),tf.exports=i3(),tf.exports}/**
 * @license React
 * react-dom-client.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var ug;function r3(){if(ug)return $r;ug=1;var n=n3(),a=pd(),o=a3();function l(t){var e="https://react.dev/errors/"+t;if(1<arguments.length){e+="?args[]="+encodeURIComponent(arguments[1]);for(var i=2;i<arguments.length;i++)e+="&args[]="+encodeURIComponent(arguments[i])}return"Minified React error #"+t+"; visit "+e+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function c(t){return!(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)}function f(t){var e=t,i=t;if(t.alternate)for(;e.return;)e=e.return;else{t=e;do e=t,(e.flags&4098)!==0&&(i=e.return),t=e.return;while(t)}return e.tag===3?i:null}function d(t){if(t.tag===13){var e=t.memoizedState;if(e===null&&(t=t.alternate,t!==null&&(e=t.memoizedState)),e!==null)return e.dehydrated}return null}function g(t){if(f(t)!==t)throw Error(l(188))}function p(t){var e=t.alternate;if(!e){if(e=f(t),e===null)throw Error(l(188));return e!==t?null:t}for(var i=t,r=e;;){var s=i.return;if(s===null)break;var u=s.alternate;if(u===null){if(r=s.return,r!==null){i=r;continue}break}if(s.child===u.child){for(u=s.child;u;){if(u===i)return g(s),t;if(u===r)return g(s),e;u=u.sibling}throw Error(l(188))}if(i.return!==r.return)i=s,r=u;else{for(var y=!1,v=s.child;v;){if(v===i){y=!0,i=s,r=u;break}if(v===r){y=!0,r=s,i=u;break}v=v.sibling}if(!y){for(v=u.child;v;){if(v===i){y=!0,i=u,r=s;break}if(v===r){y=!0,r=u,i=s;break}v=v.sibling}if(!y)throw Error(l(189))}}if(i.alternate!==r)throw Error(l(190))}if(i.tag!==3)throw Error(l(188));return i.stateNode.current===i?t:e}function m(t){var e=t.tag;if(e===5||e===26||e===27||e===6)return t;for(t=t.child;t!==null;){if(e=m(t),e!==null)return e;t=t.sibling}return null}var x=Object.assign,A=Symbol.for("react.element"),b=Symbol.for("react.transitional.element"),C=Symbol.for("react.portal"),O=Symbol.for("react.fragment"),z=Symbol.for("react.strict_mode"),P=Symbol.for("react.profiler"),R=Symbol.for("react.provider"),H=Symbol.for("react.consumer"),V=Symbol.for("react.context"),X=Symbol.for("react.forward_ref"),G=Symbol.for("react.suspense"),K=Symbol.for("react.suspense_list"),F=Symbol.for("react.memo"),Z=Symbol.for("react.lazy"),lt=Symbol.for("react.activity"),vt=Symbol.for("react.memo_cache_sentinel"),Bt=Symbol.iterator;function _t(t){return t===null||typeof t!="object"?null:(t=Bt&&t[Bt]||t["@@iterator"],typeof t=="function"?t:null)}var Xe=Symbol.for("react.client.reference");function Le(t){if(t==null)return null;if(typeof t=="function")return t.$$typeof===Xe?null:t.displayName||t.name||null;if(typeof t=="string")return t;switch(t){case O:return"Fragment";case P:return"Profiler";case z:return"StrictMode";case G:return"Suspense";case K:return"SuspenseList";case lt:return"Activity"}if(typeof t=="object")switch(t.$$typeof){case C:return"Portal";case V:return(t.displayName||"Context")+".Provider";case H:return(t._context.displayName||"Context")+".Consumer";case X:var e=t.render;return t=t.displayName,t||(t=e.displayName||e.name||"",t=t!==""?"ForwardRef("+t+")":"ForwardRef"),t;case F:return e=t.displayName||null,e!==null?e:Le(t.type)||"Memo";case Z:e=t._payload,t=t._init;try{return Le(t(e))}catch{}}return null}var Kt=Array.isArray,U=a.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,Y=o.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,W={pending:!1,data:null,method:null,action:null},st=[],T=-1;function q(t){return{current:t}}function $(t){0>T||(t.current=st[T],st[T]=null,T--)}function Q(t,e){T++,st[T]=t.current,t.current=e}var et=q(null),ht=q(null),it=q(null),Zt=q(null);function St(t,e){switch(Q(it,e),Q(ht,t),Q(et,null),e.nodeType){case 9:case 11:t=(t=e.documentElement)&&(t=t.namespaceURI)?Dp(t):0;break;default:if(t=e.tagName,e=e.namespaceURI)e=Dp(e),t=Rp(e,t);else switch(t){case"svg":t=1;break;case"math":t=2;break;default:t=0}}$(et),Q(et,t)}function ce(){$(et),$(ht),$(it)}function di(t){t.memoizedState!==null&&Q(Zt,t);var e=et.current,i=Rp(e,t.type);e!==i&&(Q(ht,t),Q(et,i))}function mn(t){ht.current===t&&($(et),$(ht)),Zt.current===t&&($(Zt),Ir._currentValue=W)}var Be=Object.prototype.hasOwnProperty,Ps=n.unstable_scheduleCallback,Vs=n.unstable_cancelCallback,Dv=n.unstable_shouldYield,Rv=n.unstable_requestPaint,tn=n.unstable_now,Lv=n.unstable_getCurrentPriorityLevel,uh=n.unstable_ImmediatePriority,fh=n.unstable_UserBlockingPriority,Mo=n.unstable_NormalPriority,Bv=n.unstable_LowPriority,dh=n.unstable_IdlePriority,zv=n.log,kv=n.unstable_setDisableYieldValue,Za=null,Ae=null;function kn(t){if(typeof zv=="function"&&kv(t),Ae&&typeof Ae.setStrictMode=="function")try{Ae.setStrictMode(Za,t)}catch{}}var we=Math.clz32?Math.clz32:Uv,Pv=Math.log,Vv=Math.LN2;function Uv(t){return t>>>=0,t===0?32:31-(Pv(t)/Vv|0)|0}var jo=256,Oo=4194304;function hi(t){var e=t&42;if(e!==0)return e;switch(t&-t){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t&4194048;case 4194304:case 8388608:case 16777216:case 33554432:return t&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return t}}function Do(t,e,i){var r=t.pendingLanes;if(r===0)return 0;var s=0,u=t.suspendedLanes,y=t.pingedLanes;t=t.warmLanes;var v=r&134217727;return v!==0?(r=v&~u,r!==0?s=hi(r):(y&=v,y!==0?s=hi(y):i||(i=v&~t,i!==0&&(s=hi(i))))):(v=r&~u,v!==0?s=hi(v):y!==0?s=hi(y):i||(i=r&~t,i!==0&&(s=hi(i)))),s===0?0:e!==0&&e!==s&&(e&u)===0&&(u=s&-s,i=e&-e,u>=i||u===32&&(i&4194048)!==0)?e:s}function Ja(t,e){return(t.pendingLanes&~(t.suspendedLanes&~t.pingedLanes)&e)===0}function Nv(t,e){switch(t){case 1:case 2:case 4:case 8:case 64:return e+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return e+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function hh(){var t=jo;return jo<<=1,(jo&4194048)===0&&(jo=256),t}function mh(){var t=Oo;return Oo<<=1,(Oo&62914560)===0&&(Oo=4194304),t}function Us(t){for(var e=[],i=0;31>i;i++)e.push(t);return e}function Wa(t,e){t.pendingLanes|=e,e!==268435456&&(t.suspendedLanes=0,t.pingedLanes=0,t.warmLanes=0)}function _v(t,e,i,r,s,u){var y=t.pendingLanes;t.pendingLanes=i,t.suspendedLanes=0,t.pingedLanes=0,t.warmLanes=0,t.expiredLanes&=i,t.entangledLanes&=i,t.errorRecoveryDisabledLanes&=i,t.shellSuspendCounter=0;var v=t.entanglements,w=t.expirationTimes,L=t.hiddenUpdates;for(i=y&~i;0<i;){var N=31-we(i),I=1<<N;v[N]=0,w[N]=-1;var B=L[N];if(B!==null)for(L[N]=null,N=0;N<B.length;N++){var k=B[N];k!==null&&(k.lane&=-536870913)}i&=~I}r!==0&&ph(t,r,0),u!==0&&s===0&&t.tag!==0&&(t.suspendedLanes|=u&~(y&~e))}function ph(t,e,i){t.pendingLanes|=e,t.suspendedLanes&=~e;var r=31-we(e);t.entangledLanes|=e,t.entanglements[r]=t.entanglements[r]|1073741824|i&4194090}function gh(t,e){var i=t.entangledLanes|=e;for(t=t.entanglements;i;){var r=31-we(i),s=1<<r;s&e|t[r]&e&&(t[r]|=e),i&=~s}}function Ns(t){switch(t){case 2:t=1;break;case 8:t=4;break;case 32:t=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:t=128;break;case 268435456:t=134217728;break;default:t=0}return t}function _s(t){return t&=-t,2<t?8<t?(t&134217727)!==0?32:268435456:8:2}function yh(){var t=Y.p;return t!==0?t:(t=window.event,t===void 0?32:Qp(t.type))}function Hv(t,e){var i=Y.p;try{return Y.p=t,e()}finally{Y.p=i}}var Pn=Math.random().toString(36).slice(2),ue="__reactFiber$"+Pn,ge="__reactProps$"+Pn,Gi="__reactContainer$"+Pn,Hs="__reactEvents$"+Pn,Gv="__reactListeners$"+Pn,Iv="__reactHandles$"+Pn,xh="__reactResources$"+Pn,tr="__reactMarker$"+Pn;function Gs(t){delete t[ue],delete t[ge],delete t[Hs],delete t[Gv],delete t[Iv]}function Ii(t){var e=t[ue];if(e)return e;for(var i=t.parentNode;i;){if(e=i[Gi]||i[ue]){if(i=e.alternate,e.child!==null||i!==null&&i.child!==null)for(t=kp(t);t!==null;){if(i=t[ue])return i;t=kp(t)}return e}t=i,i=t.parentNode}return null}function qi(t){if(t=t[ue]||t[Gi]){var e=t.tag;if(e===5||e===6||e===13||e===26||e===27||e===3)return t}return null}function er(t){var e=t.tag;if(e===5||e===26||e===27||e===6)return t.stateNode;throw Error(l(33))}function Fi(t){var e=t[xh];return e||(e=t[xh]={hoistableStyles:new Map,hoistableScripts:new Map}),e}function Jt(t){t[tr]=!0}var vh=new Set,bh={};function mi(t,e){Yi(t,e),Yi(t+"Capture",e)}function Yi(t,e){for(bh[t]=e,t=0;t<e.length;t++)vh.add(e[t])}var qv=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),Sh={},Ah={};function Fv(t){return Be.call(Ah,t)?!0:Be.call(Sh,t)?!1:qv.test(t)?Ah[t]=!0:(Sh[t]=!0,!1)}function Ro(t,e,i){if(Fv(e))if(i===null)t.removeAttribute(e);else{switch(typeof i){case"undefined":case"function":case"symbol":t.removeAttribute(e);return;case"boolean":var r=e.toLowerCase().slice(0,5);if(r!=="data-"&&r!=="aria-"){t.removeAttribute(e);return}}t.setAttribute(e,""+i)}}function Lo(t,e,i){if(i===null)t.removeAttribute(e);else{switch(typeof i){case"undefined":case"function":case"symbol":case"boolean":t.removeAttribute(e);return}t.setAttribute(e,""+i)}}function pn(t,e,i,r){if(r===null)t.removeAttribute(i);else{switch(typeof r){case"undefined":case"function":case"symbol":case"boolean":t.removeAttribute(i);return}t.setAttributeNS(e,i,""+r)}}var Is,wh;function Xi(t){if(Is===void 0)try{throw Error()}catch(i){var e=i.stack.trim().match(/\n( *(at )?)/);Is=e&&e[1]||"",wh=-1<i.stack.indexOf(`
    at`)?" (<anonymous>)":-1<i.stack.indexOf("@")?"@unknown:0:0":""}return`
`+Is+t+wh}var qs=!1;function Fs(t,e){if(!t||qs)return"";qs=!0;var i=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var r={DetermineComponentFrameRoot:function(){try{if(e){var I=function(){throw Error()};if(Object.defineProperty(I.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(I,[])}catch(k){var B=k}Reflect.construct(t,[],I)}else{try{I.call()}catch(k){B=k}t.call(I.prototype)}}else{try{throw Error()}catch(k){B=k}(I=t())&&typeof I.catch=="function"&&I.catch(function(){})}}catch(k){if(k&&B&&typeof k.stack=="string")return[k.stack,B.stack]}return[null,null]}};r.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var s=Object.getOwnPropertyDescriptor(r.DetermineComponentFrameRoot,"name");s&&s.configurable&&Object.defineProperty(r.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var u=r.DetermineComponentFrameRoot(),y=u[0],v=u[1];if(y&&v){var w=y.split(`
`),L=v.split(`
`);for(s=r=0;r<w.length&&!w[r].includes("DetermineComponentFrameRoot");)r++;for(;s<L.length&&!L[s].includes("DetermineComponentFrameRoot");)s++;if(r===w.length||s===L.length)for(r=w.length-1,s=L.length-1;1<=r&&0<=s&&w[r]!==L[s];)s--;for(;1<=r&&0<=s;r--,s--)if(w[r]!==L[s]){if(r!==1||s!==1)do if(r--,s--,0>s||w[r]!==L[s]){var N=`
`+w[r].replace(" at new "," at ");return t.displayName&&N.includes("<anonymous>")&&(N=N.replace("<anonymous>",t.displayName)),N}while(1<=r&&0<=s);break}}}finally{qs=!1,Error.prepareStackTrace=i}return(i=t?t.displayName||t.name:"")?Xi(i):""}function Yv(t){switch(t.tag){case 26:case 27:case 5:return Xi(t.type);case 16:return Xi("Lazy");case 13:return Xi("Suspense");case 19:return Xi("SuspenseList");case 0:case 15:return Fs(t.type,!1);case 11:return Fs(t.type.render,!1);case 1:return Fs(t.type,!0);case 31:return Xi("Activity");default:return""}}function Ch(t){try{var e="";do e+=Yv(t),t=t.return;while(t);return e}catch(i){return`
Error generating stack: `+i.message+`
`+i.stack}}function ze(t){switch(typeof t){case"bigint":case"boolean":case"number":case"string":case"undefined":return t;case"object":return t;default:return""}}function Th(t){var e=t.type;return(t=t.nodeName)&&t.toLowerCase()==="input"&&(e==="checkbox"||e==="radio")}function Xv(t){var e=Th(t)?"checked":"value",i=Object.getOwnPropertyDescriptor(t.constructor.prototype,e),r=""+t[e];if(!t.hasOwnProperty(e)&&typeof i<"u"&&typeof i.get=="function"&&typeof i.set=="function"){var s=i.get,u=i.set;return Object.defineProperty(t,e,{configurable:!0,get:function(){return s.call(this)},set:function(y){r=""+y,u.call(this,y)}}),Object.defineProperty(t,e,{enumerable:i.enumerable}),{getValue:function(){return r},setValue:function(y){r=""+y},stopTracking:function(){t._valueTracker=null,delete t[e]}}}}function Bo(t){t._valueTracker||(t._valueTracker=Xv(t))}function Eh(t){if(!t)return!1;var e=t._valueTracker;if(!e)return!0;var i=e.getValue(),r="";return t&&(r=Th(t)?t.checked?"true":"false":t.value),t=r,t!==i?(e.setValue(t),!0):!1}function zo(t){if(t=t||(typeof document<"u"?document:void 0),typeof t>"u")return null;try{return t.activeElement||t.body}catch{return t.body}}var Kv=/[\n"\\]/g;function ke(t){return t.replace(Kv,function(e){return"\\"+e.charCodeAt(0).toString(16)+" "})}function Ys(t,e,i,r,s,u,y,v){t.name="",y!=null&&typeof y!="function"&&typeof y!="symbol"&&typeof y!="boolean"?t.type=y:t.removeAttribute("type"),e!=null?y==="number"?(e===0&&t.value===""||t.value!=e)&&(t.value=""+ze(e)):t.value!==""+ze(e)&&(t.value=""+ze(e)):y!=="submit"&&y!=="reset"||t.removeAttribute("value"),e!=null?Xs(t,y,ze(e)):i!=null?Xs(t,y,ze(i)):r!=null&&t.removeAttribute("value"),s==null&&u!=null&&(t.defaultChecked=!!u),s!=null&&(t.checked=s&&typeof s!="function"&&typeof s!="symbol"),v!=null&&typeof v!="function"&&typeof v!="symbol"&&typeof v!="boolean"?t.name=""+ze(v):t.removeAttribute("name")}function Mh(t,e,i,r,s,u,y,v){if(u!=null&&typeof u!="function"&&typeof u!="symbol"&&typeof u!="boolean"&&(t.type=u),e!=null||i!=null){if(!(u!=="submit"&&u!=="reset"||e!=null))return;i=i!=null?""+ze(i):"",e=e!=null?""+ze(e):i,v||e===t.value||(t.value=e),t.defaultValue=e}r=r??s,r=typeof r!="function"&&typeof r!="symbol"&&!!r,t.checked=v?t.checked:!!r,t.defaultChecked=!!r,y!=null&&typeof y!="function"&&typeof y!="symbol"&&typeof y!="boolean"&&(t.name=y)}function Xs(t,e,i){e==="number"&&zo(t.ownerDocument)===t||t.defaultValue===""+i||(t.defaultValue=""+i)}function Ki(t,e,i,r){if(t=t.options,e){e={};for(var s=0;s<i.length;s++)e["$"+i[s]]=!0;for(i=0;i<t.length;i++)s=e.hasOwnProperty("$"+t[i].value),t[i].selected!==s&&(t[i].selected=s),s&&r&&(t[i].defaultSelected=!0)}else{for(i=""+ze(i),e=null,s=0;s<t.length;s++){if(t[s].value===i){t[s].selected=!0,r&&(t[s].defaultSelected=!0);return}e!==null||t[s].disabled||(e=t[s])}e!==null&&(e.selected=!0)}}function jh(t,e,i){if(e!=null&&(e=""+ze(e),e!==t.value&&(t.value=e),i==null)){t.defaultValue!==e&&(t.defaultValue=e);return}t.defaultValue=i!=null?""+ze(i):""}function Oh(t,e,i,r){if(e==null){if(r!=null){if(i!=null)throw Error(l(92));if(Kt(r)){if(1<r.length)throw Error(l(93));r=r[0]}i=r}i==null&&(i=""),e=i}i=ze(e),t.defaultValue=i,r=t.textContent,r===i&&r!==""&&r!==null&&(t.value=r)}function $i(t,e){if(e){var i=t.firstChild;if(i&&i===t.lastChild&&i.nodeType===3){i.nodeValue=e;return}}t.textContent=e}var $v=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function Dh(t,e,i){var r=e.indexOf("--")===0;i==null||typeof i=="boolean"||i===""?r?t.setProperty(e,""):e==="float"?t.cssFloat="":t[e]="":r?t.setProperty(e,i):typeof i!="number"||i===0||$v.has(e)?e==="float"?t.cssFloat=i:t[e]=(""+i).trim():t[e]=i+"px"}function Rh(t,e,i){if(e!=null&&typeof e!="object")throw Error(l(62));if(t=t.style,i!=null){for(var r in i)!i.hasOwnProperty(r)||e!=null&&e.hasOwnProperty(r)||(r.indexOf("--")===0?t.setProperty(r,""):r==="float"?t.cssFloat="":t[r]="");for(var s in e)r=e[s],e.hasOwnProperty(s)&&i[s]!==r&&Dh(t,s,r)}else for(var u in e)e.hasOwnProperty(u)&&Dh(t,u,e[u])}function Ks(t){if(t.indexOf("-")===-1)return!1;switch(t){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var Qv=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),Zv=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function ko(t){return Zv.test(""+t)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":t}var $s=null;function Qs(t){return t=t.target||t.srcElement||window,t.correspondingUseElement&&(t=t.correspondingUseElement),t.nodeType===3?t.parentNode:t}var Qi=null,Zi=null;function Lh(t){var e=qi(t);if(e&&(t=e.stateNode)){var i=t[ge]||null;t:switch(t=e.stateNode,e.type){case"input":if(Ys(t,i.value,i.defaultValue,i.defaultValue,i.checked,i.defaultChecked,i.type,i.name),e=i.name,i.type==="radio"&&e!=null){for(i=t;i.parentNode;)i=i.parentNode;for(i=i.querySelectorAll('input[name="'+ke(""+e)+'"][type="radio"]'),e=0;e<i.length;e++){var r=i[e];if(r!==t&&r.form===t.form){var s=r[ge]||null;if(!s)throw Error(l(90));Ys(r,s.value,s.defaultValue,s.defaultValue,s.checked,s.defaultChecked,s.type,s.name)}}for(e=0;e<i.length;e++)r=i[e],r.form===t.form&&Eh(r)}break t;case"textarea":jh(t,i.value,i.defaultValue);break t;case"select":e=i.value,e!=null&&Ki(t,!!i.multiple,e,!1)}}}var Zs=!1;function Bh(t,e,i){if(Zs)return t(e,i);Zs=!0;try{var r=t(e);return r}finally{if(Zs=!1,(Qi!==null||Zi!==null)&&(bl(),Qi&&(e=Qi,t=Zi,Zi=Qi=null,Lh(e),t)))for(e=0;e<t.length;e++)Lh(t[e])}}function nr(t,e){var i=t.stateNode;if(i===null)return null;var r=i[ge]||null;if(r===null)return null;i=r[e];t:switch(e){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(r=!r.disabled)||(t=t.type,r=!(t==="button"||t==="input"||t==="select"||t==="textarea")),t=!r;break t;default:t=!1}if(t)return null;if(i&&typeof i!="function")throw Error(l(231,e,typeof i));return i}var gn=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Js=!1;if(gn)try{var ir={};Object.defineProperty(ir,"passive",{get:function(){Js=!0}}),window.addEventListener("test",ir,ir),window.removeEventListener("test",ir,ir)}catch{Js=!1}var Vn=null,Ws=null,Po=null;function zh(){if(Po)return Po;var t,e=Ws,i=e.length,r,s="value"in Vn?Vn.value:Vn.textContent,u=s.length;for(t=0;t<i&&e[t]===s[t];t++);var y=i-t;for(r=1;r<=y&&e[i-r]===s[u-r];r++);return Po=s.slice(t,1<r?1-r:void 0)}function Vo(t){var e=t.keyCode;return"charCode"in t?(t=t.charCode,t===0&&e===13&&(t=13)):t=e,t===10&&(t=13),32<=t||t===13?t:0}function Uo(){return!0}function kh(){return!1}function ye(t){function e(i,r,s,u,y){this._reactName=i,this._targetInst=s,this.type=r,this.nativeEvent=u,this.target=y,this.currentTarget=null;for(var v in t)t.hasOwnProperty(v)&&(i=t[v],this[v]=i?i(u):u[v]);return this.isDefaultPrevented=(u.defaultPrevented!=null?u.defaultPrevented:u.returnValue===!1)?Uo:kh,this.isPropagationStopped=kh,this}return x(e.prototype,{preventDefault:function(){this.defaultPrevented=!0;var i=this.nativeEvent;i&&(i.preventDefault?i.preventDefault():typeof i.returnValue!="unknown"&&(i.returnValue=!1),this.isDefaultPrevented=Uo)},stopPropagation:function(){var i=this.nativeEvent;i&&(i.stopPropagation?i.stopPropagation():typeof i.cancelBubble!="unknown"&&(i.cancelBubble=!0),this.isPropagationStopped=Uo)},persist:function(){},isPersistent:Uo}),e}var pi={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(t){return t.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},No=ye(pi),ar=x({},pi,{view:0,detail:0}),Jv=ye(ar),tc,ec,rr,_o=x({},ar,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:ic,button:0,buttons:0,relatedTarget:function(t){return t.relatedTarget===void 0?t.fromElement===t.srcElement?t.toElement:t.fromElement:t.relatedTarget},movementX:function(t){return"movementX"in t?t.movementX:(t!==rr&&(rr&&t.type==="mousemove"?(tc=t.screenX-rr.screenX,ec=t.screenY-rr.screenY):ec=tc=0,rr=t),tc)},movementY:function(t){return"movementY"in t?t.movementY:ec}}),Ph=ye(_o),Wv=x({},_o,{dataTransfer:0}),tb=ye(Wv),eb=x({},ar,{relatedTarget:0}),nc=ye(eb),nb=x({},pi,{animationName:0,elapsedTime:0,pseudoElement:0}),ib=ye(nb),ab=x({},pi,{clipboardData:function(t){return"clipboardData"in t?t.clipboardData:window.clipboardData}}),rb=ye(ab),ob=x({},pi,{data:0}),Vh=ye(ob),lb={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},sb={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},cb={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function ub(t){var e=this.nativeEvent;return e.getModifierState?e.getModifierState(t):(t=cb[t])?!!e[t]:!1}function ic(){return ub}var fb=x({},ar,{key:function(t){if(t.key){var e=lb[t.key]||t.key;if(e!=="Unidentified")return e}return t.type==="keypress"?(t=Vo(t),t===13?"Enter":String.fromCharCode(t)):t.type==="keydown"||t.type==="keyup"?sb[t.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:ic,charCode:function(t){return t.type==="keypress"?Vo(t):0},keyCode:function(t){return t.type==="keydown"||t.type==="keyup"?t.keyCode:0},which:function(t){return t.type==="keypress"?Vo(t):t.type==="keydown"||t.type==="keyup"?t.keyCode:0}}),db=ye(fb),hb=x({},_o,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Uh=ye(hb),mb=x({},ar,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:ic}),pb=ye(mb),gb=x({},pi,{propertyName:0,elapsedTime:0,pseudoElement:0}),yb=ye(gb),xb=x({},_o,{deltaX:function(t){return"deltaX"in t?t.deltaX:"wheelDeltaX"in t?-t.wheelDeltaX:0},deltaY:function(t){return"deltaY"in t?t.deltaY:"wheelDeltaY"in t?-t.wheelDeltaY:"wheelDelta"in t?-t.wheelDelta:0},deltaZ:0,deltaMode:0}),vb=ye(xb),bb=x({},pi,{newState:0,oldState:0}),Sb=ye(bb),Ab=[9,13,27,32],ac=gn&&"CompositionEvent"in window,or=null;gn&&"documentMode"in document&&(or=document.documentMode);var wb=gn&&"TextEvent"in window&&!or,Nh=gn&&(!ac||or&&8<or&&11>=or),_h=" ",Hh=!1;function Gh(t,e){switch(t){case"keyup":return Ab.indexOf(e.keyCode)!==-1;case"keydown":return e.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Ih(t){return t=t.detail,typeof t=="object"&&"data"in t?t.data:null}var Ji=!1;function Cb(t,e){switch(t){case"compositionend":return Ih(e);case"keypress":return e.which!==32?null:(Hh=!0,_h);case"textInput":return t=e.data,t===_h&&Hh?null:t;default:return null}}function Tb(t,e){if(Ji)return t==="compositionend"||!ac&&Gh(t,e)?(t=zh(),Po=Ws=Vn=null,Ji=!1,t):null;switch(t){case"paste":return null;case"keypress":if(!(e.ctrlKey||e.altKey||e.metaKey)||e.ctrlKey&&e.altKey){if(e.char&&1<e.char.length)return e.char;if(e.which)return String.fromCharCode(e.which)}return null;case"compositionend":return Nh&&e.locale!=="ko"?null:e.data;default:return null}}var Eb={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function qh(t){var e=t&&t.nodeName&&t.nodeName.toLowerCase();return e==="input"?!!Eb[t.type]:e==="textarea"}function Fh(t,e,i,r){Qi?Zi?Zi.push(r):Zi=[r]:Qi=r,e=El(e,"onChange"),0<e.length&&(i=new No("onChange","change",null,i,r),t.push({event:i,listeners:e}))}var lr=null,sr=null;function Mb(t){Tp(t,0)}function Ho(t){var e=er(t);if(Eh(e))return t}function Yh(t,e){if(t==="change")return e}var Xh=!1;if(gn){var rc;if(gn){var oc="oninput"in document;if(!oc){var Kh=document.createElement("div");Kh.setAttribute("oninput","return;"),oc=typeof Kh.oninput=="function"}rc=oc}else rc=!1;Xh=rc&&(!document.documentMode||9<document.documentMode)}function $h(){lr&&(lr.detachEvent("onpropertychange",Qh),sr=lr=null)}function Qh(t){if(t.propertyName==="value"&&Ho(sr)){var e=[];Fh(e,sr,t,Qs(t)),Bh(Mb,e)}}function jb(t,e,i){t==="focusin"?($h(),lr=e,sr=i,lr.attachEvent("onpropertychange",Qh)):t==="focusout"&&$h()}function Ob(t){if(t==="selectionchange"||t==="keyup"||t==="keydown")return Ho(sr)}function Db(t,e){if(t==="click")return Ho(e)}function Rb(t,e){if(t==="input"||t==="change")return Ho(e)}function Lb(t,e){return t===e&&(t!==0||1/t===1/e)||t!==t&&e!==e}var Ce=typeof Object.is=="function"?Object.is:Lb;function cr(t,e){if(Ce(t,e))return!0;if(typeof t!="object"||t===null||typeof e!="object"||e===null)return!1;var i=Object.keys(t),r=Object.keys(e);if(i.length!==r.length)return!1;for(r=0;r<i.length;r++){var s=i[r];if(!Be.call(e,s)||!Ce(t[s],e[s]))return!1}return!0}function Zh(t){for(;t&&t.firstChild;)t=t.firstChild;return t}function Jh(t,e){var i=Zh(t);t=0;for(var r;i;){if(i.nodeType===3){if(r=t+i.textContent.length,t<=e&&r>=e)return{node:i,offset:e-t};t=r}t:{for(;i;){if(i.nextSibling){i=i.nextSibling;break t}i=i.parentNode}i=void 0}i=Zh(i)}}function Wh(t,e){return t&&e?t===e?!0:t&&t.nodeType===3?!1:e&&e.nodeType===3?Wh(t,e.parentNode):"contains"in t?t.contains(e):t.compareDocumentPosition?!!(t.compareDocumentPosition(e)&16):!1:!1}function t0(t){t=t!=null&&t.ownerDocument!=null&&t.ownerDocument.defaultView!=null?t.ownerDocument.defaultView:window;for(var e=zo(t.document);e instanceof t.HTMLIFrameElement;){try{var i=typeof e.contentWindow.location.href=="string"}catch{i=!1}if(i)t=e.contentWindow;else break;e=zo(t.document)}return e}function lc(t){var e=t&&t.nodeName&&t.nodeName.toLowerCase();return e&&(e==="input"&&(t.type==="text"||t.type==="search"||t.type==="tel"||t.type==="url"||t.type==="password")||e==="textarea"||t.contentEditable==="true")}var Bb=gn&&"documentMode"in document&&11>=document.documentMode,Wi=null,sc=null,ur=null,cc=!1;function e0(t,e,i){var r=i.window===i?i.document:i.nodeType===9?i:i.ownerDocument;cc||Wi==null||Wi!==zo(r)||(r=Wi,"selectionStart"in r&&lc(r)?r={start:r.selectionStart,end:r.selectionEnd}:(r=(r.ownerDocument&&r.ownerDocument.defaultView||window).getSelection(),r={anchorNode:r.anchorNode,anchorOffset:r.anchorOffset,focusNode:r.focusNode,focusOffset:r.focusOffset}),ur&&cr(ur,r)||(ur=r,r=El(sc,"onSelect"),0<r.length&&(e=new No("onSelect","select",null,e,i),t.push({event:e,listeners:r}),e.target=Wi)))}function gi(t,e){var i={};return i[t.toLowerCase()]=e.toLowerCase(),i["Webkit"+t]="webkit"+e,i["Moz"+t]="moz"+e,i}var ta={animationend:gi("Animation","AnimationEnd"),animationiteration:gi("Animation","AnimationIteration"),animationstart:gi("Animation","AnimationStart"),transitionrun:gi("Transition","TransitionRun"),transitionstart:gi("Transition","TransitionStart"),transitioncancel:gi("Transition","TransitionCancel"),transitionend:gi("Transition","TransitionEnd")},uc={},n0={};gn&&(n0=document.createElement("div").style,"AnimationEvent"in window||(delete ta.animationend.animation,delete ta.animationiteration.animation,delete ta.animationstart.animation),"TransitionEvent"in window||delete ta.transitionend.transition);function yi(t){if(uc[t])return uc[t];if(!ta[t])return t;var e=ta[t],i;for(i in e)if(e.hasOwnProperty(i)&&i in n0)return uc[t]=e[i];return t}var i0=yi("animationend"),a0=yi("animationiteration"),r0=yi("animationstart"),zb=yi("transitionrun"),kb=yi("transitionstart"),Pb=yi("transitioncancel"),o0=yi("transitionend"),l0=new Map,fc="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");fc.push("scrollEnd");function Ke(t,e){l0.set(t,e),mi(e,[t])}var s0=new WeakMap;function Pe(t,e){if(typeof t=="object"&&t!==null){var i=s0.get(t);return i!==void 0?i:(e={value:t,source:e,stack:Ch(e)},s0.set(t,e),e)}return{value:t,source:e,stack:Ch(e)}}var Ve=[],ea=0,dc=0;function Go(){for(var t=ea,e=dc=ea=0;e<t;){var i=Ve[e];Ve[e++]=null;var r=Ve[e];Ve[e++]=null;var s=Ve[e];Ve[e++]=null;var u=Ve[e];if(Ve[e++]=null,r!==null&&s!==null){var y=r.pending;y===null?s.next=s:(s.next=y.next,y.next=s),r.pending=s}u!==0&&c0(i,s,u)}}function Io(t,e,i,r){Ve[ea++]=t,Ve[ea++]=e,Ve[ea++]=i,Ve[ea++]=r,dc|=r,t.lanes|=r,t=t.alternate,t!==null&&(t.lanes|=r)}function hc(t,e,i,r){return Io(t,e,i,r),qo(t)}function na(t,e){return Io(t,null,null,e),qo(t)}function c0(t,e,i){t.lanes|=i;var r=t.alternate;r!==null&&(r.lanes|=i);for(var s=!1,u=t.return;u!==null;)u.childLanes|=i,r=u.alternate,r!==null&&(r.childLanes|=i),u.tag===22&&(t=u.stateNode,t===null||t._visibility&1||(s=!0)),t=u,u=u.return;return t.tag===3?(u=t.stateNode,s&&e!==null&&(s=31-we(i),t=u.hiddenUpdates,r=t[s],r===null?t[s]=[e]:r.push(e),e.lane=i|536870912),u):null}function qo(t){if(50<kr)throw kr=0,vu=null,Error(l(185));for(var e=t.return;e!==null;)t=e,e=t.return;return t.tag===3?t.stateNode:null}var ia={};function Vb(t,e,i,r){this.tag=t,this.key=i,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=e,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=r,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Te(t,e,i,r){return new Vb(t,e,i,r)}function mc(t){return t=t.prototype,!(!t||!t.isReactComponent)}function yn(t,e){var i=t.alternate;return i===null?(i=Te(t.tag,e,t.key,t.mode),i.elementType=t.elementType,i.type=t.type,i.stateNode=t.stateNode,i.alternate=t,t.alternate=i):(i.pendingProps=e,i.type=t.type,i.flags=0,i.subtreeFlags=0,i.deletions=null),i.flags=t.flags&65011712,i.childLanes=t.childLanes,i.lanes=t.lanes,i.child=t.child,i.memoizedProps=t.memoizedProps,i.memoizedState=t.memoizedState,i.updateQueue=t.updateQueue,e=t.dependencies,i.dependencies=e===null?null:{lanes:e.lanes,firstContext:e.firstContext},i.sibling=t.sibling,i.index=t.index,i.ref=t.ref,i.refCleanup=t.refCleanup,i}function u0(t,e){t.flags&=65011714;var i=t.alternate;return i===null?(t.childLanes=0,t.lanes=e,t.child=null,t.subtreeFlags=0,t.memoizedProps=null,t.memoizedState=null,t.updateQueue=null,t.dependencies=null,t.stateNode=null):(t.childLanes=i.childLanes,t.lanes=i.lanes,t.child=i.child,t.subtreeFlags=0,t.deletions=null,t.memoizedProps=i.memoizedProps,t.memoizedState=i.memoizedState,t.updateQueue=i.updateQueue,t.type=i.type,e=i.dependencies,t.dependencies=e===null?null:{lanes:e.lanes,firstContext:e.firstContext}),t}function Fo(t,e,i,r,s,u){var y=0;if(r=t,typeof t=="function")mc(t)&&(y=1);else if(typeof t=="string")y=N2(t,i,et.current)?26:t==="html"||t==="head"||t==="body"?27:5;else t:switch(t){case lt:return t=Te(31,i,e,s),t.elementType=lt,t.lanes=u,t;case O:return xi(i.children,s,u,e);case z:y=8,s|=24;break;case P:return t=Te(12,i,e,s|2),t.elementType=P,t.lanes=u,t;case G:return t=Te(13,i,e,s),t.elementType=G,t.lanes=u,t;case K:return t=Te(19,i,e,s),t.elementType=K,t.lanes=u,t;default:if(typeof t=="object"&&t!==null)switch(t.$$typeof){case R:case V:y=10;break t;case H:y=9;break t;case X:y=11;break t;case F:y=14;break t;case Z:y=16,r=null;break t}y=29,i=Error(l(130,t===null?"null":typeof t,"")),r=null}return e=Te(y,i,e,s),e.elementType=t,e.type=r,e.lanes=u,e}function xi(t,e,i,r){return t=Te(7,t,r,e),t.lanes=i,t}function pc(t,e,i){return t=Te(6,t,null,e),t.lanes=i,t}function gc(t,e,i){return e=Te(4,t.children!==null?t.children:[],t.key,e),e.lanes=i,e.stateNode={containerInfo:t.containerInfo,pendingChildren:null,implementation:t.implementation},e}var aa=[],ra=0,Yo=null,Xo=0,Ue=[],Ne=0,vi=null,xn=1,vn="";function bi(t,e){aa[ra++]=Xo,aa[ra++]=Yo,Yo=t,Xo=e}function f0(t,e,i){Ue[Ne++]=xn,Ue[Ne++]=vn,Ue[Ne++]=vi,vi=t;var r=xn;t=vn;var s=32-we(r)-1;r&=~(1<<s),i+=1;var u=32-we(e)+s;if(30<u){var y=s-s%5;u=(r&(1<<y)-1).toString(32),r>>=y,s-=y,xn=1<<32-we(e)+s|i<<s|r,vn=u+t}else xn=1<<u|i<<s|r,vn=t}function yc(t){t.return!==null&&(bi(t,1),f0(t,1,0))}function xc(t){for(;t===Yo;)Yo=aa[--ra],aa[ra]=null,Xo=aa[--ra],aa[ra]=null;for(;t===vi;)vi=Ue[--Ne],Ue[Ne]=null,vn=Ue[--Ne],Ue[Ne]=null,xn=Ue[--Ne],Ue[Ne]=null}var me=null,Vt=null,bt=!1,Si=null,en=!1,vc=Error(l(519));function Ai(t){var e=Error(l(418,""));throw hr(Pe(e,t)),vc}function d0(t){var e=t.stateNode,i=t.type,r=t.memoizedProps;switch(e[ue]=t,e[ge]=r,i){case"dialog":pt("cancel",e),pt("close",e);break;case"iframe":case"object":case"embed":pt("load",e);break;case"video":case"audio":for(i=0;i<Vr.length;i++)pt(Vr[i],e);break;case"source":pt("error",e);break;case"img":case"image":case"link":pt("error",e),pt("load",e);break;case"details":pt("toggle",e);break;case"input":pt("invalid",e),Mh(e,r.value,r.defaultValue,r.checked,r.defaultChecked,r.type,r.name,!0),Bo(e);break;case"select":pt("invalid",e);break;case"textarea":pt("invalid",e),Oh(e,r.value,r.defaultValue,r.children),Bo(e)}i=r.children,typeof i!="string"&&typeof i!="number"&&typeof i!="bigint"||e.textContent===""+i||r.suppressHydrationWarning===!0||Op(e.textContent,i)?(r.popover!=null&&(pt("beforetoggle",e),pt("toggle",e)),r.onScroll!=null&&pt("scroll",e),r.onScrollEnd!=null&&pt("scrollend",e),r.onClick!=null&&(e.onclick=Ml),e=!0):e=!1,e||Ai(t)}function h0(t){for(me=t.return;me;)switch(me.tag){case 5:case 13:en=!1;return;case 27:case 3:en=!0;return;default:me=me.return}}function fr(t){if(t!==me)return!1;if(!bt)return h0(t),bt=!0,!1;var e=t.tag,i;if((i=e!==3&&e!==27)&&((i=e===5)&&(i=t.type,i=!(i!=="form"&&i!=="button")||ku(t.type,t.memoizedProps)),i=!i),i&&Vt&&Ai(t),h0(t),e===13){if(t=t.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(l(317));t:{for(t=t.nextSibling,e=0;t;){if(t.nodeType===8)if(i=t.data,i==="/$"){if(e===0){Vt=Qe(t.nextSibling);break t}e--}else i!=="$"&&i!=="$!"&&i!=="$?"||e++;t=t.nextSibling}Vt=null}}else e===27?(e=Vt,Wn(t.type)?(t=Nu,Nu=null,Vt=t):Vt=e):Vt=me?Qe(t.stateNode.nextSibling):null;return!0}function dr(){Vt=me=null,bt=!1}function m0(){var t=Si;return t!==null&&(be===null?be=t:be.push.apply(be,t),Si=null),t}function hr(t){Si===null?Si=[t]:Si.push(t)}var bc=q(null),wi=null,bn=null;function Un(t,e,i){Q(bc,e._currentValue),e._currentValue=i}function Sn(t){t._currentValue=bc.current,$(bc)}function Sc(t,e,i){for(;t!==null;){var r=t.alternate;if((t.childLanes&e)!==e?(t.childLanes|=e,r!==null&&(r.childLanes|=e)):r!==null&&(r.childLanes&e)!==e&&(r.childLanes|=e),t===i)break;t=t.return}}function Ac(t,e,i,r){var s=t.child;for(s!==null&&(s.return=t);s!==null;){var u=s.dependencies;if(u!==null){var y=s.child;u=u.firstContext;t:for(;u!==null;){var v=u;u=s;for(var w=0;w<e.length;w++)if(v.context===e[w]){u.lanes|=i,v=u.alternate,v!==null&&(v.lanes|=i),Sc(u.return,i,t),r||(y=null);break t}u=v.next}}else if(s.tag===18){if(y=s.return,y===null)throw Error(l(341));y.lanes|=i,u=y.alternate,u!==null&&(u.lanes|=i),Sc(y,i,t),y=null}else y=s.child;if(y!==null)y.return=s;else for(y=s;y!==null;){if(y===t){y=null;break}if(s=y.sibling,s!==null){s.return=y.return,y=s;break}y=y.return}s=y}}function mr(t,e,i,r){t=null;for(var s=e,u=!1;s!==null;){if(!u){if((s.flags&524288)!==0)u=!0;else if((s.flags&262144)!==0)break}if(s.tag===10){var y=s.alternate;if(y===null)throw Error(l(387));if(y=y.memoizedProps,y!==null){var v=s.type;Ce(s.pendingProps.value,y.value)||(t!==null?t.push(v):t=[v])}}else if(s===Zt.current){if(y=s.alternate,y===null)throw Error(l(387));y.memoizedState.memoizedState!==s.memoizedState.memoizedState&&(t!==null?t.push(Ir):t=[Ir])}s=s.return}t!==null&&Ac(e,t,i,r),e.flags|=262144}function Ko(t){for(t=t.firstContext;t!==null;){if(!Ce(t.context._currentValue,t.memoizedValue))return!0;t=t.next}return!1}function Ci(t){wi=t,bn=null,t=t.dependencies,t!==null&&(t.firstContext=null)}function fe(t){return p0(wi,t)}function $o(t,e){return wi===null&&Ci(t),p0(t,e)}function p0(t,e){var i=e._currentValue;if(e={context:e,memoizedValue:i,next:null},bn===null){if(t===null)throw Error(l(308));bn=e,t.dependencies={lanes:0,firstContext:e},t.flags|=524288}else bn=bn.next=e;return i}var Ub=typeof AbortController<"u"?AbortController:function(){var t=[],e=this.signal={aborted:!1,addEventListener:function(i,r){t.push(r)}};this.abort=function(){e.aborted=!0,t.forEach(function(i){return i()})}},Nb=n.unstable_scheduleCallback,_b=n.unstable_NormalPriority,$t={$$typeof:V,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function wc(){return{controller:new Ub,data:new Map,refCount:0}}function pr(t){t.refCount--,t.refCount===0&&Nb(_b,function(){t.controller.abort()})}var gr=null,Cc=0,oa=0,la=null;function Hb(t,e){if(gr===null){var i=gr=[];Cc=0,oa=Eu(),la={status:"pending",value:void 0,then:function(r){i.push(r)}}}return Cc++,e.then(g0,g0),e}function g0(){if(--Cc===0&&gr!==null){la!==null&&(la.status="fulfilled");var t=gr;gr=null,oa=0,la=null;for(var e=0;e<t.length;e++)(0,t[e])()}}function Gb(t,e){var i=[],r={status:"pending",value:null,reason:null,then:function(s){i.push(s)}};return t.then(function(){r.status="fulfilled",r.value=e;for(var s=0;s<i.length;s++)(0,i[s])(e)},function(s){for(r.status="rejected",r.reason=s,s=0;s<i.length;s++)(0,i[s])(void 0)}),r}var y0=U.S;U.S=function(t,e){typeof e=="object"&&e!==null&&typeof e.then=="function"&&Hb(t,e),y0!==null&&y0(t,e)};var Ti=q(null);function Tc(){var t=Ti.current;return t!==null?t:Ot.pooledCache}function Qo(t,e){e===null?Q(Ti,Ti.current):Q(Ti,e.pool)}function x0(){var t=Tc();return t===null?null:{parent:$t._currentValue,pool:t}}var yr=Error(l(460)),v0=Error(l(474)),Zo=Error(l(542)),Ec={then:function(){}};function b0(t){return t=t.status,t==="fulfilled"||t==="rejected"}function Jo(){}function S0(t,e,i){switch(i=t[i],i===void 0?t.push(e):i!==e&&(e.then(Jo,Jo),e=i),e.status){case"fulfilled":return e.value;case"rejected":throw t=e.reason,w0(t),t;default:if(typeof e.status=="string")e.then(Jo,Jo);else{if(t=Ot,t!==null&&100<t.shellSuspendCounter)throw Error(l(482));t=e,t.status="pending",t.then(function(r){if(e.status==="pending"){var s=e;s.status="fulfilled",s.value=r}},function(r){if(e.status==="pending"){var s=e;s.status="rejected",s.reason=r}})}switch(e.status){case"fulfilled":return e.value;case"rejected":throw t=e.reason,w0(t),t}throw xr=e,yr}}var xr=null;function A0(){if(xr===null)throw Error(l(459));var t=xr;return xr=null,t}function w0(t){if(t===yr||t===Zo)throw Error(l(483))}var Nn=!1;function Mc(t){t.updateQueue={baseState:t.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function jc(t,e){t=t.updateQueue,e.updateQueue===t&&(e.updateQueue={baseState:t.baseState,firstBaseUpdate:t.firstBaseUpdate,lastBaseUpdate:t.lastBaseUpdate,shared:t.shared,callbacks:null})}function _n(t){return{lane:t,tag:0,payload:null,callback:null,next:null}}function Hn(t,e,i){var r=t.updateQueue;if(r===null)return null;if(r=r.shared,(wt&2)!==0){var s=r.pending;return s===null?e.next=e:(e.next=s.next,s.next=e),r.pending=e,e=qo(t),c0(t,null,i),e}return Io(t,r,e,i),qo(t)}function vr(t,e,i){if(e=e.updateQueue,e!==null&&(e=e.shared,(i&4194048)!==0)){var r=e.lanes;r&=t.pendingLanes,i|=r,e.lanes=i,gh(t,i)}}function Oc(t,e){var i=t.updateQueue,r=t.alternate;if(r!==null&&(r=r.updateQueue,i===r)){var s=null,u=null;if(i=i.firstBaseUpdate,i!==null){do{var y={lane:i.lane,tag:i.tag,payload:i.payload,callback:null,next:null};u===null?s=u=y:u=u.next=y,i=i.next}while(i!==null);u===null?s=u=e:u=u.next=e}else s=u=e;i={baseState:r.baseState,firstBaseUpdate:s,lastBaseUpdate:u,shared:r.shared,callbacks:r.callbacks},t.updateQueue=i;return}t=i.lastBaseUpdate,t===null?i.firstBaseUpdate=e:t.next=e,i.lastBaseUpdate=e}var Dc=!1;function br(){if(Dc){var t=la;if(t!==null)throw t}}function Sr(t,e,i,r){Dc=!1;var s=t.updateQueue;Nn=!1;var u=s.firstBaseUpdate,y=s.lastBaseUpdate,v=s.shared.pending;if(v!==null){s.shared.pending=null;var w=v,L=w.next;w.next=null,y===null?u=L:y.next=L,y=w;var N=t.alternate;N!==null&&(N=N.updateQueue,v=N.lastBaseUpdate,v!==y&&(v===null?N.firstBaseUpdate=L:v.next=L,N.lastBaseUpdate=w))}if(u!==null){var I=s.baseState;y=0,N=L=w=null,v=u;do{var B=v.lane&-536870913,k=B!==v.lane;if(k?(yt&B)===B:(r&B)===B){B!==0&&B===oa&&(Dc=!0),N!==null&&(N=N.next={lane:0,tag:v.tag,payload:v.payload,callback:null,next:null});t:{var rt=t,nt=v;B=e;var Mt=i;switch(nt.tag){case 1:if(rt=nt.payload,typeof rt=="function"){I=rt.call(Mt,I,B);break t}I=rt;break t;case 3:rt.flags=rt.flags&-65537|128;case 0:if(rt=nt.payload,B=typeof rt=="function"?rt.call(Mt,I,B):rt,B==null)break t;I=x({},I,B);break t;case 2:Nn=!0}}B=v.callback,B!==null&&(t.flags|=64,k&&(t.flags|=8192),k=s.callbacks,k===null?s.callbacks=[B]:k.push(B))}else k={lane:B,tag:v.tag,payload:v.payload,callback:v.callback,next:null},N===null?(L=N=k,w=I):N=N.next=k,y|=B;if(v=v.next,v===null){if(v=s.shared.pending,v===null)break;k=v,v=k.next,k.next=null,s.lastBaseUpdate=k,s.shared.pending=null}}while(!0);N===null&&(w=I),s.baseState=w,s.firstBaseUpdate=L,s.lastBaseUpdate=N,u===null&&(s.shared.lanes=0),$n|=y,t.lanes=y,t.memoizedState=I}}function C0(t,e){if(typeof t!="function")throw Error(l(191,t));t.call(e)}function T0(t,e){var i=t.callbacks;if(i!==null)for(t.callbacks=null,t=0;t<i.length;t++)C0(i[t],e)}var sa=q(null),Wo=q(0);function E0(t,e){t=jn,Q(Wo,t),Q(sa,e),jn=t|e.baseLanes}function Rc(){Q(Wo,jn),Q(sa,sa.current)}function Lc(){jn=Wo.current,$(sa),$(Wo)}var Gn=0,ft=null,Tt=null,qt=null,tl=!1,ca=!1,Ei=!1,el=0,Ar=0,ua=null,Ib=0;function Ht(){throw Error(l(321))}function Bc(t,e){if(e===null)return!1;for(var i=0;i<e.length&&i<t.length;i++)if(!Ce(t[i],e[i]))return!1;return!0}function zc(t,e,i,r,s,u){return Gn=u,ft=e,e.memoizedState=null,e.updateQueue=null,e.lanes=0,U.H=t===null||t.memoizedState===null?cm:um,Ei=!1,u=i(r,s),Ei=!1,ca&&(u=j0(e,i,r,s)),M0(t),u}function M0(t){U.H=ll;var e=Tt!==null&&Tt.next!==null;if(Gn=0,qt=Tt=ft=null,tl=!1,Ar=0,ua=null,e)throw Error(l(300));t===null||Wt||(t=t.dependencies,t!==null&&Ko(t)&&(Wt=!0))}function j0(t,e,i,r){ft=t;var s=0;do{if(ca&&(ua=null),Ar=0,ca=!1,25<=s)throw Error(l(301));if(s+=1,qt=Tt=null,t.updateQueue!=null){var u=t.updateQueue;u.lastEffect=null,u.events=null,u.stores=null,u.memoCache!=null&&(u.memoCache.index=0)}U.H=Qb,u=e(i,r)}while(ca);return u}function qb(){var t=U.H,e=t.useState()[0];return e=typeof e.then=="function"?wr(e):e,t=t.useState()[0],(Tt!==null?Tt.memoizedState:null)!==t&&(ft.flags|=1024),e}function kc(){var t=el!==0;return el=0,t}function Pc(t,e,i){e.updateQueue=t.updateQueue,e.flags&=-2053,t.lanes&=~i}function Vc(t){if(tl){for(t=t.memoizedState;t!==null;){var e=t.queue;e!==null&&(e.pending=null),t=t.next}tl=!1}Gn=0,qt=Tt=ft=null,ca=!1,Ar=el=0,ua=null}function xe(){var t={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return qt===null?ft.memoizedState=qt=t:qt=qt.next=t,qt}function Ft(){if(Tt===null){var t=ft.alternate;t=t!==null?t.memoizedState:null}else t=Tt.next;var e=qt===null?ft.memoizedState:qt.next;if(e!==null)qt=e,Tt=t;else{if(t===null)throw ft.alternate===null?Error(l(467)):Error(l(310));Tt=t,t={memoizedState:Tt.memoizedState,baseState:Tt.baseState,baseQueue:Tt.baseQueue,queue:Tt.queue,next:null},qt===null?ft.memoizedState=qt=t:qt=qt.next=t}return qt}function Uc(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function wr(t){var e=Ar;return Ar+=1,ua===null&&(ua=[]),t=S0(ua,t,e),e=ft,(qt===null?e.memoizedState:qt.next)===null&&(e=e.alternate,U.H=e===null||e.memoizedState===null?cm:um),t}function nl(t){if(t!==null&&typeof t=="object"){if(typeof t.then=="function")return wr(t);if(t.$$typeof===V)return fe(t)}throw Error(l(438,String(t)))}function Nc(t){var e=null,i=ft.updateQueue;if(i!==null&&(e=i.memoCache),e==null){var r=ft.alternate;r!==null&&(r=r.updateQueue,r!==null&&(r=r.memoCache,r!=null&&(e={data:r.data.map(function(s){return s.slice()}),index:0})))}if(e==null&&(e={data:[],index:0}),i===null&&(i=Uc(),ft.updateQueue=i),i.memoCache=e,i=e.data[e.index],i===void 0)for(i=e.data[e.index]=Array(t),r=0;r<t;r++)i[r]=vt;return e.index++,i}function An(t,e){return typeof e=="function"?e(t):e}function il(t){var e=Ft();return _c(e,Tt,t)}function _c(t,e,i){var r=t.queue;if(r===null)throw Error(l(311));r.lastRenderedReducer=i;var s=t.baseQueue,u=r.pending;if(u!==null){if(s!==null){var y=s.next;s.next=u.next,u.next=y}e.baseQueue=s=u,r.pending=null}if(u=t.baseState,s===null)t.memoizedState=u;else{e=s.next;var v=y=null,w=null,L=e,N=!1;do{var I=L.lane&-536870913;if(I!==L.lane?(yt&I)===I:(Gn&I)===I){var B=L.revertLane;if(B===0)w!==null&&(w=w.next={lane:0,revertLane:0,action:L.action,hasEagerState:L.hasEagerState,eagerState:L.eagerState,next:null}),I===oa&&(N=!0);else if((Gn&B)===B){L=L.next,B===oa&&(N=!0);continue}else I={lane:0,revertLane:L.revertLane,action:L.action,hasEagerState:L.hasEagerState,eagerState:L.eagerState,next:null},w===null?(v=w=I,y=u):w=w.next=I,ft.lanes|=B,$n|=B;I=L.action,Ei&&i(u,I),u=L.hasEagerState?L.eagerState:i(u,I)}else B={lane:I,revertLane:L.revertLane,action:L.action,hasEagerState:L.hasEagerState,eagerState:L.eagerState,next:null},w===null?(v=w=B,y=u):w=w.next=B,ft.lanes|=I,$n|=I;L=L.next}while(L!==null&&L!==e);if(w===null?y=u:w.next=v,!Ce(u,t.memoizedState)&&(Wt=!0,N&&(i=la,i!==null)))throw i;t.memoizedState=u,t.baseState=y,t.baseQueue=w,r.lastRenderedState=u}return s===null&&(r.lanes=0),[t.memoizedState,r.dispatch]}function Hc(t){var e=Ft(),i=e.queue;if(i===null)throw Error(l(311));i.lastRenderedReducer=t;var r=i.dispatch,s=i.pending,u=e.memoizedState;if(s!==null){i.pending=null;var y=s=s.next;do u=t(u,y.action),y=y.next;while(y!==s);Ce(u,e.memoizedState)||(Wt=!0),e.memoizedState=u,e.baseQueue===null&&(e.baseState=u),i.lastRenderedState=u}return[u,r]}function O0(t,e,i){var r=ft,s=Ft(),u=bt;if(u){if(i===void 0)throw Error(l(407));i=i()}else i=e();var y=!Ce((Tt||s).memoizedState,i);y&&(s.memoizedState=i,Wt=!0),s=s.queue;var v=L0.bind(null,r,s,t);if(Cr(2048,8,v,[t]),s.getSnapshot!==e||y||qt!==null&&qt.memoizedState.tag&1){if(r.flags|=2048,fa(9,al(),R0.bind(null,r,s,i,e),null),Ot===null)throw Error(l(349));u||(Gn&124)!==0||D0(r,e,i)}return i}function D0(t,e,i){t.flags|=16384,t={getSnapshot:e,value:i},e=ft.updateQueue,e===null?(e=Uc(),ft.updateQueue=e,e.stores=[t]):(i=e.stores,i===null?e.stores=[t]:i.push(t))}function R0(t,e,i,r){e.value=i,e.getSnapshot=r,B0(e)&&z0(t)}function L0(t,e,i){return i(function(){B0(e)&&z0(t)})}function B0(t){var e=t.getSnapshot;t=t.value;try{var i=e();return!Ce(t,i)}catch{return!0}}function z0(t){var e=na(t,2);e!==null&&De(e,t,2)}function Gc(t){var e=xe();if(typeof t=="function"){var i=t;if(t=i(),Ei){kn(!0);try{i()}finally{kn(!1)}}}return e.memoizedState=e.baseState=t,e.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:An,lastRenderedState:t},e}function k0(t,e,i,r){return t.baseState=i,_c(t,Tt,typeof r=="function"?r:An)}function Fb(t,e,i,r,s){if(ol(t))throw Error(l(485));if(t=e.action,t!==null){var u={payload:s,action:t,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(y){u.listeners.push(y)}};U.T!==null?i(!0):u.isTransition=!1,r(u),i=e.pending,i===null?(u.next=e.pending=u,P0(e,u)):(u.next=i.next,e.pending=i.next=u)}}function P0(t,e){var i=e.action,r=e.payload,s=t.state;if(e.isTransition){var u=U.T,y={};U.T=y;try{var v=i(s,r),w=U.S;w!==null&&w(y,v),V0(t,e,v)}catch(L){Ic(t,e,L)}finally{U.T=u}}else try{u=i(s,r),V0(t,e,u)}catch(L){Ic(t,e,L)}}function V0(t,e,i){i!==null&&typeof i=="object"&&typeof i.then=="function"?i.then(function(r){U0(t,e,r)},function(r){return Ic(t,e,r)}):U0(t,e,i)}function U0(t,e,i){e.status="fulfilled",e.value=i,N0(e),t.state=i,e=t.pending,e!==null&&(i=e.next,i===e?t.pending=null:(i=i.next,e.next=i,P0(t,i)))}function Ic(t,e,i){var r=t.pending;if(t.pending=null,r!==null){r=r.next;do e.status="rejected",e.reason=i,N0(e),e=e.next;while(e!==r)}t.action=null}function N0(t){t=t.listeners;for(var e=0;e<t.length;e++)(0,t[e])()}function _0(t,e){return e}function H0(t,e){if(bt){var i=Ot.formState;if(i!==null){t:{var r=ft;if(bt){if(Vt){e:{for(var s=Vt,u=en;s.nodeType!==8;){if(!u){s=null;break e}if(s=Qe(s.nextSibling),s===null){s=null;break e}}u=s.data,s=u==="F!"||u==="F"?s:null}if(s){Vt=Qe(s.nextSibling),r=s.data==="F!";break t}}Ai(r)}r=!1}r&&(e=i[0])}}return i=xe(),i.memoizedState=i.baseState=e,r={pending:null,lanes:0,dispatch:null,lastRenderedReducer:_0,lastRenderedState:e},i.queue=r,i=om.bind(null,ft,r),r.dispatch=i,r=Gc(!1),u=Kc.bind(null,ft,!1,r.queue),r=xe(),s={state:e,dispatch:null,action:t,pending:null},r.queue=s,i=Fb.bind(null,ft,s,u,i),s.dispatch=i,r.memoizedState=t,[e,i,!1]}function G0(t){var e=Ft();return I0(e,Tt,t)}function I0(t,e,i){if(e=_c(t,e,_0)[0],t=il(An)[0],typeof e=="object"&&e!==null&&typeof e.then=="function")try{var r=wr(e)}catch(y){throw y===yr?Zo:y}else r=e;e=Ft();var s=e.queue,u=s.dispatch;return i!==e.memoizedState&&(ft.flags|=2048,fa(9,al(),Yb.bind(null,s,i),null)),[r,u,t]}function Yb(t,e){t.action=e}function q0(t){var e=Ft(),i=Tt;if(i!==null)return I0(e,i,t);Ft(),e=e.memoizedState,i=Ft();var r=i.queue.dispatch;return i.memoizedState=t,[e,r,!1]}function fa(t,e,i,r){return t={tag:t,create:i,deps:r,inst:e,next:null},e=ft.updateQueue,e===null&&(e=Uc(),ft.updateQueue=e),i=e.lastEffect,i===null?e.lastEffect=t.next=t:(r=i.next,i.next=t,t.next=r,e.lastEffect=t),t}function al(){return{destroy:void 0,resource:void 0}}function F0(){return Ft().memoizedState}function rl(t,e,i,r){var s=xe();r=r===void 0?null:r,ft.flags|=t,s.memoizedState=fa(1|e,al(),i,r)}function Cr(t,e,i,r){var s=Ft();r=r===void 0?null:r;var u=s.memoizedState.inst;Tt!==null&&r!==null&&Bc(r,Tt.memoizedState.deps)?s.memoizedState=fa(e,u,i,r):(ft.flags|=t,s.memoizedState=fa(1|e,u,i,r))}function Y0(t,e){rl(8390656,8,t,e)}function X0(t,e){Cr(2048,8,t,e)}function K0(t,e){return Cr(4,2,t,e)}function $0(t,e){return Cr(4,4,t,e)}function Q0(t,e){if(typeof e=="function"){t=t();var i=e(t);return function(){typeof i=="function"?i():e(null)}}if(e!=null)return t=t(),e.current=t,function(){e.current=null}}function Z0(t,e,i){i=i!=null?i.concat([t]):null,Cr(4,4,Q0.bind(null,e,t),i)}function qc(){}function J0(t,e){var i=Ft();e=e===void 0?null:e;var r=i.memoizedState;return e!==null&&Bc(e,r[1])?r[0]:(i.memoizedState=[t,e],t)}function W0(t,e){var i=Ft();e=e===void 0?null:e;var r=i.memoizedState;if(e!==null&&Bc(e,r[1]))return r[0];if(r=t(),Ei){kn(!0);try{t()}finally{kn(!1)}}return i.memoizedState=[r,e],r}function Fc(t,e,i){return i===void 0||(Gn&1073741824)!==0?t.memoizedState=e:(t.memoizedState=i,t=np(),ft.lanes|=t,$n|=t,i)}function tm(t,e,i,r){return Ce(i,e)?i:sa.current!==null?(t=Fc(t,i,r),Ce(t,e)||(Wt=!0),t):(Gn&42)===0?(Wt=!0,t.memoizedState=i):(t=np(),ft.lanes|=t,$n|=t,e)}function em(t,e,i,r,s){var u=Y.p;Y.p=u!==0&&8>u?u:8;var y=U.T,v={};U.T=v,Kc(t,!1,e,i);try{var w=s(),L=U.S;if(L!==null&&L(v,w),w!==null&&typeof w=="object"&&typeof w.then=="function"){var N=Gb(w,r);Tr(t,e,N,Oe(t))}else Tr(t,e,r,Oe(t))}catch(I){Tr(t,e,{then:function(){},status:"rejected",reason:I},Oe())}finally{Y.p=u,U.T=y}}function Xb(){}function Yc(t,e,i,r){if(t.tag!==5)throw Error(l(476));var s=nm(t).queue;em(t,s,e,W,i===null?Xb:function(){return im(t),i(r)})}function nm(t){var e=t.memoizedState;if(e!==null)return e;e={memoizedState:W,baseState:W,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:An,lastRenderedState:W},next:null};var i={};return e.next={memoizedState:i,baseState:i,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:An,lastRenderedState:i},next:null},t.memoizedState=e,t=t.alternate,t!==null&&(t.memoizedState=e),e}function im(t){var e=nm(t).next.queue;Tr(t,e,{},Oe())}function Xc(){return fe(Ir)}function am(){return Ft().memoizedState}function rm(){return Ft().memoizedState}function Kb(t){for(var e=t.return;e!==null;){switch(e.tag){case 24:case 3:var i=Oe();t=_n(i);var r=Hn(e,t,i);r!==null&&(De(r,e,i),vr(r,e,i)),e={cache:wc()},t.payload=e;return}e=e.return}}function $b(t,e,i){var r=Oe();i={lane:r,revertLane:0,action:i,hasEagerState:!1,eagerState:null,next:null},ol(t)?lm(e,i):(i=hc(t,e,i,r),i!==null&&(De(i,t,r),sm(i,e,r)))}function om(t,e,i){var r=Oe();Tr(t,e,i,r)}function Tr(t,e,i,r){var s={lane:r,revertLane:0,action:i,hasEagerState:!1,eagerState:null,next:null};if(ol(t))lm(e,s);else{var u=t.alternate;if(t.lanes===0&&(u===null||u.lanes===0)&&(u=e.lastRenderedReducer,u!==null))try{var y=e.lastRenderedState,v=u(y,i);if(s.hasEagerState=!0,s.eagerState=v,Ce(v,y))return Io(t,e,s,0),Ot===null&&Go(),!1}catch{}finally{}if(i=hc(t,e,s,r),i!==null)return De(i,t,r),sm(i,e,r),!0}return!1}function Kc(t,e,i,r){if(r={lane:2,revertLane:Eu(),action:r,hasEagerState:!1,eagerState:null,next:null},ol(t)){if(e)throw Error(l(479))}else e=hc(t,i,r,2),e!==null&&De(e,t,2)}function ol(t){var e=t.alternate;return t===ft||e!==null&&e===ft}function lm(t,e){ca=tl=!0;var i=t.pending;i===null?e.next=e:(e.next=i.next,i.next=e),t.pending=e}function sm(t,e,i){if((i&4194048)!==0){var r=e.lanes;r&=t.pendingLanes,i|=r,e.lanes=i,gh(t,i)}}var ll={readContext:fe,use:nl,useCallback:Ht,useContext:Ht,useEffect:Ht,useImperativeHandle:Ht,useLayoutEffect:Ht,useInsertionEffect:Ht,useMemo:Ht,useReducer:Ht,useRef:Ht,useState:Ht,useDebugValue:Ht,useDeferredValue:Ht,useTransition:Ht,useSyncExternalStore:Ht,useId:Ht,useHostTransitionStatus:Ht,useFormState:Ht,useActionState:Ht,useOptimistic:Ht,useMemoCache:Ht,useCacheRefresh:Ht},cm={readContext:fe,use:nl,useCallback:function(t,e){return xe().memoizedState=[t,e===void 0?null:e],t},useContext:fe,useEffect:Y0,useImperativeHandle:function(t,e,i){i=i!=null?i.concat([t]):null,rl(4194308,4,Q0.bind(null,e,t),i)},useLayoutEffect:function(t,e){return rl(4194308,4,t,e)},useInsertionEffect:function(t,e){rl(4,2,t,e)},useMemo:function(t,e){var i=xe();e=e===void 0?null:e;var r=t();if(Ei){kn(!0);try{t()}finally{kn(!1)}}return i.memoizedState=[r,e],r},useReducer:function(t,e,i){var r=xe();if(i!==void 0){var s=i(e);if(Ei){kn(!0);try{i(e)}finally{kn(!1)}}}else s=e;return r.memoizedState=r.baseState=s,t={pending:null,lanes:0,dispatch:null,lastRenderedReducer:t,lastRenderedState:s},r.queue=t,t=t.dispatch=$b.bind(null,ft,t),[r.memoizedState,t]},useRef:function(t){var e=xe();return t={current:t},e.memoizedState=t},useState:function(t){t=Gc(t);var e=t.queue,i=om.bind(null,ft,e);return e.dispatch=i,[t.memoizedState,i]},useDebugValue:qc,useDeferredValue:function(t,e){var i=xe();return Fc(i,t,e)},useTransition:function(){var t=Gc(!1);return t=em.bind(null,ft,t.queue,!0,!1),xe().memoizedState=t,[!1,t]},useSyncExternalStore:function(t,e,i){var r=ft,s=xe();if(bt){if(i===void 0)throw Error(l(407));i=i()}else{if(i=e(),Ot===null)throw Error(l(349));(yt&124)!==0||D0(r,e,i)}s.memoizedState=i;var u={value:i,getSnapshot:e};return s.queue=u,Y0(L0.bind(null,r,u,t),[t]),r.flags|=2048,fa(9,al(),R0.bind(null,r,u,i,e),null),i},useId:function(){var t=xe(),e=Ot.identifierPrefix;if(bt){var i=vn,r=xn;i=(r&~(1<<32-we(r)-1)).toString(32)+i,e="«"+e+"R"+i,i=el++,0<i&&(e+="H"+i.toString(32)),e+="»"}else i=Ib++,e="«"+e+"r"+i.toString(32)+"»";return t.memoizedState=e},useHostTransitionStatus:Xc,useFormState:H0,useActionState:H0,useOptimistic:function(t){var e=xe();e.memoizedState=e.baseState=t;var i={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return e.queue=i,e=Kc.bind(null,ft,!0,i),i.dispatch=e,[t,e]},useMemoCache:Nc,useCacheRefresh:function(){return xe().memoizedState=Kb.bind(null,ft)}},um={readContext:fe,use:nl,useCallback:J0,useContext:fe,useEffect:X0,useImperativeHandle:Z0,useInsertionEffect:K0,useLayoutEffect:$0,useMemo:W0,useReducer:il,useRef:F0,useState:function(){return il(An)},useDebugValue:qc,useDeferredValue:function(t,e){var i=Ft();return tm(i,Tt.memoizedState,t,e)},useTransition:function(){var t=il(An)[0],e=Ft().memoizedState;return[typeof t=="boolean"?t:wr(t),e]},useSyncExternalStore:O0,useId:am,useHostTransitionStatus:Xc,useFormState:G0,useActionState:G0,useOptimistic:function(t,e){var i=Ft();return k0(i,Tt,t,e)},useMemoCache:Nc,useCacheRefresh:rm},Qb={readContext:fe,use:nl,useCallback:J0,useContext:fe,useEffect:X0,useImperativeHandle:Z0,useInsertionEffect:K0,useLayoutEffect:$0,useMemo:W0,useReducer:Hc,useRef:F0,useState:function(){return Hc(An)},useDebugValue:qc,useDeferredValue:function(t,e){var i=Ft();return Tt===null?Fc(i,t,e):tm(i,Tt.memoizedState,t,e)},useTransition:function(){var t=Hc(An)[0],e=Ft().memoizedState;return[typeof t=="boolean"?t:wr(t),e]},useSyncExternalStore:O0,useId:am,useHostTransitionStatus:Xc,useFormState:q0,useActionState:q0,useOptimistic:function(t,e){var i=Ft();return Tt!==null?k0(i,Tt,t,e):(i.baseState=t,[t,i.queue.dispatch])},useMemoCache:Nc,useCacheRefresh:rm},da=null,Er=0;function sl(t){var e=Er;return Er+=1,da===null&&(da=[]),S0(da,t,e)}function Mr(t,e){e=e.props.ref,t.ref=e!==void 0?e:null}function cl(t,e){throw e.$$typeof===A?Error(l(525)):(t=Object.prototype.toString.call(e),Error(l(31,t==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":t)))}function fm(t){var e=t._init;return e(t._payload)}function dm(t){function e(j,M){if(t){var D=j.deletions;D===null?(j.deletions=[M],j.flags|=16):D.push(M)}}function i(j,M){if(!t)return null;for(;M!==null;)e(j,M),M=M.sibling;return null}function r(j){for(var M=new Map;j!==null;)j.key!==null?M.set(j.key,j):M.set(j.index,j),j=j.sibling;return M}function s(j,M){return j=yn(j,M),j.index=0,j.sibling=null,j}function u(j,M,D){return j.index=D,t?(D=j.alternate,D!==null?(D=D.index,D<M?(j.flags|=67108866,M):D):(j.flags|=67108866,M)):(j.flags|=1048576,M)}function y(j){return t&&j.alternate===null&&(j.flags|=67108866),j}function v(j,M,D,_){return M===null||M.tag!==6?(M=pc(D,j.mode,_),M.return=j,M):(M=s(M,D),M.return=j,M)}function w(j,M,D,_){var J=D.type;return J===O?N(j,M,D.props.children,_,D.key):M!==null&&(M.elementType===J||typeof J=="object"&&J!==null&&J.$$typeof===Z&&fm(J)===M.type)?(M=s(M,D.props),Mr(M,D),M.return=j,M):(M=Fo(D.type,D.key,D.props,null,j.mode,_),Mr(M,D),M.return=j,M)}function L(j,M,D,_){return M===null||M.tag!==4||M.stateNode.containerInfo!==D.containerInfo||M.stateNode.implementation!==D.implementation?(M=gc(D,j.mode,_),M.return=j,M):(M=s(M,D.children||[]),M.return=j,M)}function N(j,M,D,_,J){return M===null||M.tag!==7?(M=xi(D,j.mode,_,J),M.return=j,M):(M=s(M,D),M.return=j,M)}function I(j,M,D){if(typeof M=="string"&&M!==""||typeof M=="number"||typeof M=="bigint")return M=pc(""+M,j.mode,D),M.return=j,M;if(typeof M=="object"&&M!==null){switch(M.$$typeof){case b:return D=Fo(M.type,M.key,M.props,null,j.mode,D),Mr(D,M),D.return=j,D;case C:return M=gc(M,j.mode,D),M.return=j,M;case Z:var _=M._init;return M=_(M._payload),I(j,M,D)}if(Kt(M)||_t(M))return M=xi(M,j.mode,D,null),M.return=j,M;if(typeof M.then=="function")return I(j,sl(M),D);if(M.$$typeof===V)return I(j,$o(j,M),D);cl(j,M)}return null}function B(j,M,D,_){var J=M!==null?M.key:null;if(typeof D=="string"&&D!==""||typeof D=="number"||typeof D=="bigint")return J!==null?null:v(j,M,""+D,_);if(typeof D=="object"&&D!==null){switch(D.$$typeof){case b:return D.key===J?w(j,M,D,_):null;case C:return D.key===J?L(j,M,D,_):null;case Z:return J=D._init,D=J(D._payload),B(j,M,D,_)}if(Kt(D)||_t(D))return J!==null?null:N(j,M,D,_,null);if(typeof D.then=="function")return B(j,M,sl(D),_);if(D.$$typeof===V)return B(j,M,$o(j,D),_);cl(j,D)}return null}function k(j,M,D,_,J){if(typeof _=="string"&&_!==""||typeof _=="number"||typeof _=="bigint")return j=j.get(D)||null,v(M,j,""+_,J);if(typeof _=="object"&&_!==null){switch(_.$$typeof){case b:return j=j.get(_.key===null?D:_.key)||null,w(M,j,_,J);case C:return j=j.get(_.key===null?D:_.key)||null,L(M,j,_,J);case Z:var dt=_._init;return _=dt(_._payload),k(j,M,D,_,J)}if(Kt(_)||_t(_))return j=j.get(D)||null,N(M,j,_,J,null);if(typeof _.then=="function")return k(j,M,D,sl(_),J);if(_.$$typeof===V)return k(j,M,D,$o(M,_),J);cl(M,_)}return null}function rt(j,M,D,_){for(var J=null,dt=null,tt=M,at=M=0,ee=null;tt!==null&&at<D.length;at++){tt.index>at?(ee=tt,tt=null):ee=tt.sibling;var xt=B(j,tt,D[at],_);if(xt===null){tt===null&&(tt=ee);break}t&&tt&&xt.alternate===null&&e(j,tt),M=u(xt,M,at),dt===null?J=xt:dt.sibling=xt,dt=xt,tt=ee}if(at===D.length)return i(j,tt),bt&&bi(j,at),J;if(tt===null){for(;at<D.length;at++)tt=I(j,D[at],_),tt!==null&&(M=u(tt,M,at),dt===null?J=tt:dt.sibling=tt,dt=tt);return bt&&bi(j,at),J}for(tt=r(tt);at<D.length;at++)ee=k(tt,j,at,D[at],_),ee!==null&&(t&&ee.alternate!==null&&tt.delete(ee.key===null?at:ee.key),M=u(ee,M,at),dt===null?J=ee:dt.sibling=ee,dt=ee);return t&&tt.forEach(function(ai){return e(j,ai)}),bt&&bi(j,at),J}function nt(j,M,D,_){if(D==null)throw Error(l(151));for(var J=null,dt=null,tt=M,at=M=0,ee=null,xt=D.next();tt!==null&&!xt.done;at++,xt=D.next()){tt.index>at?(ee=tt,tt=null):ee=tt.sibling;var ai=B(j,tt,xt.value,_);if(ai===null){tt===null&&(tt=ee);break}t&&tt&&ai.alternate===null&&e(j,tt),M=u(ai,M,at),dt===null?J=ai:dt.sibling=ai,dt=ai,tt=ee}if(xt.done)return i(j,tt),bt&&bi(j,at),J;if(tt===null){for(;!xt.done;at++,xt=D.next())xt=I(j,xt.value,_),xt!==null&&(M=u(xt,M,at),dt===null?J=xt:dt.sibling=xt,dt=xt);return bt&&bi(j,at),J}for(tt=r(tt);!xt.done;at++,xt=D.next())xt=k(tt,j,at,xt.value,_),xt!==null&&(t&&xt.alternate!==null&&tt.delete(xt.key===null?at:xt.key),M=u(xt,M,at),dt===null?J=xt:dt.sibling=xt,dt=xt);return t&&tt.forEach(function(Z2){return e(j,Z2)}),bt&&bi(j,at),J}function Mt(j,M,D,_){if(typeof D=="object"&&D!==null&&D.type===O&&D.key===null&&(D=D.props.children),typeof D=="object"&&D!==null){switch(D.$$typeof){case b:t:{for(var J=D.key;M!==null;){if(M.key===J){if(J=D.type,J===O){if(M.tag===7){i(j,M.sibling),_=s(M,D.props.children),_.return=j,j=_;break t}}else if(M.elementType===J||typeof J=="object"&&J!==null&&J.$$typeof===Z&&fm(J)===M.type){i(j,M.sibling),_=s(M,D.props),Mr(_,D),_.return=j,j=_;break t}i(j,M);break}else e(j,M);M=M.sibling}D.type===O?(_=xi(D.props.children,j.mode,_,D.key),_.return=j,j=_):(_=Fo(D.type,D.key,D.props,null,j.mode,_),Mr(_,D),_.return=j,j=_)}return y(j);case C:t:{for(J=D.key;M!==null;){if(M.key===J)if(M.tag===4&&M.stateNode.containerInfo===D.containerInfo&&M.stateNode.implementation===D.implementation){i(j,M.sibling),_=s(M,D.children||[]),_.return=j,j=_;break t}else{i(j,M);break}else e(j,M);M=M.sibling}_=gc(D,j.mode,_),_.return=j,j=_}return y(j);case Z:return J=D._init,D=J(D._payload),Mt(j,M,D,_)}if(Kt(D))return rt(j,M,D,_);if(_t(D)){if(J=_t(D),typeof J!="function")throw Error(l(150));return D=J.call(D),nt(j,M,D,_)}if(typeof D.then=="function")return Mt(j,M,sl(D),_);if(D.$$typeof===V)return Mt(j,M,$o(j,D),_);cl(j,D)}return typeof D=="string"&&D!==""||typeof D=="number"||typeof D=="bigint"?(D=""+D,M!==null&&M.tag===6?(i(j,M.sibling),_=s(M,D),_.return=j,j=_):(i(j,M),_=pc(D,j.mode,_),_.return=j,j=_),y(j)):i(j,M)}return function(j,M,D,_){try{Er=0;var J=Mt(j,M,D,_);return da=null,J}catch(tt){if(tt===yr||tt===Zo)throw tt;var dt=Te(29,tt,null,j.mode);return dt.lanes=_,dt.return=j,dt}finally{}}}var ha=dm(!0),hm=dm(!1),_e=q(null),nn=null;function In(t){var e=t.alternate;Q(Qt,Qt.current&1),Q(_e,t),nn===null&&(e===null||sa.current!==null||e.memoizedState!==null)&&(nn=t)}function mm(t){if(t.tag===22){if(Q(Qt,Qt.current),Q(_e,t),nn===null){var e=t.alternate;e!==null&&e.memoizedState!==null&&(nn=t)}}else qn()}function qn(){Q(Qt,Qt.current),Q(_e,_e.current)}function wn(t){$(_e),nn===t&&(nn=null),$(Qt)}var Qt=q(0);function ul(t){for(var e=t;e!==null;){if(e.tag===13){var i=e.memoizedState;if(i!==null&&(i=i.dehydrated,i===null||i.data==="$?"||Uu(i)))return e}else if(e.tag===19&&e.memoizedProps.revealOrder!==void 0){if((e.flags&128)!==0)return e}else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break;for(;e.sibling===null;){if(e.return===null||e.return===t)return null;e=e.return}e.sibling.return=e.return,e=e.sibling}return null}function $c(t,e,i,r){e=t.memoizedState,i=i(r,e),i=i==null?e:x({},e,i),t.memoizedState=i,t.lanes===0&&(t.updateQueue.baseState=i)}var Qc={enqueueSetState:function(t,e,i){t=t._reactInternals;var r=Oe(),s=_n(r);s.payload=e,i!=null&&(s.callback=i),e=Hn(t,s,r),e!==null&&(De(e,t,r),vr(e,t,r))},enqueueReplaceState:function(t,e,i){t=t._reactInternals;var r=Oe(),s=_n(r);s.tag=1,s.payload=e,i!=null&&(s.callback=i),e=Hn(t,s,r),e!==null&&(De(e,t,r),vr(e,t,r))},enqueueForceUpdate:function(t,e){t=t._reactInternals;var i=Oe(),r=_n(i);r.tag=2,e!=null&&(r.callback=e),e=Hn(t,r,i),e!==null&&(De(e,t,i),vr(e,t,i))}};function pm(t,e,i,r,s,u,y){return t=t.stateNode,typeof t.shouldComponentUpdate=="function"?t.shouldComponentUpdate(r,u,y):e.prototype&&e.prototype.isPureReactComponent?!cr(i,r)||!cr(s,u):!0}function gm(t,e,i,r){t=e.state,typeof e.componentWillReceiveProps=="function"&&e.componentWillReceiveProps(i,r),typeof e.UNSAFE_componentWillReceiveProps=="function"&&e.UNSAFE_componentWillReceiveProps(i,r),e.state!==t&&Qc.enqueueReplaceState(e,e.state,null)}function Mi(t,e){var i=e;if("ref"in e){i={};for(var r in e)r!=="ref"&&(i[r]=e[r])}if(t=t.defaultProps){i===e&&(i=x({},i));for(var s in t)i[s]===void 0&&(i[s]=t[s])}return i}var fl=typeof reportError=="function"?reportError:function(t){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var e=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof t=="object"&&t!==null&&typeof t.message=="string"?String(t.message):String(t),error:t});if(!window.dispatchEvent(e))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",t);return}console.error(t)};function ym(t){fl(t)}function xm(t){console.error(t)}function vm(t){fl(t)}function dl(t,e){try{var i=t.onUncaughtError;i(e.value,{componentStack:e.stack})}catch(r){setTimeout(function(){throw r})}}function bm(t,e,i){try{var r=t.onCaughtError;r(i.value,{componentStack:i.stack,errorBoundary:e.tag===1?e.stateNode:null})}catch(s){setTimeout(function(){throw s})}}function Zc(t,e,i){return i=_n(i),i.tag=3,i.payload={element:null},i.callback=function(){dl(t,e)},i}function Sm(t){return t=_n(t),t.tag=3,t}function Am(t,e,i,r){var s=i.type.getDerivedStateFromError;if(typeof s=="function"){var u=r.value;t.payload=function(){return s(u)},t.callback=function(){bm(e,i,r)}}var y=i.stateNode;y!==null&&typeof y.componentDidCatch=="function"&&(t.callback=function(){bm(e,i,r),typeof s!="function"&&(Qn===null?Qn=new Set([this]):Qn.add(this));var v=r.stack;this.componentDidCatch(r.value,{componentStack:v!==null?v:""})})}function Zb(t,e,i,r,s){if(i.flags|=32768,r!==null&&typeof r=="object"&&typeof r.then=="function"){if(e=i.alternate,e!==null&&mr(e,i,s,!0),i=_e.current,i!==null){switch(i.tag){case 13:return nn===null?Su():i.alternate===null&&Ut===0&&(Ut=3),i.flags&=-257,i.flags|=65536,i.lanes=s,r===Ec?i.flags|=16384:(e=i.updateQueue,e===null?i.updateQueue=new Set([r]):e.add(r),wu(t,r,s)),!1;case 22:return i.flags|=65536,r===Ec?i.flags|=16384:(e=i.updateQueue,e===null?(e={transitions:null,markerInstances:null,retryQueue:new Set([r])},i.updateQueue=e):(i=e.retryQueue,i===null?e.retryQueue=new Set([r]):i.add(r)),wu(t,r,s)),!1}throw Error(l(435,i.tag))}return wu(t,r,s),Su(),!1}if(bt)return e=_e.current,e!==null?((e.flags&65536)===0&&(e.flags|=256),e.flags|=65536,e.lanes=s,r!==vc&&(t=Error(l(422),{cause:r}),hr(Pe(t,i)))):(r!==vc&&(e=Error(l(423),{cause:r}),hr(Pe(e,i))),t=t.current.alternate,t.flags|=65536,s&=-s,t.lanes|=s,r=Pe(r,i),s=Zc(t.stateNode,r,s),Oc(t,s),Ut!==4&&(Ut=2)),!1;var u=Error(l(520),{cause:r});if(u=Pe(u,i),zr===null?zr=[u]:zr.push(u),Ut!==4&&(Ut=2),e===null)return!0;r=Pe(r,i),i=e;do{switch(i.tag){case 3:return i.flags|=65536,t=s&-s,i.lanes|=t,t=Zc(i.stateNode,r,t),Oc(i,t),!1;case 1:if(e=i.type,u=i.stateNode,(i.flags&128)===0&&(typeof e.getDerivedStateFromError=="function"||u!==null&&typeof u.componentDidCatch=="function"&&(Qn===null||!Qn.has(u))))return i.flags|=65536,s&=-s,i.lanes|=s,s=Sm(s),Am(s,t,i,r),Oc(i,s),!1}i=i.return}while(i!==null);return!1}var wm=Error(l(461)),Wt=!1;function re(t,e,i,r){e.child=t===null?hm(e,null,i,r):ha(e,t.child,i,r)}function Cm(t,e,i,r,s){i=i.render;var u=e.ref;if("ref"in r){var y={};for(var v in r)v!=="ref"&&(y[v]=r[v])}else y=r;return Ci(e),r=zc(t,e,i,y,u,s),v=kc(),t!==null&&!Wt?(Pc(t,e,s),Cn(t,e,s)):(bt&&v&&yc(e),e.flags|=1,re(t,e,r,s),e.child)}function Tm(t,e,i,r,s){if(t===null){var u=i.type;return typeof u=="function"&&!mc(u)&&u.defaultProps===void 0&&i.compare===null?(e.tag=15,e.type=u,Em(t,e,u,r,s)):(t=Fo(i.type,null,r,e,e.mode,s),t.ref=e.ref,t.return=e,e.child=t)}if(u=t.child,!ru(t,s)){var y=u.memoizedProps;if(i=i.compare,i=i!==null?i:cr,i(y,r)&&t.ref===e.ref)return Cn(t,e,s)}return e.flags|=1,t=yn(u,r),t.ref=e.ref,t.return=e,e.child=t}function Em(t,e,i,r,s){if(t!==null){var u=t.memoizedProps;if(cr(u,r)&&t.ref===e.ref)if(Wt=!1,e.pendingProps=r=u,ru(t,s))(t.flags&131072)!==0&&(Wt=!0);else return e.lanes=t.lanes,Cn(t,e,s)}return Jc(t,e,i,r,s)}function Mm(t,e,i){var r=e.pendingProps,s=r.children,u=t!==null?t.memoizedState:null;if(r.mode==="hidden"){if((e.flags&128)!==0){if(r=u!==null?u.baseLanes|i:i,t!==null){for(s=e.child=t.child,u=0;s!==null;)u=u|s.lanes|s.childLanes,s=s.sibling;e.childLanes=u&~r}else e.childLanes=0,e.child=null;return jm(t,e,r,i)}if((i&536870912)!==0)e.memoizedState={baseLanes:0,cachePool:null},t!==null&&Qo(e,u!==null?u.cachePool:null),u!==null?E0(e,u):Rc(),mm(e);else return e.lanes=e.childLanes=536870912,jm(t,e,u!==null?u.baseLanes|i:i,i)}else u!==null?(Qo(e,u.cachePool),E0(e,u),qn(),e.memoizedState=null):(t!==null&&Qo(e,null),Rc(),qn());return re(t,e,s,i),e.child}function jm(t,e,i,r){var s=Tc();return s=s===null?null:{parent:$t._currentValue,pool:s},e.memoizedState={baseLanes:i,cachePool:s},t!==null&&Qo(e,null),Rc(),mm(e),t!==null&&mr(t,e,r,!0),null}function hl(t,e){var i=e.ref;if(i===null)t!==null&&t.ref!==null&&(e.flags|=4194816);else{if(typeof i!="function"&&typeof i!="object")throw Error(l(284));(t===null||t.ref!==i)&&(e.flags|=4194816)}}function Jc(t,e,i,r,s){return Ci(e),i=zc(t,e,i,r,void 0,s),r=kc(),t!==null&&!Wt?(Pc(t,e,s),Cn(t,e,s)):(bt&&r&&yc(e),e.flags|=1,re(t,e,i,s),e.child)}function Om(t,e,i,r,s,u){return Ci(e),e.updateQueue=null,i=j0(e,r,i,s),M0(t),r=kc(),t!==null&&!Wt?(Pc(t,e,u),Cn(t,e,u)):(bt&&r&&yc(e),e.flags|=1,re(t,e,i,u),e.child)}function Dm(t,e,i,r,s){if(Ci(e),e.stateNode===null){var u=ia,y=i.contextType;typeof y=="object"&&y!==null&&(u=fe(y)),u=new i(r,u),e.memoizedState=u.state!==null&&u.state!==void 0?u.state:null,u.updater=Qc,e.stateNode=u,u._reactInternals=e,u=e.stateNode,u.props=r,u.state=e.memoizedState,u.refs={},Mc(e),y=i.contextType,u.context=typeof y=="object"&&y!==null?fe(y):ia,u.state=e.memoizedState,y=i.getDerivedStateFromProps,typeof y=="function"&&($c(e,i,y,r),u.state=e.memoizedState),typeof i.getDerivedStateFromProps=="function"||typeof u.getSnapshotBeforeUpdate=="function"||typeof u.UNSAFE_componentWillMount!="function"&&typeof u.componentWillMount!="function"||(y=u.state,typeof u.componentWillMount=="function"&&u.componentWillMount(),typeof u.UNSAFE_componentWillMount=="function"&&u.UNSAFE_componentWillMount(),y!==u.state&&Qc.enqueueReplaceState(u,u.state,null),Sr(e,r,u,s),br(),u.state=e.memoizedState),typeof u.componentDidMount=="function"&&(e.flags|=4194308),r=!0}else if(t===null){u=e.stateNode;var v=e.memoizedProps,w=Mi(i,v);u.props=w;var L=u.context,N=i.contextType;y=ia,typeof N=="object"&&N!==null&&(y=fe(N));var I=i.getDerivedStateFromProps;N=typeof I=="function"||typeof u.getSnapshotBeforeUpdate=="function",v=e.pendingProps!==v,N||typeof u.UNSAFE_componentWillReceiveProps!="function"&&typeof u.componentWillReceiveProps!="function"||(v||L!==y)&&gm(e,u,r,y),Nn=!1;var B=e.memoizedState;u.state=B,Sr(e,r,u,s),br(),L=e.memoizedState,v||B!==L||Nn?(typeof I=="function"&&($c(e,i,I,r),L=e.memoizedState),(w=Nn||pm(e,i,w,r,B,L,y))?(N||typeof u.UNSAFE_componentWillMount!="function"&&typeof u.componentWillMount!="function"||(typeof u.componentWillMount=="function"&&u.componentWillMount(),typeof u.UNSAFE_componentWillMount=="function"&&u.UNSAFE_componentWillMount()),typeof u.componentDidMount=="function"&&(e.flags|=4194308)):(typeof u.componentDidMount=="function"&&(e.flags|=4194308),e.memoizedProps=r,e.memoizedState=L),u.props=r,u.state=L,u.context=y,r=w):(typeof u.componentDidMount=="function"&&(e.flags|=4194308),r=!1)}else{u=e.stateNode,jc(t,e),y=e.memoizedProps,N=Mi(i,y),u.props=N,I=e.pendingProps,B=u.context,L=i.contextType,w=ia,typeof L=="object"&&L!==null&&(w=fe(L)),v=i.getDerivedStateFromProps,(L=typeof v=="function"||typeof u.getSnapshotBeforeUpdate=="function")||typeof u.UNSAFE_componentWillReceiveProps!="function"&&typeof u.componentWillReceiveProps!="function"||(y!==I||B!==w)&&gm(e,u,r,w),Nn=!1,B=e.memoizedState,u.state=B,Sr(e,r,u,s),br();var k=e.memoizedState;y!==I||B!==k||Nn||t!==null&&t.dependencies!==null&&Ko(t.dependencies)?(typeof v=="function"&&($c(e,i,v,r),k=e.memoizedState),(N=Nn||pm(e,i,N,r,B,k,w)||t!==null&&t.dependencies!==null&&Ko(t.dependencies))?(L||typeof u.UNSAFE_componentWillUpdate!="function"&&typeof u.componentWillUpdate!="function"||(typeof u.componentWillUpdate=="function"&&u.componentWillUpdate(r,k,w),typeof u.UNSAFE_componentWillUpdate=="function"&&u.UNSAFE_componentWillUpdate(r,k,w)),typeof u.componentDidUpdate=="function"&&(e.flags|=4),typeof u.getSnapshotBeforeUpdate=="function"&&(e.flags|=1024)):(typeof u.componentDidUpdate!="function"||y===t.memoizedProps&&B===t.memoizedState||(e.flags|=4),typeof u.getSnapshotBeforeUpdate!="function"||y===t.memoizedProps&&B===t.memoizedState||(e.flags|=1024),e.memoizedProps=r,e.memoizedState=k),u.props=r,u.state=k,u.context=w,r=N):(typeof u.componentDidUpdate!="function"||y===t.memoizedProps&&B===t.memoizedState||(e.flags|=4),typeof u.getSnapshotBeforeUpdate!="function"||y===t.memoizedProps&&B===t.memoizedState||(e.flags|=1024),r=!1)}return u=r,hl(t,e),r=(e.flags&128)!==0,u||r?(u=e.stateNode,i=r&&typeof i.getDerivedStateFromError!="function"?null:u.render(),e.flags|=1,t!==null&&r?(e.child=ha(e,t.child,null,s),e.child=ha(e,null,i,s)):re(t,e,i,s),e.memoizedState=u.state,t=e.child):t=Cn(t,e,s),t}function Rm(t,e,i,r){return dr(),e.flags|=256,re(t,e,i,r),e.child}var Wc={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function tu(t){return{baseLanes:t,cachePool:x0()}}function eu(t,e,i){return t=t!==null?t.childLanes&~i:0,e&&(t|=He),t}function Lm(t,e,i){var r=e.pendingProps,s=!1,u=(e.flags&128)!==0,y;if((y=u)||(y=t!==null&&t.memoizedState===null?!1:(Qt.current&2)!==0),y&&(s=!0,e.flags&=-129),y=(e.flags&32)!==0,e.flags&=-33,t===null){if(bt){if(s?In(e):qn(),bt){var v=Vt,w;if(w=v){t:{for(w=v,v=en;w.nodeType!==8;){if(!v){v=null;break t}if(w=Qe(w.nextSibling),w===null){v=null;break t}}v=w}v!==null?(e.memoizedState={dehydrated:v,treeContext:vi!==null?{id:xn,overflow:vn}:null,retryLane:536870912,hydrationErrors:null},w=Te(18,null,null,0),w.stateNode=v,w.return=e,e.child=w,me=e,Vt=null,w=!0):w=!1}w||Ai(e)}if(v=e.memoizedState,v!==null&&(v=v.dehydrated,v!==null))return Uu(v)?e.lanes=32:e.lanes=536870912,null;wn(e)}return v=r.children,r=r.fallback,s?(qn(),s=e.mode,v=ml({mode:"hidden",children:v},s),r=xi(r,s,i,null),v.return=e,r.return=e,v.sibling=r,e.child=v,s=e.child,s.memoizedState=tu(i),s.childLanes=eu(t,y,i),e.memoizedState=Wc,r):(In(e),nu(e,v))}if(w=t.memoizedState,w!==null&&(v=w.dehydrated,v!==null)){if(u)e.flags&256?(In(e),e.flags&=-257,e=iu(t,e,i)):e.memoizedState!==null?(qn(),e.child=t.child,e.flags|=128,e=null):(qn(),s=r.fallback,v=e.mode,r=ml({mode:"visible",children:r.children},v),s=xi(s,v,i,null),s.flags|=2,r.return=e,s.return=e,r.sibling=s,e.child=r,ha(e,t.child,null,i),r=e.child,r.memoizedState=tu(i),r.childLanes=eu(t,y,i),e.memoizedState=Wc,e=s);else if(In(e),Uu(v)){if(y=v.nextSibling&&v.nextSibling.dataset,y)var L=y.dgst;y=L,r=Error(l(419)),r.stack="",r.digest=y,hr({value:r,source:null,stack:null}),e=iu(t,e,i)}else if(Wt||mr(t,e,i,!1),y=(i&t.childLanes)!==0,Wt||y){if(y=Ot,y!==null&&(r=i&-i,r=(r&42)!==0?1:Ns(r),r=(r&(y.suspendedLanes|i))!==0?0:r,r!==0&&r!==w.retryLane))throw w.retryLane=r,na(t,r),De(y,t,r),wm;v.data==="$?"||Su(),e=iu(t,e,i)}else v.data==="$?"?(e.flags|=192,e.child=t.child,e=null):(t=w.treeContext,Vt=Qe(v.nextSibling),me=e,bt=!0,Si=null,en=!1,t!==null&&(Ue[Ne++]=xn,Ue[Ne++]=vn,Ue[Ne++]=vi,xn=t.id,vn=t.overflow,vi=e),e=nu(e,r.children),e.flags|=4096);return e}return s?(qn(),s=r.fallback,v=e.mode,w=t.child,L=w.sibling,r=yn(w,{mode:"hidden",children:r.children}),r.subtreeFlags=w.subtreeFlags&65011712,L!==null?s=yn(L,s):(s=xi(s,v,i,null),s.flags|=2),s.return=e,r.return=e,r.sibling=s,e.child=r,r=s,s=e.child,v=t.child.memoizedState,v===null?v=tu(i):(w=v.cachePool,w!==null?(L=$t._currentValue,w=w.parent!==L?{parent:L,pool:L}:w):w=x0(),v={baseLanes:v.baseLanes|i,cachePool:w}),s.memoizedState=v,s.childLanes=eu(t,y,i),e.memoizedState=Wc,r):(In(e),i=t.child,t=i.sibling,i=yn(i,{mode:"visible",children:r.children}),i.return=e,i.sibling=null,t!==null&&(y=e.deletions,y===null?(e.deletions=[t],e.flags|=16):y.push(t)),e.child=i,e.memoizedState=null,i)}function nu(t,e){return e=ml({mode:"visible",children:e},t.mode),e.return=t,t.child=e}function ml(t,e){return t=Te(22,t,null,e),t.lanes=0,t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null},t}function iu(t,e,i){return ha(e,t.child,null,i),t=nu(e,e.pendingProps.children),t.flags|=2,e.memoizedState=null,t}function Bm(t,e,i){t.lanes|=e;var r=t.alternate;r!==null&&(r.lanes|=e),Sc(t.return,e,i)}function au(t,e,i,r,s){var u=t.memoizedState;u===null?t.memoizedState={isBackwards:e,rendering:null,renderingStartTime:0,last:r,tail:i,tailMode:s}:(u.isBackwards=e,u.rendering=null,u.renderingStartTime=0,u.last=r,u.tail=i,u.tailMode=s)}function zm(t,e,i){var r=e.pendingProps,s=r.revealOrder,u=r.tail;if(re(t,e,r.children,i),r=Qt.current,(r&2)!==0)r=r&1|2,e.flags|=128;else{if(t!==null&&(t.flags&128)!==0)t:for(t=e.child;t!==null;){if(t.tag===13)t.memoizedState!==null&&Bm(t,i,e);else if(t.tag===19)Bm(t,i,e);else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break t;for(;t.sibling===null;){if(t.return===null||t.return===e)break t;t=t.return}t.sibling.return=t.return,t=t.sibling}r&=1}switch(Q(Qt,r),s){case"forwards":for(i=e.child,s=null;i!==null;)t=i.alternate,t!==null&&ul(t)===null&&(s=i),i=i.sibling;i=s,i===null?(s=e.child,e.child=null):(s=i.sibling,i.sibling=null),au(e,!1,s,i,u);break;case"backwards":for(i=null,s=e.child,e.child=null;s!==null;){if(t=s.alternate,t!==null&&ul(t)===null){e.child=s;break}t=s.sibling,s.sibling=i,i=s,s=t}au(e,!0,i,null,u);break;case"together":au(e,!1,null,null,void 0);break;default:e.memoizedState=null}return e.child}function Cn(t,e,i){if(t!==null&&(e.dependencies=t.dependencies),$n|=e.lanes,(i&e.childLanes)===0)if(t!==null){if(mr(t,e,i,!1),(i&e.childLanes)===0)return null}else return null;if(t!==null&&e.child!==t.child)throw Error(l(153));if(e.child!==null){for(t=e.child,i=yn(t,t.pendingProps),e.child=i,i.return=e;t.sibling!==null;)t=t.sibling,i=i.sibling=yn(t,t.pendingProps),i.return=e;i.sibling=null}return e.child}function ru(t,e){return(t.lanes&e)!==0?!0:(t=t.dependencies,!!(t!==null&&Ko(t)))}function Jb(t,e,i){switch(e.tag){case 3:St(e,e.stateNode.containerInfo),Un(e,$t,t.memoizedState.cache),dr();break;case 27:case 5:di(e);break;case 4:St(e,e.stateNode.containerInfo);break;case 10:Un(e,e.type,e.memoizedProps.value);break;case 13:var r=e.memoizedState;if(r!==null)return r.dehydrated!==null?(In(e),e.flags|=128,null):(i&e.child.childLanes)!==0?Lm(t,e,i):(In(e),t=Cn(t,e,i),t!==null?t.sibling:null);In(e);break;case 19:var s=(t.flags&128)!==0;if(r=(i&e.childLanes)!==0,r||(mr(t,e,i,!1),r=(i&e.childLanes)!==0),s){if(r)return zm(t,e,i);e.flags|=128}if(s=e.memoizedState,s!==null&&(s.rendering=null,s.tail=null,s.lastEffect=null),Q(Qt,Qt.current),r)break;return null;case 22:case 23:return e.lanes=0,Mm(t,e,i);case 24:Un(e,$t,t.memoizedState.cache)}return Cn(t,e,i)}function km(t,e,i){if(t!==null)if(t.memoizedProps!==e.pendingProps)Wt=!0;else{if(!ru(t,i)&&(e.flags&128)===0)return Wt=!1,Jb(t,e,i);Wt=(t.flags&131072)!==0}else Wt=!1,bt&&(e.flags&1048576)!==0&&f0(e,Xo,e.index);switch(e.lanes=0,e.tag){case 16:t:{t=e.pendingProps;var r=e.elementType,s=r._init;if(r=s(r._payload),e.type=r,typeof r=="function")mc(r)?(t=Mi(r,t),e.tag=1,e=Dm(null,e,r,t,i)):(e.tag=0,e=Jc(null,e,r,t,i));else{if(r!=null){if(s=r.$$typeof,s===X){e.tag=11,e=Cm(null,e,r,t,i);break t}else if(s===F){e.tag=14,e=Tm(null,e,r,t,i);break t}}throw e=Le(r)||r,Error(l(306,e,""))}}return e;case 0:return Jc(t,e,e.type,e.pendingProps,i);case 1:return r=e.type,s=Mi(r,e.pendingProps),Dm(t,e,r,s,i);case 3:t:{if(St(e,e.stateNode.containerInfo),t===null)throw Error(l(387));r=e.pendingProps;var u=e.memoizedState;s=u.element,jc(t,e),Sr(e,r,null,i);var y=e.memoizedState;if(r=y.cache,Un(e,$t,r),r!==u.cache&&Ac(e,[$t],i,!0),br(),r=y.element,u.isDehydrated)if(u={element:r,isDehydrated:!1,cache:y.cache},e.updateQueue.baseState=u,e.memoizedState=u,e.flags&256){e=Rm(t,e,r,i);break t}else if(r!==s){s=Pe(Error(l(424)),e),hr(s),e=Rm(t,e,r,i);break t}else{switch(t=e.stateNode.containerInfo,t.nodeType){case 9:t=t.body;break;default:t=t.nodeName==="HTML"?t.ownerDocument.body:t}for(Vt=Qe(t.firstChild),me=e,bt=!0,Si=null,en=!0,i=hm(e,null,r,i),e.child=i;i;)i.flags=i.flags&-3|4096,i=i.sibling}else{if(dr(),r===s){e=Cn(t,e,i);break t}re(t,e,r,i)}e=e.child}return e;case 26:return hl(t,e),t===null?(i=Np(e.type,null,e.pendingProps,null))?e.memoizedState=i:bt||(i=e.type,t=e.pendingProps,r=jl(it.current).createElement(i),r[ue]=e,r[ge]=t,le(r,i,t),Jt(r),e.stateNode=r):e.memoizedState=Np(e.type,t.memoizedProps,e.pendingProps,t.memoizedState),null;case 27:return di(e),t===null&&bt&&(r=e.stateNode=Pp(e.type,e.pendingProps,it.current),me=e,en=!0,s=Vt,Wn(e.type)?(Nu=s,Vt=Qe(r.firstChild)):Vt=s),re(t,e,e.pendingProps.children,i),hl(t,e),t===null&&(e.flags|=4194304),e.child;case 5:return t===null&&bt&&((s=r=Vt)&&(r=E2(r,e.type,e.pendingProps,en),r!==null?(e.stateNode=r,me=e,Vt=Qe(r.firstChild),en=!1,s=!0):s=!1),s||Ai(e)),di(e),s=e.type,u=e.pendingProps,y=t!==null?t.memoizedProps:null,r=u.children,ku(s,u)?r=null:y!==null&&ku(s,y)&&(e.flags|=32),e.memoizedState!==null&&(s=zc(t,e,qb,null,null,i),Ir._currentValue=s),hl(t,e),re(t,e,r,i),e.child;case 6:return t===null&&bt&&((t=i=Vt)&&(i=M2(i,e.pendingProps,en),i!==null?(e.stateNode=i,me=e,Vt=null,t=!0):t=!1),t||Ai(e)),null;case 13:return Lm(t,e,i);case 4:return St(e,e.stateNode.containerInfo),r=e.pendingProps,t===null?e.child=ha(e,null,r,i):re(t,e,r,i),e.child;case 11:return Cm(t,e,e.type,e.pendingProps,i);case 7:return re(t,e,e.pendingProps,i),e.child;case 8:return re(t,e,e.pendingProps.children,i),e.child;case 12:return re(t,e,e.pendingProps.children,i),e.child;case 10:return r=e.pendingProps,Un(e,e.type,r.value),re(t,e,r.children,i),e.child;case 9:return s=e.type._context,r=e.pendingProps.children,Ci(e),s=fe(s),r=r(s),e.flags|=1,re(t,e,r,i),e.child;case 14:return Tm(t,e,e.type,e.pendingProps,i);case 15:return Em(t,e,e.type,e.pendingProps,i);case 19:return zm(t,e,i);case 31:return r=e.pendingProps,i=e.mode,r={mode:r.mode,children:r.children},t===null?(i=ml(r,i),i.ref=e.ref,e.child=i,i.return=e,e=i):(i=yn(t.child,r),i.ref=e.ref,e.child=i,i.return=e,e=i),e;case 22:return Mm(t,e,i);case 24:return Ci(e),r=fe($t),t===null?(s=Tc(),s===null&&(s=Ot,u=wc(),s.pooledCache=u,u.refCount++,u!==null&&(s.pooledCacheLanes|=i),s=u),e.memoizedState={parent:r,cache:s},Mc(e),Un(e,$t,s)):((t.lanes&i)!==0&&(jc(t,e),Sr(e,null,null,i),br()),s=t.memoizedState,u=e.memoizedState,s.parent!==r?(s={parent:r,cache:r},e.memoizedState=s,e.lanes===0&&(e.memoizedState=e.updateQueue.baseState=s),Un(e,$t,r)):(r=u.cache,Un(e,$t,r),r!==s.cache&&Ac(e,[$t],i,!0))),re(t,e,e.pendingProps.children,i),e.child;case 29:throw e.pendingProps}throw Error(l(156,e.tag))}function Tn(t){t.flags|=4}function Pm(t,e){if(e.type!=="stylesheet"||(e.state.loading&4)!==0)t.flags&=-16777217;else if(t.flags|=16777216,!qp(e)){if(e=_e.current,e!==null&&((yt&4194048)===yt?nn!==null:(yt&62914560)!==yt&&(yt&536870912)===0||e!==nn))throw xr=Ec,v0;t.flags|=8192}}function pl(t,e){e!==null&&(t.flags|=4),t.flags&16384&&(e=t.tag!==22?mh():536870912,t.lanes|=e,ya|=e)}function jr(t,e){if(!bt)switch(t.tailMode){case"hidden":e=t.tail;for(var i=null;e!==null;)e.alternate!==null&&(i=e),e=e.sibling;i===null?t.tail=null:i.sibling=null;break;case"collapsed":i=t.tail;for(var r=null;i!==null;)i.alternate!==null&&(r=i),i=i.sibling;r===null?e||t.tail===null?t.tail=null:t.tail.sibling=null:r.sibling=null}}function zt(t){var e=t.alternate!==null&&t.alternate.child===t.child,i=0,r=0;if(e)for(var s=t.child;s!==null;)i|=s.lanes|s.childLanes,r|=s.subtreeFlags&65011712,r|=s.flags&65011712,s.return=t,s=s.sibling;else for(s=t.child;s!==null;)i|=s.lanes|s.childLanes,r|=s.subtreeFlags,r|=s.flags,s.return=t,s=s.sibling;return t.subtreeFlags|=r,t.childLanes=i,e}function Wb(t,e,i){var r=e.pendingProps;switch(xc(e),e.tag){case 31:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return zt(e),null;case 1:return zt(e),null;case 3:return i=e.stateNode,r=null,t!==null&&(r=t.memoizedState.cache),e.memoizedState.cache!==r&&(e.flags|=2048),Sn($t),ce(),i.pendingContext&&(i.context=i.pendingContext,i.pendingContext=null),(t===null||t.child===null)&&(fr(e)?Tn(e):t===null||t.memoizedState.isDehydrated&&(e.flags&256)===0||(e.flags|=1024,m0())),zt(e),null;case 26:return i=e.memoizedState,t===null?(Tn(e),i!==null?(zt(e),Pm(e,i)):(zt(e),e.flags&=-16777217)):i?i!==t.memoizedState?(Tn(e),zt(e),Pm(e,i)):(zt(e),e.flags&=-16777217):(t.memoizedProps!==r&&Tn(e),zt(e),e.flags&=-16777217),null;case 27:mn(e),i=it.current;var s=e.type;if(t!==null&&e.stateNode!=null)t.memoizedProps!==r&&Tn(e);else{if(!r){if(e.stateNode===null)throw Error(l(166));return zt(e),null}t=et.current,fr(e)?d0(e):(t=Pp(s,r,i),e.stateNode=t,Tn(e))}return zt(e),null;case 5:if(mn(e),i=e.type,t!==null&&e.stateNode!=null)t.memoizedProps!==r&&Tn(e);else{if(!r){if(e.stateNode===null)throw Error(l(166));return zt(e),null}if(t=et.current,fr(e))d0(e);else{switch(s=jl(it.current),t){case 1:t=s.createElementNS("http://www.w3.org/2000/svg",i);break;case 2:t=s.createElementNS("http://www.w3.org/1998/Math/MathML",i);break;default:switch(i){case"svg":t=s.createElementNS("http://www.w3.org/2000/svg",i);break;case"math":t=s.createElementNS("http://www.w3.org/1998/Math/MathML",i);break;case"script":t=s.createElement("div"),t.innerHTML="<script><\/script>",t=t.removeChild(t.firstChild);break;case"select":t=typeof r.is=="string"?s.createElement("select",{is:r.is}):s.createElement("select"),r.multiple?t.multiple=!0:r.size&&(t.size=r.size);break;default:t=typeof r.is=="string"?s.createElement(i,{is:r.is}):s.createElement(i)}}t[ue]=e,t[ge]=r;t:for(s=e.child;s!==null;){if(s.tag===5||s.tag===6)t.appendChild(s.stateNode);else if(s.tag!==4&&s.tag!==27&&s.child!==null){s.child.return=s,s=s.child;continue}if(s===e)break t;for(;s.sibling===null;){if(s.return===null||s.return===e)break t;s=s.return}s.sibling.return=s.return,s=s.sibling}e.stateNode=t;t:switch(le(t,i,r),i){case"button":case"input":case"select":case"textarea":t=!!r.autoFocus;break t;case"img":t=!0;break t;default:t=!1}t&&Tn(e)}}return zt(e),e.flags&=-16777217,null;case 6:if(t&&e.stateNode!=null)t.memoizedProps!==r&&Tn(e);else{if(typeof r!="string"&&e.stateNode===null)throw Error(l(166));if(t=it.current,fr(e)){if(t=e.stateNode,i=e.memoizedProps,r=null,s=me,s!==null)switch(s.tag){case 27:case 5:r=s.memoizedProps}t[ue]=e,t=!!(t.nodeValue===i||r!==null&&r.suppressHydrationWarning===!0||Op(t.nodeValue,i)),t||Ai(e)}else t=jl(t).createTextNode(r),t[ue]=e,e.stateNode=t}return zt(e),null;case 13:if(r=e.memoizedState,t===null||t.memoizedState!==null&&t.memoizedState.dehydrated!==null){if(s=fr(e),r!==null&&r.dehydrated!==null){if(t===null){if(!s)throw Error(l(318));if(s=e.memoizedState,s=s!==null?s.dehydrated:null,!s)throw Error(l(317));s[ue]=e}else dr(),(e.flags&128)===0&&(e.memoizedState=null),e.flags|=4;zt(e),s=!1}else s=m0(),t!==null&&t.memoizedState!==null&&(t.memoizedState.hydrationErrors=s),s=!0;if(!s)return e.flags&256?(wn(e),e):(wn(e),null)}if(wn(e),(e.flags&128)!==0)return e.lanes=i,e;if(i=r!==null,t=t!==null&&t.memoizedState!==null,i){r=e.child,s=null,r.alternate!==null&&r.alternate.memoizedState!==null&&r.alternate.memoizedState.cachePool!==null&&(s=r.alternate.memoizedState.cachePool.pool);var u=null;r.memoizedState!==null&&r.memoizedState.cachePool!==null&&(u=r.memoizedState.cachePool.pool),u!==s&&(r.flags|=2048)}return i!==t&&i&&(e.child.flags|=8192),pl(e,e.updateQueue),zt(e),null;case 4:return ce(),t===null&&Du(e.stateNode.containerInfo),zt(e),null;case 10:return Sn(e.type),zt(e),null;case 19:if($(Qt),s=e.memoizedState,s===null)return zt(e),null;if(r=(e.flags&128)!==0,u=s.rendering,u===null)if(r)jr(s,!1);else{if(Ut!==0||t!==null&&(t.flags&128)!==0)for(t=e.child;t!==null;){if(u=ul(t),u!==null){for(e.flags|=128,jr(s,!1),t=u.updateQueue,e.updateQueue=t,pl(e,t),e.subtreeFlags=0,t=i,i=e.child;i!==null;)u0(i,t),i=i.sibling;return Q(Qt,Qt.current&1|2),e.child}t=t.sibling}s.tail!==null&&tn()>xl&&(e.flags|=128,r=!0,jr(s,!1),e.lanes=4194304)}else{if(!r)if(t=ul(u),t!==null){if(e.flags|=128,r=!0,t=t.updateQueue,e.updateQueue=t,pl(e,t),jr(s,!0),s.tail===null&&s.tailMode==="hidden"&&!u.alternate&&!bt)return zt(e),null}else 2*tn()-s.renderingStartTime>xl&&i!==536870912&&(e.flags|=128,r=!0,jr(s,!1),e.lanes=4194304);s.isBackwards?(u.sibling=e.child,e.child=u):(t=s.last,t!==null?t.sibling=u:e.child=u,s.last=u)}return s.tail!==null?(e=s.tail,s.rendering=e,s.tail=e.sibling,s.renderingStartTime=tn(),e.sibling=null,t=Qt.current,Q(Qt,r?t&1|2:t&1),e):(zt(e),null);case 22:case 23:return wn(e),Lc(),r=e.memoizedState!==null,t!==null?t.memoizedState!==null!==r&&(e.flags|=8192):r&&(e.flags|=8192),r?(i&536870912)!==0&&(e.flags&128)===0&&(zt(e),e.subtreeFlags&6&&(e.flags|=8192)):zt(e),i=e.updateQueue,i!==null&&pl(e,i.retryQueue),i=null,t!==null&&t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(i=t.memoizedState.cachePool.pool),r=null,e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(r=e.memoizedState.cachePool.pool),r!==i&&(e.flags|=2048),t!==null&&$(Ti),null;case 24:return i=null,t!==null&&(i=t.memoizedState.cache),e.memoizedState.cache!==i&&(e.flags|=2048),Sn($t),zt(e),null;case 25:return null;case 30:return null}throw Error(l(156,e.tag))}function t2(t,e){switch(xc(e),e.tag){case 1:return t=e.flags,t&65536?(e.flags=t&-65537|128,e):null;case 3:return Sn($t),ce(),t=e.flags,(t&65536)!==0&&(t&128)===0?(e.flags=t&-65537|128,e):null;case 26:case 27:case 5:return mn(e),null;case 13:if(wn(e),t=e.memoizedState,t!==null&&t.dehydrated!==null){if(e.alternate===null)throw Error(l(340));dr()}return t=e.flags,t&65536?(e.flags=t&-65537|128,e):null;case 19:return $(Qt),null;case 4:return ce(),null;case 10:return Sn(e.type),null;case 22:case 23:return wn(e),Lc(),t!==null&&$(Ti),t=e.flags,t&65536?(e.flags=t&-65537|128,e):null;case 24:return Sn($t),null;case 25:return null;default:return null}}function Vm(t,e){switch(xc(e),e.tag){case 3:Sn($t),ce();break;case 26:case 27:case 5:mn(e);break;case 4:ce();break;case 13:wn(e);break;case 19:$(Qt);break;case 10:Sn(e.type);break;case 22:case 23:wn(e),Lc(),t!==null&&$(Ti);break;case 24:Sn($t)}}function Or(t,e){try{var i=e.updateQueue,r=i!==null?i.lastEffect:null;if(r!==null){var s=r.next;i=s;do{if((i.tag&t)===t){r=void 0;var u=i.create,y=i.inst;r=u(),y.destroy=r}i=i.next}while(i!==s)}}catch(v){jt(e,e.return,v)}}function Fn(t,e,i){try{var r=e.updateQueue,s=r!==null?r.lastEffect:null;if(s!==null){var u=s.next;r=u;do{if((r.tag&t)===t){var y=r.inst,v=y.destroy;if(v!==void 0){y.destroy=void 0,s=e;var w=i,L=v;try{L()}catch(N){jt(s,w,N)}}}r=r.next}while(r!==u)}}catch(N){jt(e,e.return,N)}}function Um(t){var e=t.updateQueue;if(e!==null){var i=t.stateNode;try{T0(e,i)}catch(r){jt(t,t.return,r)}}}function Nm(t,e,i){i.props=Mi(t.type,t.memoizedProps),i.state=t.memoizedState;try{i.componentWillUnmount()}catch(r){jt(t,e,r)}}function Dr(t,e){try{var i=t.ref;if(i!==null){switch(t.tag){case 26:case 27:case 5:var r=t.stateNode;break;case 30:r=t.stateNode;break;default:r=t.stateNode}typeof i=="function"?t.refCleanup=i(r):i.current=r}}catch(s){jt(t,e,s)}}function an(t,e){var i=t.ref,r=t.refCleanup;if(i!==null)if(typeof r=="function")try{r()}catch(s){jt(t,e,s)}finally{t.refCleanup=null,t=t.alternate,t!=null&&(t.refCleanup=null)}else if(typeof i=="function")try{i(null)}catch(s){jt(t,e,s)}else i.current=null}function _m(t){var e=t.type,i=t.memoizedProps,r=t.stateNode;try{t:switch(e){case"button":case"input":case"select":case"textarea":i.autoFocus&&r.focus();break t;case"img":i.src?r.src=i.src:i.srcSet&&(r.srcset=i.srcSet)}}catch(s){jt(t,t.return,s)}}function ou(t,e,i){try{var r=t.stateNode;S2(r,t.type,i,e),r[ge]=e}catch(s){jt(t,t.return,s)}}function Hm(t){return t.tag===5||t.tag===3||t.tag===26||t.tag===27&&Wn(t.type)||t.tag===4}function lu(t){t:for(;;){for(;t.sibling===null;){if(t.return===null||Hm(t.return))return null;t=t.return}for(t.sibling.return=t.return,t=t.sibling;t.tag!==5&&t.tag!==6&&t.tag!==18;){if(t.tag===27&&Wn(t.type)||t.flags&2||t.child===null||t.tag===4)continue t;t.child.return=t,t=t.child}if(!(t.flags&2))return t.stateNode}}function su(t,e,i){var r=t.tag;if(r===5||r===6)t=t.stateNode,e?(i.nodeType===9?i.body:i.nodeName==="HTML"?i.ownerDocument.body:i).insertBefore(t,e):(e=i.nodeType===9?i.body:i.nodeName==="HTML"?i.ownerDocument.body:i,e.appendChild(t),i=i._reactRootContainer,i!=null||e.onclick!==null||(e.onclick=Ml));else if(r!==4&&(r===27&&Wn(t.type)&&(i=t.stateNode,e=null),t=t.child,t!==null))for(su(t,e,i),t=t.sibling;t!==null;)su(t,e,i),t=t.sibling}function gl(t,e,i){var r=t.tag;if(r===5||r===6)t=t.stateNode,e?i.insertBefore(t,e):i.appendChild(t);else if(r!==4&&(r===27&&Wn(t.type)&&(i=t.stateNode),t=t.child,t!==null))for(gl(t,e,i),t=t.sibling;t!==null;)gl(t,e,i),t=t.sibling}function Gm(t){var e=t.stateNode,i=t.memoizedProps;try{for(var r=t.type,s=e.attributes;s.length;)e.removeAttributeNode(s[0]);le(e,r,i),e[ue]=t,e[ge]=i}catch(u){jt(t,t.return,u)}}var En=!1,Gt=!1,cu=!1,Im=typeof WeakSet=="function"?WeakSet:Set,te=null;function e2(t,e){if(t=t.containerInfo,Bu=zl,t=t0(t),lc(t)){if("selectionStart"in t)var i={start:t.selectionStart,end:t.selectionEnd};else t:{i=(i=t.ownerDocument)&&i.defaultView||window;var r=i.getSelection&&i.getSelection();if(r&&r.rangeCount!==0){i=r.anchorNode;var s=r.anchorOffset,u=r.focusNode;r=r.focusOffset;try{i.nodeType,u.nodeType}catch{i=null;break t}var y=0,v=-1,w=-1,L=0,N=0,I=t,B=null;e:for(;;){for(var k;I!==i||s!==0&&I.nodeType!==3||(v=y+s),I!==u||r!==0&&I.nodeType!==3||(w=y+r),I.nodeType===3&&(y+=I.nodeValue.length),(k=I.firstChild)!==null;)B=I,I=k;for(;;){if(I===t)break e;if(B===i&&++L===s&&(v=y),B===u&&++N===r&&(w=y),(k=I.nextSibling)!==null)break;I=B,B=I.parentNode}I=k}i=v===-1||w===-1?null:{start:v,end:w}}else i=null}i=i||{start:0,end:0}}else i=null;for(zu={focusedElem:t,selectionRange:i},zl=!1,te=e;te!==null;)if(e=te,t=e.child,(e.subtreeFlags&1024)!==0&&t!==null)t.return=e,te=t;else for(;te!==null;){switch(e=te,u=e.alternate,t=e.flags,e.tag){case 0:break;case 11:case 15:break;case 1:if((t&1024)!==0&&u!==null){t=void 0,i=e,s=u.memoizedProps,u=u.memoizedState,r=i.stateNode;try{var rt=Mi(i.type,s,i.elementType===i.type);t=r.getSnapshotBeforeUpdate(rt,u),r.__reactInternalSnapshotBeforeUpdate=t}catch(nt){jt(i,i.return,nt)}}break;case 3:if((t&1024)!==0){if(t=e.stateNode.containerInfo,i=t.nodeType,i===9)Vu(t);else if(i===1)switch(t.nodeName){case"HEAD":case"HTML":case"BODY":Vu(t);break;default:t.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((t&1024)!==0)throw Error(l(163))}if(t=e.sibling,t!==null){t.return=e.return,te=t;break}te=e.return}}function qm(t,e,i){var r=i.flags;switch(i.tag){case 0:case 11:case 15:Yn(t,i),r&4&&Or(5,i);break;case 1:if(Yn(t,i),r&4)if(t=i.stateNode,e===null)try{t.componentDidMount()}catch(y){jt(i,i.return,y)}else{var s=Mi(i.type,e.memoizedProps);e=e.memoizedState;try{t.componentDidUpdate(s,e,t.__reactInternalSnapshotBeforeUpdate)}catch(y){jt(i,i.return,y)}}r&64&&Um(i),r&512&&Dr(i,i.return);break;case 3:if(Yn(t,i),r&64&&(t=i.updateQueue,t!==null)){if(e=null,i.child!==null)switch(i.child.tag){case 27:case 5:e=i.child.stateNode;break;case 1:e=i.child.stateNode}try{T0(t,e)}catch(y){jt(i,i.return,y)}}break;case 27:e===null&&r&4&&Gm(i);case 26:case 5:Yn(t,i),e===null&&r&4&&_m(i),r&512&&Dr(i,i.return);break;case 12:Yn(t,i);break;case 13:Yn(t,i),r&4&&Xm(t,i),r&64&&(t=i.memoizedState,t!==null&&(t=t.dehydrated,t!==null&&(i=u2.bind(null,i),j2(t,i))));break;case 22:if(r=i.memoizedState!==null||En,!r){e=e!==null&&e.memoizedState!==null||Gt,s=En;var u=Gt;En=r,(Gt=e)&&!u?Xn(t,i,(i.subtreeFlags&8772)!==0):Yn(t,i),En=s,Gt=u}break;case 30:break;default:Yn(t,i)}}function Fm(t){var e=t.alternate;e!==null&&(t.alternate=null,Fm(e)),t.child=null,t.deletions=null,t.sibling=null,t.tag===5&&(e=t.stateNode,e!==null&&Gs(e)),t.stateNode=null,t.return=null,t.dependencies=null,t.memoizedProps=null,t.memoizedState=null,t.pendingProps=null,t.stateNode=null,t.updateQueue=null}var Rt=null,ve=!1;function Mn(t,e,i){for(i=i.child;i!==null;)Ym(t,e,i),i=i.sibling}function Ym(t,e,i){if(Ae&&typeof Ae.onCommitFiberUnmount=="function")try{Ae.onCommitFiberUnmount(Za,i)}catch{}switch(i.tag){case 26:Gt||an(i,e),Mn(t,e,i),i.memoizedState?i.memoizedState.count--:i.stateNode&&(i=i.stateNode,i.parentNode.removeChild(i));break;case 27:Gt||an(i,e);var r=Rt,s=ve;Wn(i.type)&&(Rt=i.stateNode,ve=!1),Mn(t,e,i),Nr(i.stateNode),Rt=r,ve=s;break;case 5:Gt||an(i,e);case 6:if(r=Rt,s=ve,Rt=null,Mn(t,e,i),Rt=r,ve=s,Rt!==null)if(ve)try{(Rt.nodeType===9?Rt.body:Rt.nodeName==="HTML"?Rt.ownerDocument.body:Rt).removeChild(i.stateNode)}catch(u){jt(i,e,u)}else try{Rt.removeChild(i.stateNode)}catch(u){jt(i,e,u)}break;case 18:Rt!==null&&(ve?(t=Rt,zp(t.nodeType===9?t.body:t.nodeName==="HTML"?t.ownerDocument.body:t,i.stateNode),Xr(t)):zp(Rt,i.stateNode));break;case 4:r=Rt,s=ve,Rt=i.stateNode.containerInfo,ve=!0,Mn(t,e,i),Rt=r,ve=s;break;case 0:case 11:case 14:case 15:Gt||Fn(2,i,e),Gt||Fn(4,i,e),Mn(t,e,i);break;case 1:Gt||(an(i,e),r=i.stateNode,typeof r.componentWillUnmount=="function"&&Nm(i,e,r)),Mn(t,e,i);break;case 21:Mn(t,e,i);break;case 22:Gt=(r=Gt)||i.memoizedState!==null,Mn(t,e,i),Gt=r;break;default:Mn(t,e,i)}}function Xm(t,e){if(e.memoizedState===null&&(t=e.alternate,t!==null&&(t=t.memoizedState,t!==null&&(t=t.dehydrated,t!==null))))try{Xr(t)}catch(i){jt(e,e.return,i)}}function n2(t){switch(t.tag){case 13:case 19:var e=t.stateNode;return e===null&&(e=t.stateNode=new Im),e;case 22:return t=t.stateNode,e=t._retryCache,e===null&&(e=t._retryCache=new Im),e;default:throw Error(l(435,t.tag))}}function uu(t,e){var i=n2(t);e.forEach(function(r){var s=f2.bind(null,t,r);i.has(r)||(i.add(r),r.then(s,s))})}function Ee(t,e){var i=e.deletions;if(i!==null)for(var r=0;r<i.length;r++){var s=i[r],u=t,y=e,v=y;t:for(;v!==null;){switch(v.tag){case 27:if(Wn(v.type)){Rt=v.stateNode,ve=!1;break t}break;case 5:Rt=v.stateNode,ve=!1;break t;case 3:case 4:Rt=v.stateNode.containerInfo,ve=!0;break t}v=v.return}if(Rt===null)throw Error(l(160));Ym(u,y,s),Rt=null,ve=!1,u=s.alternate,u!==null&&(u.return=null),s.return=null}if(e.subtreeFlags&13878)for(e=e.child;e!==null;)Km(e,t),e=e.sibling}var $e=null;function Km(t,e){var i=t.alternate,r=t.flags;switch(t.tag){case 0:case 11:case 14:case 15:Ee(e,t),Me(t),r&4&&(Fn(3,t,t.return),Or(3,t),Fn(5,t,t.return));break;case 1:Ee(e,t),Me(t),r&512&&(Gt||i===null||an(i,i.return)),r&64&&En&&(t=t.updateQueue,t!==null&&(r=t.callbacks,r!==null&&(i=t.shared.hiddenCallbacks,t.shared.hiddenCallbacks=i===null?r:i.concat(r))));break;case 26:var s=$e;if(Ee(e,t),Me(t),r&512&&(Gt||i===null||an(i,i.return)),r&4){var u=i!==null?i.memoizedState:null;if(r=t.memoizedState,i===null)if(r===null)if(t.stateNode===null){t:{r=t.type,i=t.memoizedProps,s=s.ownerDocument||s;e:switch(r){case"title":u=s.getElementsByTagName("title")[0],(!u||u[tr]||u[ue]||u.namespaceURI==="http://www.w3.org/2000/svg"||u.hasAttribute("itemprop"))&&(u=s.createElement(r),s.head.insertBefore(u,s.querySelector("head > title"))),le(u,r,i),u[ue]=t,Jt(u),r=u;break t;case"link":var y=Gp("link","href",s).get(r+(i.href||""));if(y){for(var v=0;v<y.length;v++)if(u=y[v],u.getAttribute("href")===(i.href==null||i.href===""?null:i.href)&&u.getAttribute("rel")===(i.rel==null?null:i.rel)&&u.getAttribute("title")===(i.title==null?null:i.title)&&u.getAttribute("crossorigin")===(i.crossOrigin==null?null:i.crossOrigin)){y.splice(v,1);break e}}u=s.createElement(r),le(u,r,i),s.head.appendChild(u);break;case"meta":if(y=Gp("meta","content",s).get(r+(i.content||""))){for(v=0;v<y.length;v++)if(u=y[v],u.getAttribute("content")===(i.content==null?null:""+i.content)&&u.getAttribute("name")===(i.name==null?null:i.name)&&u.getAttribute("property")===(i.property==null?null:i.property)&&u.getAttribute("http-equiv")===(i.httpEquiv==null?null:i.httpEquiv)&&u.getAttribute("charset")===(i.charSet==null?null:i.charSet)){y.splice(v,1);break e}}u=s.createElement(r),le(u,r,i),s.head.appendChild(u);break;default:throw Error(l(468,r))}u[ue]=t,Jt(u),r=u}t.stateNode=r}else Ip(s,t.type,t.stateNode);else t.stateNode=Hp(s,r,t.memoizedProps);else u!==r?(u===null?i.stateNode!==null&&(i=i.stateNode,i.parentNode.removeChild(i)):u.count--,r===null?Ip(s,t.type,t.stateNode):Hp(s,r,t.memoizedProps)):r===null&&t.stateNode!==null&&ou(t,t.memoizedProps,i.memoizedProps)}break;case 27:Ee(e,t),Me(t),r&512&&(Gt||i===null||an(i,i.return)),i!==null&&r&4&&ou(t,t.memoizedProps,i.memoizedProps);break;case 5:if(Ee(e,t),Me(t),r&512&&(Gt||i===null||an(i,i.return)),t.flags&32){s=t.stateNode;try{$i(s,"")}catch(k){jt(t,t.return,k)}}r&4&&t.stateNode!=null&&(s=t.memoizedProps,ou(t,s,i!==null?i.memoizedProps:s)),r&1024&&(cu=!0);break;case 6:if(Ee(e,t),Me(t),r&4){if(t.stateNode===null)throw Error(l(162));r=t.memoizedProps,i=t.stateNode;try{i.nodeValue=r}catch(k){jt(t,t.return,k)}}break;case 3:if(Rl=null,s=$e,$e=Ol(e.containerInfo),Ee(e,t),$e=s,Me(t),r&4&&i!==null&&i.memoizedState.isDehydrated)try{Xr(e.containerInfo)}catch(k){jt(t,t.return,k)}cu&&(cu=!1,$m(t));break;case 4:r=$e,$e=Ol(t.stateNode.containerInfo),Ee(e,t),Me(t),$e=r;break;case 12:Ee(e,t),Me(t);break;case 13:Ee(e,t),Me(t),t.child.flags&8192&&t.memoizedState!==null!=(i!==null&&i.memoizedState!==null)&&(gu=tn()),r&4&&(r=t.updateQueue,r!==null&&(t.updateQueue=null,uu(t,r)));break;case 22:s=t.memoizedState!==null;var w=i!==null&&i.memoizedState!==null,L=En,N=Gt;if(En=L||s,Gt=N||w,Ee(e,t),Gt=N,En=L,Me(t),r&8192)t:for(e=t.stateNode,e._visibility=s?e._visibility&-2:e._visibility|1,s&&(i===null||w||En||Gt||ji(t)),i=null,e=t;;){if(e.tag===5||e.tag===26){if(i===null){w=i=e;try{if(u=w.stateNode,s)y=u.style,typeof y.setProperty=="function"?y.setProperty("display","none","important"):y.display="none";else{v=w.stateNode;var I=w.memoizedProps.style,B=I!=null&&I.hasOwnProperty("display")?I.display:null;v.style.display=B==null||typeof B=="boolean"?"":(""+B).trim()}}catch(k){jt(w,w.return,k)}}}else if(e.tag===6){if(i===null){w=e;try{w.stateNode.nodeValue=s?"":w.memoizedProps}catch(k){jt(w,w.return,k)}}}else if((e.tag!==22&&e.tag!==23||e.memoizedState===null||e===t)&&e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break t;for(;e.sibling===null;){if(e.return===null||e.return===t)break t;i===e&&(i=null),e=e.return}i===e&&(i=null),e.sibling.return=e.return,e=e.sibling}r&4&&(r=t.updateQueue,r!==null&&(i=r.retryQueue,i!==null&&(r.retryQueue=null,uu(t,i))));break;case 19:Ee(e,t),Me(t),r&4&&(r=t.updateQueue,r!==null&&(t.updateQueue=null,uu(t,r)));break;case 30:break;case 21:break;default:Ee(e,t),Me(t)}}function Me(t){var e=t.flags;if(e&2){try{for(var i,r=t.return;r!==null;){if(Hm(r)){i=r;break}r=r.return}if(i==null)throw Error(l(160));switch(i.tag){case 27:var s=i.stateNode,u=lu(t);gl(t,u,s);break;case 5:var y=i.stateNode;i.flags&32&&($i(y,""),i.flags&=-33);var v=lu(t);gl(t,v,y);break;case 3:case 4:var w=i.stateNode.containerInfo,L=lu(t);su(t,L,w);break;default:throw Error(l(161))}}catch(N){jt(t,t.return,N)}t.flags&=-3}e&4096&&(t.flags&=-4097)}function $m(t){if(t.subtreeFlags&1024)for(t=t.child;t!==null;){var e=t;$m(e),e.tag===5&&e.flags&1024&&e.stateNode.reset(),t=t.sibling}}function Yn(t,e){if(e.subtreeFlags&8772)for(e=e.child;e!==null;)qm(t,e.alternate,e),e=e.sibling}function ji(t){for(t=t.child;t!==null;){var e=t;switch(e.tag){case 0:case 11:case 14:case 15:Fn(4,e,e.return),ji(e);break;case 1:an(e,e.return);var i=e.stateNode;typeof i.componentWillUnmount=="function"&&Nm(e,e.return,i),ji(e);break;case 27:Nr(e.stateNode);case 26:case 5:an(e,e.return),ji(e);break;case 22:e.memoizedState===null&&ji(e);break;case 30:ji(e);break;default:ji(e)}t=t.sibling}}function Xn(t,e,i){for(i=i&&(e.subtreeFlags&8772)!==0,e=e.child;e!==null;){var r=e.alternate,s=t,u=e,y=u.flags;switch(u.tag){case 0:case 11:case 15:Xn(s,u,i),Or(4,u);break;case 1:if(Xn(s,u,i),r=u,s=r.stateNode,typeof s.componentDidMount=="function")try{s.componentDidMount()}catch(L){jt(r,r.return,L)}if(r=u,s=r.updateQueue,s!==null){var v=r.stateNode;try{var w=s.shared.hiddenCallbacks;if(w!==null)for(s.shared.hiddenCallbacks=null,s=0;s<w.length;s++)C0(w[s],v)}catch(L){jt(r,r.return,L)}}i&&y&64&&Um(u),Dr(u,u.return);break;case 27:Gm(u);case 26:case 5:Xn(s,u,i),i&&r===null&&y&4&&_m(u),Dr(u,u.return);break;case 12:Xn(s,u,i);break;case 13:Xn(s,u,i),i&&y&4&&Xm(s,u);break;case 22:u.memoizedState===null&&Xn(s,u,i),Dr(u,u.return);break;case 30:break;default:Xn(s,u,i)}e=e.sibling}}function fu(t,e){var i=null;t!==null&&t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(i=t.memoizedState.cachePool.pool),t=null,e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(t=e.memoizedState.cachePool.pool),t!==i&&(t!=null&&t.refCount++,i!=null&&pr(i))}function du(t,e){t=null,e.alternate!==null&&(t=e.alternate.memoizedState.cache),e=e.memoizedState.cache,e!==t&&(e.refCount++,t!=null&&pr(t))}function rn(t,e,i,r){if(e.subtreeFlags&10256)for(e=e.child;e!==null;)Qm(t,e,i,r),e=e.sibling}function Qm(t,e,i,r){var s=e.flags;switch(e.tag){case 0:case 11:case 15:rn(t,e,i,r),s&2048&&Or(9,e);break;case 1:rn(t,e,i,r);break;case 3:rn(t,e,i,r),s&2048&&(t=null,e.alternate!==null&&(t=e.alternate.memoizedState.cache),e=e.memoizedState.cache,e!==t&&(e.refCount++,t!=null&&pr(t)));break;case 12:if(s&2048){rn(t,e,i,r),t=e.stateNode;try{var u=e.memoizedProps,y=u.id,v=u.onPostCommit;typeof v=="function"&&v(y,e.alternate===null?"mount":"update",t.passiveEffectDuration,-0)}catch(w){jt(e,e.return,w)}}else rn(t,e,i,r);break;case 13:rn(t,e,i,r);break;case 23:break;case 22:u=e.stateNode,y=e.alternate,e.memoizedState!==null?u._visibility&2?rn(t,e,i,r):Rr(t,e):u._visibility&2?rn(t,e,i,r):(u._visibility|=2,ma(t,e,i,r,(e.subtreeFlags&10256)!==0)),s&2048&&fu(y,e);break;case 24:rn(t,e,i,r),s&2048&&du(e.alternate,e);break;default:rn(t,e,i,r)}}function ma(t,e,i,r,s){for(s=s&&(e.subtreeFlags&10256)!==0,e=e.child;e!==null;){var u=t,y=e,v=i,w=r,L=y.flags;switch(y.tag){case 0:case 11:case 15:ma(u,y,v,w,s),Or(8,y);break;case 23:break;case 22:var N=y.stateNode;y.memoizedState!==null?N._visibility&2?ma(u,y,v,w,s):Rr(u,y):(N._visibility|=2,ma(u,y,v,w,s)),s&&L&2048&&fu(y.alternate,y);break;case 24:ma(u,y,v,w,s),s&&L&2048&&du(y.alternate,y);break;default:ma(u,y,v,w,s)}e=e.sibling}}function Rr(t,e){if(e.subtreeFlags&10256)for(e=e.child;e!==null;){var i=t,r=e,s=r.flags;switch(r.tag){case 22:Rr(i,r),s&2048&&fu(r.alternate,r);break;case 24:Rr(i,r),s&2048&&du(r.alternate,r);break;default:Rr(i,r)}e=e.sibling}}var Lr=8192;function pa(t){if(t.subtreeFlags&Lr)for(t=t.child;t!==null;)Zm(t),t=t.sibling}function Zm(t){switch(t.tag){case 26:pa(t),t.flags&Lr&&t.memoizedState!==null&&H2($e,t.memoizedState,t.memoizedProps);break;case 5:pa(t);break;case 3:case 4:var e=$e;$e=Ol(t.stateNode.containerInfo),pa(t),$e=e;break;case 22:t.memoizedState===null&&(e=t.alternate,e!==null&&e.memoizedState!==null?(e=Lr,Lr=16777216,pa(t),Lr=e):pa(t));break;default:pa(t)}}function Jm(t){var e=t.alternate;if(e!==null&&(t=e.child,t!==null)){e.child=null;do e=t.sibling,t.sibling=null,t=e;while(t!==null)}}function Br(t){var e=t.deletions;if((t.flags&16)!==0){if(e!==null)for(var i=0;i<e.length;i++){var r=e[i];te=r,tp(r,t)}Jm(t)}if(t.subtreeFlags&10256)for(t=t.child;t!==null;)Wm(t),t=t.sibling}function Wm(t){switch(t.tag){case 0:case 11:case 15:Br(t),t.flags&2048&&Fn(9,t,t.return);break;case 3:Br(t);break;case 12:Br(t);break;case 22:var e=t.stateNode;t.memoizedState!==null&&e._visibility&2&&(t.return===null||t.return.tag!==13)?(e._visibility&=-3,yl(t)):Br(t);break;default:Br(t)}}function yl(t){var e=t.deletions;if((t.flags&16)!==0){if(e!==null)for(var i=0;i<e.length;i++){var r=e[i];te=r,tp(r,t)}Jm(t)}for(t=t.child;t!==null;){switch(e=t,e.tag){case 0:case 11:case 15:Fn(8,e,e.return),yl(e);break;case 22:i=e.stateNode,i._visibility&2&&(i._visibility&=-3,yl(e));break;default:yl(e)}t=t.sibling}}function tp(t,e){for(;te!==null;){var i=te;switch(i.tag){case 0:case 11:case 15:Fn(8,i,e);break;case 23:case 22:if(i.memoizedState!==null&&i.memoizedState.cachePool!==null){var r=i.memoizedState.cachePool.pool;r!=null&&r.refCount++}break;case 24:pr(i.memoizedState.cache)}if(r=i.child,r!==null)r.return=i,te=r;else t:for(i=t;te!==null;){r=te;var s=r.sibling,u=r.return;if(Fm(r),r===i){te=null;break t}if(s!==null){s.return=u,te=s;break t}te=u}}}var i2={getCacheForType:function(t){var e=fe($t),i=e.data.get(t);return i===void 0&&(i=t(),e.data.set(t,i)),i}},a2=typeof WeakMap=="function"?WeakMap:Map,wt=0,Ot=null,mt=null,yt=0,Ct=0,je=null,Kn=!1,ga=!1,hu=!1,jn=0,Ut=0,$n=0,Oi=0,mu=0,He=0,ya=0,zr=null,be=null,pu=!1,gu=0,xl=1/0,vl=null,Qn=null,oe=0,Zn=null,xa=null,va=0,yu=0,xu=null,ep=null,kr=0,vu=null;function Oe(){if((wt&2)!==0&&yt!==0)return yt&-yt;if(U.T!==null){var t=oa;return t!==0?t:Eu()}return yh()}function np(){He===0&&(He=(yt&536870912)===0||bt?hh():536870912);var t=_e.current;return t!==null&&(t.flags|=32),He}function De(t,e,i){(t===Ot&&(Ct===2||Ct===9)||t.cancelPendingCommit!==null)&&(ba(t,0),Jn(t,yt,He,!1)),Wa(t,i),((wt&2)===0||t!==Ot)&&(t===Ot&&((wt&2)===0&&(Oi|=i),Ut===4&&Jn(t,yt,He,!1)),on(t))}function ip(t,e,i){if((wt&6)!==0)throw Error(l(327));var r=!i&&(e&124)===0&&(e&t.expiredLanes)===0||Ja(t,e),s=r?l2(t,e):Au(t,e,!0),u=r;do{if(s===0){ga&&!r&&Jn(t,e,0,!1);break}else{if(i=t.current.alternate,u&&!r2(i)){s=Au(t,e,!1),u=!1;continue}if(s===2){if(u=e,t.errorRecoveryDisabledLanes&u)var y=0;else y=t.pendingLanes&-536870913,y=y!==0?y:y&536870912?536870912:0;if(y!==0){e=y;t:{var v=t;s=zr;var w=v.current.memoizedState.isDehydrated;if(w&&(ba(v,y).flags|=256),y=Au(v,y,!1),y!==2){if(hu&&!w){v.errorRecoveryDisabledLanes|=u,Oi|=u,s=4;break t}u=be,be=s,u!==null&&(be===null?be=u:be.push.apply(be,u))}s=y}if(u=!1,s!==2)continue}}if(s===1){ba(t,0),Jn(t,e,0,!0);break}t:{switch(r=t,u=s,u){case 0:case 1:throw Error(l(345));case 4:if((e&4194048)!==e)break;case 6:Jn(r,e,He,!Kn);break t;case 2:be=null;break;case 3:case 5:break;default:throw Error(l(329))}if((e&62914560)===e&&(s=gu+300-tn(),10<s)){if(Jn(r,e,He,!Kn),Do(r,0,!0)!==0)break t;r.timeoutHandle=Lp(ap.bind(null,r,i,be,vl,pu,e,He,Oi,ya,Kn,u,2,-0,0),s);break t}ap(r,i,be,vl,pu,e,He,Oi,ya,Kn,u,0,-0,0)}}break}while(!0);on(t)}function ap(t,e,i,r,s,u,y,v,w,L,N,I,B,k){if(t.timeoutHandle=-1,I=e.subtreeFlags,(I&8192||(I&16785408)===16785408)&&(Gr={stylesheets:null,count:0,unsuspend:_2},Zm(e),I=G2(),I!==null)){t.cancelPendingCommit=I(fp.bind(null,t,e,u,i,r,s,y,v,w,N,1,B,k)),Jn(t,u,y,!L);return}fp(t,e,u,i,r,s,y,v,w)}function r2(t){for(var e=t;;){var i=e.tag;if((i===0||i===11||i===15)&&e.flags&16384&&(i=e.updateQueue,i!==null&&(i=i.stores,i!==null)))for(var r=0;r<i.length;r++){var s=i[r],u=s.getSnapshot;s=s.value;try{if(!Ce(u(),s))return!1}catch{return!1}}if(i=e.child,e.subtreeFlags&16384&&i!==null)i.return=e,e=i;else{if(e===t)break;for(;e.sibling===null;){if(e.return===null||e.return===t)return!0;e=e.return}e.sibling.return=e.return,e=e.sibling}}return!0}function Jn(t,e,i,r){e&=~mu,e&=~Oi,t.suspendedLanes|=e,t.pingedLanes&=~e,r&&(t.warmLanes|=e),r=t.expirationTimes;for(var s=e;0<s;){var u=31-we(s),y=1<<u;r[u]=-1,s&=~y}i!==0&&ph(t,i,e)}function bl(){return(wt&6)===0?(Pr(0),!1):!0}function bu(){if(mt!==null){if(Ct===0)var t=mt.return;else t=mt,bn=wi=null,Vc(t),da=null,Er=0,t=mt;for(;t!==null;)Vm(t.alternate,t),t=t.return;mt=null}}function ba(t,e){var i=t.timeoutHandle;i!==-1&&(t.timeoutHandle=-1,w2(i)),i=t.cancelPendingCommit,i!==null&&(t.cancelPendingCommit=null,i()),bu(),Ot=t,mt=i=yn(t.current,null),yt=e,Ct=0,je=null,Kn=!1,ga=Ja(t,e),hu=!1,ya=He=mu=Oi=$n=Ut=0,be=zr=null,pu=!1,(e&8)!==0&&(e|=e&32);var r=t.entangledLanes;if(r!==0)for(t=t.entanglements,r&=e;0<r;){var s=31-we(r),u=1<<s;e|=t[s],r&=~u}return jn=e,Go(),i}function rp(t,e){ft=null,U.H=ll,e===yr||e===Zo?(e=A0(),Ct=3):e===v0?(e=A0(),Ct=4):Ct=e===wm?8:e!==null&&typeof e=="object"&&typeof e.then=="function"?6:1,je=e,mt===null&&(Ut=1,dl(t,Pe(e,t.current)))}function op(){var t=U.H;return U.H=ll,t===null?ll:t}function lp(){var t=U.A;return U.A=i2,t}function Su(){Ut=4,Kn||(yt&4194048)!==yt&&_e.current!==null||(ga=!0),($n&134217727)===0&&(Oi&134217727)===0||Ot===null||Jn(Ot,yt,He,!1)}function Au(t,e,i){var r=wt;wt|=2;var s=op(),u=lp();(Ot!==t||yt!==e)&&(vl=null,ba(t,e)),e=!1;var y=Ut;t:do try{if(Ct!==0&&mt!==null){var v=mt,w=je;switch(Ct){case 8:bu(),y=6;break t;case 3:case 2:case 9:case 6:_e.current===null&&(e=!0);var L=Ct;if(Ct=0,je=null,Sa(t,v,w,L),i&&ga){y=0;break t}break;default:L=Ct,Ct=0,je=null,Sa(t,v,w,L)}}o2(),y=Ut;break}catch(N){rp(t,N)}while(!0);return e&&t.shellSuspendCounter++,bn=wi=null,wt=r,U.H=s,U.A=u,mt===null&&(Ot=null,yt=0,Go()),y}function o2(){for(;mt!==null;)sp(mt)}function l2(t,e){var i=wt;wt|=2;var r=op(),s=lp();Ot!==t||yt!==e?(vl=null,xl=tn()+500,ba(t,e)):ga=Ja(t,e);t:do try{if(Ct!==0&&mt!==null){e=mt;var u=je;e:switch(Ct){case 1:Ct=0,je=null,Sa(t,e,u,1);break;case 2:case 9:if(b0(u)){Ct=0,je=null,cp(e);break}e=function(){Ct!==2&&Ct!==9||Ot!==t||(Ct=7),on(t)},u.then(e,e);break t;case 3:Ct=7;break t;case 4:Ct=5;break t;case 7:b0(u)?(Ct=0,je=null,cp(e)):(Ct=0,je=null,Sa(t,e,u,7));break;case 5:var y=null;switch(mt.tag){case 26:y=mt.memoizedState;case 5:case 27:var v=mt;if(!y||qp(y)){Ct=0,je=null;var w=v.sibling;if(w!==null)mt=w;else{var L=v.return;L!==null?(mt=L,Sl(L)):mt=null}break e}}Ct=0,je=null,Sa(t,e,u,5);break;case 6:Ct=0,je=null,Sa(t,e,u,6);break;case 8:bu(),Ut=6;break t;default:throw Error(l(462))}}s2();break}catch(N){rp(t,N)}while(!0);return bn=wi=null,U.H=r,U.A=s,wt=i,mt!==null?0:(Ot=null,yt=0,Go(),Ut)}function s2(){for(;mt!==null&&!Dv();)sp(mt)}function sp(t){var e=km(t.alternate,t,jn);t.memoizedProps=t.pendingProps,e===null?Sl(t):mt=e}function cp(t){var e=t,i=e.alternate;switch(e.tag){case 15:case 0:e=Om(i,e,e.pendingProps,e.type,void 0,yt);break;case 11:e=Om(i,e,e.pendingProps,e.type.render,e.ref,yt);break;case 5:Vc(e);default:Vm(i,e),e=mt=u0(e,jn),e=km(i,e,jn)}t.memoizedProps=t.pendingProps,e===null?Sl(t):mt=e}function Sa(t,e,i,r){bn=wi=null,Vc(e),da=null,Er=0;var s=e.return;try{if(Zb(t,s,e,i,yt)){Ut=1,dl(t,Pe(i,t.current)),mt=null;return}}catch(u){if(s!==null)throw mt=s,u;Ut=1,dl(t,Pe(i,t.current)),mt=null;return}e.flags&32768?(bt||r===1?t=!0:ga||(yt&536870912)!==0?t=!1:(Kn=t=!0,(r===2||r===9||r===3||r===6)&&(r=_e.current,r!==null&&r.tag===13&&(r.flags|=16384))),up(e,t)):Sl(e)}function Sl(t){var e=t;do{if((e.flags&32768)!==0){up(e,Kn);return}t=e.return;var i=Wb(e.alternate,e,jn);if(i!==null){mt=i;return}if(e=e.sibling,e!==null){mt=e;return}mt=e=t}while(e!==null);Ut===0&&(Ut=5)}function up(t,e){do{var i=t2(t.alternate,t);if(i!==null){i.flags&=32767,mt=i;return}if(i=t.return,i!==null&&(i.flags|=32768,i.subtreeFlags=0,i.deletions=null),!e&&(t=t.sibling,t!==null)){mt=t;return}mt=t=i}while(t!==null);Ut=6,mt=null}function fp(t,e,i,r,s,u,y,v,w){t.cancelPendingCommit=null;do Al();while(oe!==0);if((wt&6)!==0)throw Error(l(327));if(e!==null){if(e===t.current)throw Error(l(177));if(u=e.lanes|e.childLanes,u|=dc,_v(t,i,u,y,v,w),t===Ot&&(mt=Ot=null,yt=0),xa=e,Zn=t,va=i,yu=u,xu=s,ep=r,(e.subtreeFlags&10256)!==0||(e.flags&10256)!==0?(t.callbackNode=null,t.callbackPriority=0,d2(Mo,function(){return gp(),null})):(t.callbackNode=null,t.callbackPriority=0),r=(e.flags&13878)!==0,(e.subtreeFlags&13878)!==0||r){r=U.T,U.T=null,s=Y.p,Y.p=2,y=wt,wt|=4;try{e2(t,e,i)}finally{wt=y,Y.p=s,U.T=r}}oe=1,dp(),hp(),mp()}}function dp(){if(oe===1){oe=0;var t=Zn,e=xa,i=(e.flags&13878)!==0;if((e.subtreeFlags&13878)!==0||i){i=U.T,U.T=null;var r=Y.p;Y.p=2;var s=wt;wt|=4;try{Km(e,t);var u=zu,y=t0(t.containerInfo),v=u.focusedElem,w=u.selectionRange;if(y!==v&&v&&v.ownerDocument&&Wh(v.ownerDocument.documentElement,v)){if(w!==null&&lc(v)){var L=w.start,N=w.end;if(N===void 0&&(N=L),"selectionStart"in v)v.selectionStart=L,v.selectionEnd=Math.min(N,v.value.length);else{var I=v.ownerDocument||document,B=I&&I.defaultView||window;if(B.getSelection){var k=B.getSelection(),rt=v.textContent.length,nt=Math.min(w.start,rt),Mt=w.end===void 0?nt:Math.min(w.end,rt);!k.extend&&nt>Mt&&(y=Mt,Mt=nt,nt=y);var j=Jh(v,nt),M=Jh(v,Mt);if(j&&M&&(k.rangeCount!==1||k.anchorNode!==j.node||k.anchorOffset!==j.offset||k.focusNode!==M.node||k.focusOffset!==M.offset)){var D=I.createRange();D.setStart(j.node,j.offset),k.removeAllRanges(),nt>Mt?(k.addRange(D),k.extend(M.node,M.offset)):(D.setEnd(M.node,M.offset),k.addRange(D))}}}}for(I=[],k=v;k=k.parentNode;)k.nodeType===1&&I.push({element:k,left:k.scrollLeft,top:k.scrollTop});for(typeof v.focus=="function"&&v.focus(),v=0;v<I.length;v++){var _=I[v];_.element.scrollLeft=_.left,_.element.scrollTop=_.top}}zl=!!Bu,zu=Bu=null}finally{wt=s,Y.p=r,U.T=i}}t.current=e,oe=2}}function hp(){if(oe===2){oe=0;var t=Zn,e=xa,i=(e.flags&8772)!==0;if((e.subtreeFlags&8772)!==0||i){i=U.T,U.T=null;var r=Y.p;Y.p=2;var s=wt;wt|=4;try{qm(t,e.alternate,e)}finally{wt=s,Y.p=r,U.T=i}}oe=3}}function mp(){if(oe===4||oe===3){oe=0,Rv();var t=Zn,e=xa,i=va,r=ep;(e.subtreeFlags&10256)!==0||(e.flags&10256)!==0?oe=5:(oe=0,xa=Zn=null,pp(t,t.pendingLanes));var s=t.pendingLanes;if(s===0&&(Qn=null),_s(i),e=e.stateNode,Ae&&typeof Ae.onCommitFiberRoot=="function")try{Ae.onCommitFiberRoot(Za,e,void 0,(e.current.flags&128)===128)}catch{}if(r!==null){e=U.T,s=Y.p,Y.p=2,U.T=null;try{for(var u=t.onRecoverableError,y=0;y<r.length;y++){var v=r[y];u(v.value,{componentStack:v.stack})}}finally{U.T=e,Y.p=s}}(va&3)!==0&&Al(),on(t),s=t.pendingLanes,(i&4194090)!==0&&(s&42)!==0?t===vu?kr++:(kr=0,vu=t):kr=0,Pr(0)}}function pp(t,e){(t.pooledCacheLanes&=e)===0&&(e=t.pooledCache,e!=null&&(t.pooledCache=null,pr(e)))}function Al(t){return dp(),hp(),mp(),gp()}function gp(){if(oe!==5)return!1;var t=Zn,e=yu;yu=0;var i=_s(va),r=U.T,s=Y.p;try{Y.p=32>i?32:i,U.T=null,i=xu,xu=null;var u=Zn,y=va;if(oe=0,xa=Zn=null,va=0,(wt&6)!==0)throw Error(l(331));var v=wt;if(wt|=4,Wm(u.current),Qm(u,u.current,y,i),wt=v,Pr(0,!1),Ae&&typeof Ae.onPostCommitFiberRoot=="function")try{Ae.onPostCommitFiberRoot(Za,u)}catch{}return!0}finally{Y.p=s,U.T=r,pp(t,e)}}function yp(t,e,i){e=Pe(i,e),e=Zc(t.stateNode,e,2),t=Hn(t,e,2),t!==null&&(Wa(t,2),on(t))}function jt(t,e,i){if(t.tag===3)yp(t,t,i);else for(;e!==null;){if(e.tag===3){yp(e,t,i);break}else if(e.tag===1){var r=e.stateNode;if(typeof e.type.getDerivedStateFromError=="function"||typeof r.componentDidCatch=="function"&&(Qn===null||!Qn.has(r))){t=Pe(i,t),i=Sm(2),r=Hn(e,i,2),r!==null&&(Am(i,r,e,t),Wa(r,2),on(r));break}}e=e.return}}function wu(t,e,i){var r=t.pingCache;if(r===null){r=t.pingCache=new a2;var s=new Set;r.set(e,s)}else s=r.get(e),s===void 0&&(s=new Set,r.set(e,s));s.has(i)||(hu=!0,s.add(i),t=c2.bind(null,t,e,i),e.then(t,t))}function c2(t,e,i){var r=t.pingCache;r!==null&&r.delete(e),t.pingedLanes|=t.suspendedLanes&i,t.warmLanes&=~i,Ot===t&&(yt&i)===i&&(Ut===4||Ut===3&&(yt&62914560)===yt&&300>tn()-gu?(wt&2)===0&&ba(t,0):mu|=i,ya===yt&&(ya=0)),on(t)}function xp(t,e){e===0&&(e=mh()),t=na(t,e),t!==null&&(Wa(t,e),on(t))}function u2(t){var e=t.memoizedState,i=0;e!==null&&(i=e.retryLane),xp(t,i)}function f2(t,e){var i=0;switch(t.tag){case 13:var r=t.stateNode,s=t.memoizedState;s!==null&&(i=s.retryLane);break;case 19:r=t.stateNode;break;case 22:r=t.stateNode._retryCache;break;default:throw Error(l(314))}r!==null&&r.delete(e),xp(t,i)}function d2(t,e){return Ps(t,e)}var wl=null,Aa=null,Cu=!1,Cl=!1,Tu=!1,Di=0;function on(t){t!==Aa&&t.next===null&&(Aa===null?wl=Aa=t:Aa=Aa.next=t),Cl=!0,Cu||(Cu=!0,m2())}function Pr(t,e){if(!Tu&&Cl){Tu=!0;do for(var i=!1,r=wl;r!==null;){if(t!==0){var s=r.pendingLanes;if(s===0)var u=0;else{var y=r.suspendedLanes,v=r.pingedLanes;u=(1<<31-we(42|t)+1)-1,u&=s&~(y&~v),u=u&201326741?u&201326741|1:u?u|2:0}u!==0&&(i=!0,Ap(r,u))}else u=yt,u=Do(r,r===Ot?u:0,r.cancelPendingCommit!==null||r.timeoutHandle!==-1),(u&3)===0||Ja(r,u)||(i=!0,Ap(r,u));r=r.next}while(i);Tu=!1}}function h2(){vp()}function vp(){Cl=Cu=!1;var t=0;Di!==0&&(A2()&&(t=Di),Di=0);for(var e=tn(),i=null,r=wl;r!==null;){var s=r.next,u=bp(r,e);u===0?(r.next=null,i===null?wl=s:i.next=s,s===null&&(Aa=i)):(i=r,(t!==0||(u&3)!==0)&&(Cl=!0)),r=s}Pr(t)}function bp(t,e){for(var i=t.suspendedLanes,r=t.pingedLanes,s=t.expirationTimes,u=t.pendingLanes&-62914561;0<u;){var y=31-we(u),v=1<<y,w=s[y];w===-1?((v&i)===0||(v&r)!==0)&&(s[y]=Nv(v,e)):w<=e&&(t.expiredLanes|=v),u&=~v}if(e=Ot,i=yt,i=Do(t,t===e?i:0,t.cancelPendingCommit!==null||t.timeoutHandle!==-1),r=t.callbackNode,i===0||t===e&&(Ct===2||Ct===9)||t.cancelPendingCommit!==null)return r!==null&&r!==null&&Vs(r),t.callbackNode=null,t.callbackPriority=0;if((i&3)===0||Ja(t,i)){if(e=i&-i,e===t.callbackPriority)return e;switch(r!==null&&Vs(r),_s(i)){case 2:case 8:i=fh;break;case 32:i=Mo;break;case 268435456:i=dh;break;default:i=Mo}return r=Sp.bind(null,t),i=Ps(i,r),t.callbackPriority=e,t.callbackNode=i,e}return r!==null&&r!==null&&Vs(r),t.callbackPriority=2,t.callbackNode=null,2}function Sp(t,e){if(oe!==0&&oe!==5)return t.callbackNode=null,t.callbackPriority=0,null;var i=t.callbackNode;if(Al()&&t.callbackNode!==i)return null;var r=yt;return r=Do(t,t===Ot?r:0,t.cancelPendingCommit!==null||t.timeoutHandle!==-1),r===0?null:(ip(t,r,e),bp(t,tn()),t.callbackNode!=null&&t.callbackNode===i?Sp.bind(null,t):null)}function Ap(t,e){if(Al())return null;ip(t,e,!0)}function m2(){C2(function(){(wt&6)!==0?Ps(uh,h2):vp()})}function Eu(){return Di===0&&(Di=hh()),Di}function wp(t){return t==null||typeof t=="symbol"||typeof t=="boolean"?null:typeof t=="function"?t:ko(""+t)}function Cp(t,e){var i=e.ownerDocument.createElement("input");return i.name=e.name,i.value=e.value,t.id&&i.setAttribute("form",t.id),e.parentNode.insertBefore(i,e),t=new FormData(t),i.parentNode.removeChild(i),t}function p2(t,e,i,r,s){if(e==="submit"&&i&&i.stateNode===s){var u=wp((s[ge]||null).action),y=r.submitter;y&&(e=(e=y[ge]||null)?wp(e.formAction):y.getAttribute("formAction"),e!==null&&(u=e,y=null));var v=new No("action","action",null,r,s);t.push({event:v,listeners:[{instance:null,listener:function(){if(r.defaultPrevented){if(Di!==0){var w=y?Cp(s,y):new FormData(s);Yc(i,{pending:!0,data:w,method:s.method,action:u},null,w)}}else typeof u=="function"&&(v.preventDefault(),w=y?Cp(s,y):new FormData(s),Yc(i,{pending:!0,data:w,method:s.method,action:u},u,w))},currentTarget:s}]})}}for(var Mu=0;Mu<fc.length;Mu++){var ju=fc[Mu],g2=ju.toLowerCase(),y2=ju[0].toUpperCase()+ju.slice(1);Ke(g2,"on"+y2)}Ke(i0,"onAnimationEnd"),Ke(a0,"onAnimationIteration"),Ke(r0,"onAnimationStart"),Ke("dblclick","onDoubleClick"),Ke("focusin","onFocus"),Ke("focusout","onBlur"),Ke(zb,"onTransitionRun"),Ke(kb,"onTransitionStart"),Ke(Pb,"onTransitionCancel"),Ke(o0,"onTransitionEnd"),Yi("onMouseEnter",["mouseout","mouseover"]),Yi("onMouseLeave",["mouseout","mouseover"]),Yi("onPointerEnter",["pointerout","pointerover"]),Yi("onPointerLeave",["pointerout","pointerover"]),mi("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),mi("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),mi("onBeforeInput",["compositionend","keypress","textInput","paste"]),mi("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),mi("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),mi("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Vr="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),x2=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Vr));function Tp(t,e){e=(e&4)!==0;for(var i=0;i<t.length;i++){var r=t[i],s=r.event;r=r.listeners;t:{var u=void 0;if(e)for(var y=r.length-1;0<=y;y--){var v=r[y],w=v.instance,L=v.currentTarget;if(v=v.listener,w!==u&&s.isPropagationStopped())break t;u=v,s.currentTarget=L;try{u(s)}catch(N){fl(N)}s.currentTarget=null,u=w}else for(y=0;y<r.length;y++){if(v=r[y],w=v.instance,L=v.currentTarget,v=v.listener,w!==u&&s.isPropagationStopped())break t;u=v,s.currentTarget=L;try{u(s)}catch(N){fl(N)}s.currentTarget=null,u=w}}}}function pt(t,e){var i=e[Hs];i===void 0&&(i=e[Hs]=new Set);var r=t+"__bubble";i.has(r)||(Ep(e,t,2,!1),i.add(r))}function Ou(t,e,i){var r=0;e&&(r|=4),Ep(i,t,r,e)}var Tl="_reactListening"+Math.random().toString(36).slice(2);function Du(t){if(!t[Tl]){t[Tl]=!0,vh.forEach(function(i){i!=="selectionchange"&&(x2.has(i)||Ou(i,!1,t),Ou(i,!0,t))});var e=t.nodeType===9?t:t.ownerDocument;e===null||e[Tl]||(e[Tl]=!0,Ou("selectionchange",!1,e))}}function Ep(t,e,i,r){switch(Qp(e)){case 2:var s=F2;break;case 8:s=Y2;break;default:s=qu}i=s.bind(null,e,i,t),s=void 0,!Js||e!=="touchstart"&&e!=="touchmove"&&e!=="wheel"||(s=!0),r?s!==void 0?t.addEventListener(e,i,{capture:!0,passive:s}):t.addEventListener(e,i,!0):s!==void 0?t.addEventListener(e,i,{passive:s}):t.addEventListener(e,i,!1)}function Ru(t,e,i,r,s){var u=r;if((e&1)===0&&(e&2)===0&&r!==null)t:for(;;){if(r===null)return;var y=r.tag;if(y===3||y===4){var v=r.stateNode.containerInfo;if(v===s)break;if(y===4)for(y=r.return;y!==null;){var w=y.tag;if((w===3||w===4)&&y.stateNode.containerInfo===s)return;y=y.return}for(;v!==null;){if(y=Ii(v),y===null)return;if(w=y.tag,w===5||w===6||w===26||w===27){r=u=y;continue t}v=v.parentNode}}r=r.return}Bh(function(){var L=u,N=Qs(i),I=[];t:{var B=l0.get(t);if(B!==void 0){var k=No,rt=t;switch(t){case"keypress":if(Vo(i)===0)break t;case"keydown":case"keyup":k=db;break;case"focusin":rt="focus",k=nc;break;case"focusout":rt="blur",k=nc;break;case"beforeblur":case"afterblur":k=nc;break;case"click":if(i.button===2)break t;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":k=Ph;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":k=tb;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":k=pb;break;case i0:case a0:case r0:k=ib;break;case o0:k=yb;break;case"scroll":case"scrollend":k=Jv;break;case"wheel":k=vb;break;case"copy":case"cut":case"paste":k=rb;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":k=Uh;break;case"toggle":case"beforetoggle":k=Sb}var nt=(e&4)!==0,Mt=!nt&&(t==="scroll"||t==="scrollend"),j=nt?B!==null?B+"Capture":null:B;nt=[];for(var M=L,D;M!==null;){var _=M;if(D=_.stateNode,_=_.tag,_!==5&&_!==26&&_!==27||D===null||j===null||(_=nr(M,j),_!=null&&nt.push(Ur(M,_,D))),Mt)break;M=M.return}0<nt.length&&(B=new k(B,rt,null,i,N),I.push({event:B,listeners:nt}))}}if((e&7)===0){t:{if(B=t==="mouseover"||t==="pointerover",k=t==="mouseout"||t==="pointerout",B&&i!==$s&&(rt=i.relatedTarget||i.fromElement)&&(Ii(rt)||rt[Gi]))break t;if((k||B)&&(B=N.window===N?N:(B=N.ownerDocument)?B.defaultView||B.parentWindow:window,k?(rt=i.relatedTarget||i.toElement,k=L,rt=rt?Ii(rt):null,rt!==null&&(Mt=f(rt),nt=rt.tag,rt!==Mt||nt!==5&&nt!==27&&nt!==6)&&(rt=null)):(k=null,rt=L),k!==rt)){if(nt=Ph,_="onMouseLeave",j="onMouseEnter",M="mouse",(t==="pointerout"||t==="pointerover")&&(nt=Uh,_="onPointerLeave",j="onPointerEnter",M="pointer"),Mt=k==null?B:er(k),D=rt==null?B:er(rt),B=new nt(_,M+"leave",k,i,N),B.target=Mt,B.relatedTarget=D,_=null,Ii(N)===L&&(nt=new nt(j,M+"enter",rt,i,N),nt.target=D,nt.relatedTarget=Mt,_=nt),Mt=_,k&&rt)e:{for(nt=k,j=rt,M=0,D=nt;D;D=wa(D))M++;for(D=0,_=j;_;_=wa(_))D++;for(;0<M-D;)nt=wa(nt),M--;for(;0<D-M;)j=wa(j),D--;for(;M--;){if(nt===j||j!==null&&nt===j.alternate)break e;nt=wa(nt),j=wa(j)}nt=null}else nt=null;k!==null&&Mp(I,B,k,nt,!1),rt!==null&&Mt!==null&&Mp(I,Mt,rt,nt,!0)}}t:{if(B=L?er(L):window,k=B.nodeName&&B.nodeName.toLowerCase(),k==="select"||k==="input"&&B.type==="file")var J=Yh;else if(qh(B))if(Xh)J=Rb;else{J=Ob;var dt=jb}else k=B.nodeName,!k||k.toLowerCase()!=="input"||B.type!=="checkbox"&&B.type!=="radio"?L&&Ks(L.elementType)&&(J=Yh):J=Db;if(J&&(J=J(t,L))){Fh(I,J,i,N);break t}dt&&dt(t,B,L),t==="focusout"&&L&&B.type==="number"&&L.memoizedProps.value!=null&&Xs(B,"number",B.value)}switch(dt=L?er(L):window,t){case"focusin":(qh(dt)||dt.contentEditable==="true")&&(Wi=dt,sc=L,ur=null);break;case"focusout":ur=sc=Wi=null;break;case"mousedown":cc=!0;break;case"contextmenu":case"mouseup":case"dragend":cc=!1,e0(I,i,N);break;case"selectionchange":if(Bb)break;case"keydown":case"keyup":e0(I,i,N)}var tt;if(ac)t:{switch(t){case"compositionstart":var at="onCompositionStart";break t;case"compositionend":at="onCompositionEnd";break t;case"compositionupdate":at="onCompositionUpdate";break t}at=void 0}else Ji?Gh(t,i)&&(at="onCompositionEnd"):t==="keydown"&&i.keyCode===229&&(at="onCompositionStart");at&&(Nh&&i.locale!=="ko"&&(Ji||at!=="onCompositionStart"?at==="onCompositionEnd"&&Ji&&(tt=zh()):(Vn=N,Ws="value"in Vn?Vn.value:Vn.textContent,Ji=!0)),dt=El(L,at),0<dt.length&&(at=new Vh(at,t,null,i,N),I.push({event:at,listeners:dt}),tt?at.data=tt:(tt=Ih(i),tt!==null&&(at.data=tt)))),(tt=wb?Cb(t,i):Tb(t,i))&&(at=El(L,"onBeforeInput"),0<at.length&&(dt=new Vh("onBeforeInput","beforeinput",null,i,N),I.push({event:dt,listeners:at}),dt.data=tt)),p2(I,t,L,i,N)}Tp(I,e)})}function Ur(t,e,i){return{instance:t,listener:e,currentTarget:i}}function El(t,e){for(var i=e+"Capture",r=[];t!==null;){var s=t,u=s.stateNode;if(s=s.tag,s!==5&&s!==26&&s!==27||u===null||(s=nr(t,i),s!=null&&r.unshift(Ur(t,s,u)),s=nr(t,e),s!=null&&r.push(Ur(t,s,u))),t.tag===3)return r;t=t.return}return[]}function wa(t){if(t===null)return null;do t=t.return;while(t&&t.tag!==5&&t.tag!==27);return t||null}function Mp(t,e,i,r,s){for(var u=e._reactName,y=[];i!==null&&i!==r;){var v=i,w=v.alternate,L=v.stateNode;if(v=v.tag,w!==null&&w===r)break;v!==5&&v!==26&&v!==27||L===null||(w=L,s?(L=nr(i,u),L!=null&&y.unshift(Ur(i,L,w))):s||(L=nr(i,u),L!=null&&y.push(Ur(i,L,w)))),i=i.return}y.length!==0&&t.push({event:e,listeners:y})}var v2=/\r\n?/g,b2=/\u0000|\uFFFD/g;function jp(t){return(typeof t=="string"?t:""+t).replace(v2,`
`).replace(b2,"")}function Op(t,e){return e=jp(e),jp(t)===e}function Ml(){}function Et(t,e,i,r,s,u){switch(i){case"children":typeof r=="string"?e==="body"||e==="textarea"&&r===""||$i(t,r):(typeof r=="number"||typeof r=="bigint")&&e!=="body"&&$i(t,""+r);break;case"className":Lo(t,"class",r);break;case"tabIndex":Lo(t,"tabindex",r);break;case"dir":case"role":case"viewBox":case"width":case"height":Lo(t,i,r);break;case"style":Rh(t,r,u);break;case"data":if(e!=="object"){Lo(t,"data",r);break}case"src":case"href":if(r===""&&(e!=="a"||i!=="href")){t.removeAttribute(i);break}if(r==null||typeof r=="function"||typeof r=="symbol"||typeof r=="boolean"){t.removeAttribute(i);break}r=ko(""+r),t.setAttribute(i,r);break;case"action":case"formAction":if(typeof r=="function"){t.setAttribute(i,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof u=="function"&&(i==="formAction"?(e!=="input"&&Et(t,e,"name",s.name,s,null),Et(t,e,"formEncType",s.formEncType,s,null),Et(t,e,"formMethod",s.formMethod,s,null),Et(t,e,"formTarget",s.formTarget,s,null)):(Et(t,e,"encType",s.encType,s,null),Et(t,e,"method",s.method,s,null),Et(t,e,"target",s.target,s,null)));if(r==null||typeof r=="symbol"||typeof r=="boolean"){t.removeAttribute(i);break}r=ko(""+r),t.setAttribute(i,r);break;case"onClick":r!=null&&(t.onclick=Ml);break;case"onScroll":r!=null&&pt("scroll",t);break;case"onScrollEnd":r!=null&&pt("scrollend",t);break;case"dangerouslySetInnerHTML":if(r!=null){if(typeof r!="object"||!("__html"in r))throw Error(l(61));if(i=r.__html,i!=null){if(s.children!=null)throw Error(l(60));t.innerHTML=i}}break;case"multiple":t.multiple=r&&typeof r!="function"&&typeof r!="symbol";break;case"muted":t.muted=r&&typeof r!="function"&&typeof r!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(r==null||typeof r=="function"||typeof r=="boolean"||typeof r=="symbol"){t.removeAttribute("xlink:href");break}i=ko(""+r),t.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",i);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":r!=null&&typeof r!="function"&&typeof r!="symbol"?t.setAttribute(i,""+r):t.removeAttribute(i);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":r&&typeof r!="function"&&typeof r!="symbol"?t.setAttribute(i,""):t.removeAttribute(i);break;case"capture":case"download":r===!0?t.setAttribute(i,""):r!==!1&&r!=null&&typeof r!="function"&&typeof r!="symbol"?t.setAttribute(i,r):t.removeAttribute(i);break;case"cols":case"rows":case"size":case"span":r!=null&&typeof r!="function"&&typeof r!="symbol"&&!isNaN(r)&&1<=r?t.setAttribute(i,r):t.removeAttribute(i);break;case"rowSpan":case"start":r==null||typeof r=="function"||typeof r=="symbol"||isNaN(r)?t.removeAttribute(i):t.setAttribute(i,r);break;case"popover":pt("beforetoggle",t),pt("toggle",t),Ro(t,"popover",r);break;case"xlinkActuate":pn(t,"http://www.w3.org/1999/xlink","xlink:actuate",r);break;case"xlinkArcrole":pn(t,"http://www.w3.org/1999/xlink","xlink:arcrole",r);break;case"xlinkRole":pn(t,"http://www.w3.org/1999/xlink","xlink:role",r);break;case"xlinkShow":pn(t,"http://www.w3.org/1999/xlink","xlink:show",r);break;case"xlinkTitle":pn(t,"http://www.w3.org/1999/xlink","xlink:title",r);break;case"xlinkType":pn(t,"http://www.w3.org/1999/xlink","xlink:type",r);break;case"xmlBase":pn(t,"http://www.w3.org/XML/1998/namespace","xml:base",r);break;case"xmlLang":pn(t,"http://www.w3.org/XML/1998/namespace","xml:lang",r);break;case"xmlSpace":pn(t,"http://www.w3.org/XML/1998/namespace","xml:space",r);break;case"is":Ro(t,"is",r);break;case"innerText":case"textContent":break;default:(!(2<i.length)||i[0]!=="o"&&i[0]!=="O"||i[1]!=="n"&&i[1]!=="N")&&(i=Qv.get(i)||i,Ro(t,i,r))}}function Lu(t,e,i,r,s,u){switch(i){case"style":Rh(t,r,u);break;case"dangerouslySetInnerHTML":if(r!=null){if(typeof r!="object"||!("__html"in r))throw Error(l(61));if(i=r.__html,i!=null){if(s.children!=null)throw Error(l(60));t.innerHTML=i}}break;case"children":typeof r=="string"?$i(t,r):(typeof r=="number"||typeof r=="bigint")&&$i(t,""+r);break;case"onScroll":r!=null&&pt("scroll",t);break;case"onScrollEnd":r!=null&&pt("scrollend",t);break;case"onClick":r!=null&&(t.onclick=Ml);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!bh.hasOwnProperty(i))t:{if(i[0]==="o"&&i[1]==="n"&&(s=i.endsWith("Capture"),e=i.slice(2,s?i.length-7:void 0),u=t[ge]||null,u=u!=null?u[i]:null,typeof u=="function"&&t.removeEventListener(e,u,s),typeof r=="function")){typeof u!="function"&&u!==null&&(i in t?t[i]=null:t.hasAttribute(i)&&t.removeAttribute(i)),t.addEventListener(e,r,s);break t}i in t?t[i]=r:r===!0?t.setAttribute(i,""):Ro(t,i,r)}}}function le(t,e,i){switch(e){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":pt("error",t),pt("load",t);var r=!1,s=!1,u;for(u in i)if(i.hasOwnProperty(u)){var y=i[u];if(y!=null)switch(u){case"src":r=!0;break;case"srcSet":s=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(l(137,e));default:Et(t,e,u,y,i,null)}}s&&Et(t,e,"srcSet",i.srcSet,i,null),r&&Et(t,e,"src",i.src,i,null);return;case"input":pt("invalid",t);var v=u=y=s=null,w=null,L=null;for(r in i)if(i.hasOwnProperty(r)){var N=i[r];if(N!=null)switch(r){case"name":s=N;break;case"type":y=N;break;case"checked":w=N;break;case"defaultChecked":L=N;break;case"value":u=N;break;case"defaultValue":v=N;break;case"children":case"dangerouslySetInnerHTML":if(N!=null)throw Error(l(137,e));break;default:Et(t,e,r,N,i,null)}}Mh(t,u,v,w,L,y,s,!1),Bo(t);return;case"select":pt("invalid",t),r=y=u=null;for(s in i)if(i.hasOwnProperty(s)&&(v=i[s],v!=null))switch(s){case"value":u=v;break;case"defaultValue":y=v;break;case"multiple":r=v;default:Et(t,e,s,v,i,null)}e=u,i=y,t.multiple=!!r,e!=null?Ki(t,!!r,e,!1):i!=null&&Ki(t,!!r,i,!0);return;case"textarea":pt("invalid",t),u=s=r=null;for(y in i)if(i.hasOwnProperty(y)&&(v=i[y],v!=null))switch(y){case"value":r=v;break;case"defaultValue":s=v;break;case"children":u=v;break;case"dangerouslySetInnerHTML":if(v!=null)throw Error(l(91));break;default:Et(t,e,y,v,i,null)}Oh(t,r,s,u),Bo(t);return;case"option":for(w in i)if(i.hasOwnProperty(w)&&(r=i[w],r!=null))switch(w){case"selected":t.selected=r&&typeof r!="function"&&typeof r!="symbol";break;default:Et(t,e,w,r,i,null)}return;case"dialog":pt("beforetoggle",t),pt("toggle",t),pt("cancel",t),pt("close",t);break;case"iframe":case"object":pt("load",t);break;case"video":case"audio":for(r=0;r<Vr.length;r++)pt(Vr[r],t);break;case"image":pt("error",t),pt("load",t);break;case"details":pt("toggle",t);break;case"embed":case"source":case"link":pt("error",t),pt("load",t);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(L in i)if(i.hasOwnProperty(L)&&(r=i[L],r!=null))switch(L){case"children":case"dangerouslySetInnerHTML":throw Error(l(137,e));default:Et(t,e,L,r,i,null)}return;default:if(Ks(e)){for(N in i)i.hasOwnProperty(N)&&(r=i[N],r!==void 0&&Lu(t,e,N,r,i,void 0));return}}for(v in i)i.hasOwnProperty(v)&&(r=i[v],r!=null&&Et(t,e,v,r,i,null))}function S2(t,e,i,r){switch(e){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var s=null,u=null,y=null,v=null,w=null,L=null,N=null;for(k in i){var I=i[k];if(i.hasOwnProperty(k)&&I!=null)switch(k){case"checked":break;case"value":break;case"defaultValue":w=I;default:r.hasOwnProperty(k)||Et(t,e,k,null,r,I)}}for(var B in r){var k=r[B];if(I=i[B],r.hasOwnProperty(B)&&(k!=null||I!=null))switch(B){case"type":u=k;break;case"name":s=k;break;case"checked":L=k;break;case"defaultChecked":N=k;break;case"value":y=k;break;case"defaultValue":v=k;break;case"children":case"dangerouslySetInnerHTML":if(k!=null)throw Error(l(137,e));break;default:k!==I&&Et(t,e,B,k,r,I)}}Ys(t,y,v,w,L,N,u,s);return;case"select":k=y=v=B=null;for(u in i)if(w=i[u],i.hasOwnProperty(u)&&w!=null)switch(u){case"value":break;case"multiple":k=w;default:r.hasOwnProperty(u)||Et(t,e,u,null,r,w)}for(s in r)if(u=r[s],w=i[s],r.hasOwnProperty(s)&&(u!=null||w!=null))switch(s){case"value":B=u;break;case"defaultValue":v=u;break;case"multiple":y=u;default:u!==w&&Et(t,e,s,u,r,w)}e=v,i=y,r=k,B!=null?Ki(t,!!i,B,!1):!!r!=!!i&&(e!=null?Ki(t,!!i,e,!0):Ki(t,!!i,i?[]:"",!1));return;case"textarea":k=B=null;for(v in i)if(s=i[v],i.hasOwnProperty(v)&&s!=null&&!r.hasOwnProperty(v))switch(v){case"value":break;case"children":break;default:Et(t,e,v,null,r,s)}for(y in r)if(s=r[y],u=i[y],r.hasOwnProperty(y)&&(s!=null||u!=null))switch(y){case"value":B=s;break;case"defaultValue":k=s;break;case"children":break;case"dangerouslySetInnerHTML":if(s!=null)throw Error(l(91));break;default:s!==u&&Et(t,e,y,s,r,u)}jh(t,B,k);return;case"option":for(var rt in i)if(B=i[rt],i.hasOwnProperty(rt)&&B!=null&&!r.hasOwnProperty(rt))switch(rt){case"selected":t.selected=!1;break;default:Et(t,e,rt,null,r,B)}for(w in r)if(B=r[w],k=i[w],r.hasOwnProperty(w)&&B!==k&&(B!=null||k!=null))switch(w){case"selected":t.selected=B&&typeof B!="function"&&typeof B!="symbol";break;default:Et(t,e,w,B,r,k)}return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var nt in i)B=i[nt],i.hasOwnProperty(nt)&&B!=null&&!r.hasOwnProperty(nt)&&Et(t,e,nt,null,r,B);for(L in r)if(B=r[L],k=i[L],r.hasOwnProperty(L)&&B!==k&&(B!=null||k!=null))switch(L){case"children":case"dangerouslySetInnerHTML":if(B!=null)throw Error(l(137,e));break;default:Et(t,e,L,B,r,k)}return;default:if(Ks(e)){for(var Mt in i)B=i[Mt],i.hasOwnProperty(Mt)&&B!==void 0&&!r.hasOwnProperty(Mt)&&Lu(t,e,Mt,void 0,r,B);for(N in r)B=r[N],k=i[N],!r.hasOwnProperty(N)||B===k||B===void 0&&k===void 0||Lu(t,e,N,B,r,k);return}}for(var j in i)B=i[j],i.hasOwnProperty(j)&&B!=null&&!r.hasOwnProperty(j)&&Et(t,e,j,null,r,B);for(I in r)B=r[I],k=i[I],!r.hasOwnProperty(I)||B===k||B==null&&k==null||Et(t,e,I,B,r,k)}var Bu=null,zu=null;function jl(t){return t.nodeType===9?t:t.ownerDocument}function Dp(t){switch(t){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function Rp(t,e){if(t===0)switch(e){case"svg":return 1;case"math":return 2;default:return 0}return t===1&&e==="foreignObject"?0:t}function ku(t,e){return t==="textarea"||t==="noscript"||typeof e.children=="string"||typeof e.children=="number"||typeof e.children=="bigint"||typeof e.dangerouslySetInnerHTML=="object"&&e.dangerouslySetInnerHTML!==null&&e.dangerouslySetInnerHTML.__html!=null}var Pu=null;function A2(){var t=window.event;return t&&t.type==="popstate"?t===Pu?!1:(Pu=t,!0):(Pu=null,!1)}var Lp=typeof setTimeout=="function"?setTimeout:void 0,w2=typeof clearTimeout=="function"?clearTimeout:void 0,Bp=typeof Promise=="function"?Promise:void 0,C2=typeof queueMicrotask=="function"?queueMicrotask:typeof Bp<"u"?function(t){return Bp.resolve(null).then(t).catch(T2)}:Lp;function T2(t){setTimeout(function(){throw t})}function Wn(t){return t==="head"}function zp(t,e){var i=e,r=0,s=0;do{var u=i.nextSibling;if(t.removeChild(i),u&&u.nodeType===8)if(i=u.data,i==="/$"){if(0<r&&8>r){i=r;var y=t.ownerDocument;if(i&1&&Nr(y.documentElement),i&2&&Nr(y.body),i&4)for(i=y.head,Nr(i),y=i.firstChild;y;){var v=y.nextSibling,w=y.nodeName;y[tr]||w==="SCRIPT"||w==="STYLE"||w==="LINK"&&y.rel.toLowerCase()==="stylesheet"||i.removeChild(y),y=v}}if(s===0){t.removeChild(u),Xr(e);return}s--}else i==="$"||i==="$?"||i==="$!"?s++:r=i.charCodeAt(0)-48;else r=0;i=u}while(i);Xr(e)}function Vu(t){var e=t.firstChild;for(e&&e.nodeType===10&&(e=e.nextSibling);e;){var i=e;switch(e=e.nextSibling,i.nodeName){case"HTML":case"HEAD":case"BODY":Vu(i),Gs(i);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(i.rel.toLowerCase()==="stylesheet")continue}t.removeChild(i)}}function E2(t,e,i,r){for(;t.nodeType===1;){var s=i;if(t.nodeName.toLowerCase()!==e.toLowerCase()){if(!r&&(t.nodeName!=="INPUT"||t.type!=="hidden"))break}else if(r){if(!t[tr])switch(e){case"meta":if(!t.hasAttribute("itemprop"))break;return t;case"link":if(u=t.getAttribute("rel"),u==="stylesheet"&&t.hasAttribute("data-precedence"))break;if(u!==s.rel||t.getAttribute("href")!==(s.href==null||s.href===""?null:s.href)||t.getAttribute("crossorigin")!==(s.crossOrigin==null?null:s.crossOrigin)||t.getAttribute("title")!==(s.title==null?null:s.title))break;return t;case"style":if(t.hasAttribute("data-precedence"))break;return t;case"script":if(u=t.getAttribute("src"),(u!==(s.src==null?null:s.src)||t.getAttribute("type")!==(s.type==null?null:s.type)||t.getAttribute("crossorigin")!==(s.crossOrigin==null?null:s.crossOrigin))&&u&&t.hasAttribute("async")&&!t.hasAttribute("itemprop"))break;return t;default:return t}}else if(e==="input"&&t.type==="hidden"){var u=s.name==null?null:""+s.name;if(s.type==="hidden"&&t.getAttribute("name")===u)return t}else return t;if(t=Qe(t.nextSibling),t===null)break}return null}function M2(t,e,i){if(e==="")return null;for(;t.nodeType!==3;)if((t.nodeType!==1||t.nodeName!=="INPUT"||t.type!=="hidden")&&!i||(t=Qe(t.nextSibling),t===null))return null;return t}function Uu(t){return t.data==="$!"||t.data==="$?"&&t.ownerDocument.readyState==="complete"}function j2(t,e){var i=t.ownerDocument;if(t.data!=="$?"||i.readyState==="complete")e();else{var r=function(){e(),i.removeEventListener("DOMContentLoaded",r)};i.addEventListener("DOMContentLoaded",r),t._reactRetry=r}}function Qe(t){for(;t!=null;t=t.nextSibling){var e=t.nodeType;if(e===1||e===3)break;if(e===8){if(e=t.data,e==="$"||e==="$!"||e==="$?"||e==="F!"||e==="F")break;if(e==="/$")return null}}return t}var Nu=null;function kp(t){t=t.previousSibling;for(var e=0;t;){if(t.nodeType===8){var i=t.data;if(i==="$"||i==="$!"||i==="$?"){if(e===0)return t;e--}else i==="/$"&&e++}t=t.previousSibling}return null}function Pp(t,e,i){switch(e=jl(i),t){case"html":if(t=e.documentElement,!t)throw Error(l(452));return t;case"head":if(t=e.head,!t)throw Error(l(453));return t;case"body":if(t=e.body,!t)throw Error(l(454));return t;default:throw Error(l(451))}}function Nr(t){for(var e=t.attributes;e.length;)t.removeAttributeNode(e[0]);Gs(t)}var Ge=new Map,Vp=new Set;function Ol(t){return typeof t.getRootNode=="function"?t.getRootNode():t.nodeType===9?t:t.ownerDocument}var On=Y.d;Y.d={f:O2,r:D2,D:R2,C:L2,L:B2,m:z2,X:P2,S:k2,M:V2};function O2(){var t=On.f(),e=bl();return t||e}function D2(t){var e=qi(t);e!==null&&e.tag===5&&e.type==="form"?im(e):On.r(t)}var Ca=typeof document>"u"?null:document;function Up(t,e,i){var r=Ca;if(r&&typeof e=="string"&&e){var s=ke(e);s='link[rel="'+t+'"][href="'+s+'"]',typeof i=="string"&&(s+='[crossorigin="'+i+'"]'),Vp.has(s)||(Vp.add(s),t={rel:t,crossOrigin:i,href:e},r.querySelector(s)===null&&(e=r.createElement("link"),le(e,"link",t),Jt(e),r.head.appendChild(e)))}}function R2(t){On.D(t),Up("dns-prefetch",t,null)}function L2(t,e){On.C(t,e),Up("preconnect",t,e)}function B2(t,e,i){On.L(t,e,i);var r=Ca;if(r&&t&&e){var s='link[rel="preload"][as="'+ke(e)+'"]';e==="image"&&i&&i.imageSrcSet?(s+='[imagesrcset="'+ke(i.imageSrcSet)+'"]',typeof i.imageSizes=="string"&&(s+='[imagesizes="'+ke(i.imageSizes)+'"]')):s+='[href="'+ke(t)+'"]';var u=s;switch(e){case"style":u=Ta(t);break;case"script":u=Ea(t)}Ge.has(u)||(t=x({rel:"preload",href:e==="image"&&i&&i.imageSrcSet?void 0:t,as:e},i),Ge.set(u,t),r.querySelector(s)!==null||e==="style"&&r.querySelector(_r(u))||e==="script"&&r.querySelector(Hr(u))||(e=r.createElement("link"),le(e,"link",t),Jt(e),r.head.appendChild(e)))}}function z2(t,e){On.m(t,e);var i=Ca;if(i&&t){var r=e&&typeof e.as=="string"?e.as:"script",s='link[rel="modulepreload"][as="'+ke(r)+'"][href="'+ke(t)+'"]',u=s;switch(r){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":u=Ea(t)}if(!Ge.has(u)&&(t=x({rel:"modulepreload",href:t},e),Ge.set(u,t),i.querySelector(s)===null)){switch(r){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(i.querySelector(Hr(u)))return}r=i.createElement("link"),le(r,"link",t),Jt(r),i.head.appendChild(r)}}}function k2(t,e,i){On.S(t,e,i);var r=Ca;if(r&&t){var s=Fi(r).hoistableStyles,u=Ta(t);e=e||"default";var y=s.get(u);if(!y){var v={loading:0,preload:null};if(y=r.querySelector(_r(u)))v.loading=5;else{t=x({rel:"stylesheet",href:t,"data-precedence":e},i),(i=Ge.get(u))&&_u(t,i);var w=y=r.createElement("link");Jt(w),le(w,"link",t),w._p=new Promise(function(L,N){w.onload=L,w.onerror=N}),w.addEventListener("load",function(){v.loading|=1}),w.addEventListener("error",function(){v.loading|=2}),v.loading|=4,Dl(y,e,r)}y={type:"stylesheet",instance:y,count:1,state:v},s.set(u,y)}}}function P2(t,e){On.X(t,e);var i=Ca;if(i&&t){var r=Fi(i).hoistableScripts,s=Ea(t),u=r.get(s);u||(u=i.querySelector(Hr(s)),u||(t=x({src:t,async:!0},e),(e=Ge.get(s))&&Hu(t,e),u=i.createElement("script"),Jt(u),le(u,"link",t),i.head.appendChild(u)),u={type:"script",instance:u,count:1,state:null},r.set(s,u))}}function V2(t,e){On.M(t,e);var i=Ca;if(i&&t){var r=Fi(i).hoistableScripts,s=Ea(t),u=r.get(s);u||(u=i.querySelector(Hr(s)),u||(t=x({src:t,async:!0,type:"module"},e),(e=Ge.get(s))&&Hu(t,e),u=i.createElement("script"),Jt(u),le(u,"link",t),i.head.appendChild(u)),u={type:"script",instance:u,count:1,state:null},r.set(s,u))}}function Np(t,e,i,r){var s=(s=it.current)?Ol(s):null;if(!s)throw Error(l(446));switch(t){case"meta":case"title":return null;case"style":return typeof i.precedence=="string"&&typeof i.href=="string"?(e=Ta(i.href),i=Fi(s).hoistableStyles,r=i.get(e),r||(r={type:"style",instance:null,count:0,state:null},i.set(e,r)),r):{type:"void",instance:null,count:0,state:null};case"link":if(i.rel==="stylesheet"&&typeof i.href=="string"&&typeof i.precedence=="string"){t=Ta(i.href);var u=Fi(s).hoistableStyles,y=u.get(t);if(y||(s=s.ownerDocument||s,y={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},u.set(t,y),(u=s.querySelector(_r(t)))&&!u._p&&(y.instance=u,y.state.loading=5),Ge.has(t)||(i={rel:"preload",as:"style",href:i.href,crossOrigin:i.crossOrigin,integrity:i.integrity,media:i.media,hrefLang:i.hrefLang,referrerPolicy:i.referrerPolicy},Ge.set(t,i),u||U2(s,t,i,y.state))),e&&r===null)throw Error(l(528,""));return y}if(e&&r!==null)throw Error(l(529,""));return null;case"script":return e=i.async,i=i.src,typeof i=="string"&&e&&typeof e!="function"&&typeof e!="symbol"?(e=Ea(i),i=Fi(s).hoistableScripts,r=i.get(e),r||(r={type:"script",instance:null,count:0,state:null},i.set(e,r)),r):{type:"void",instance:null,count:0,state:null};default:throw Error(l(444,t))}}function Ta(t){return'href="'+ke(t)+'"'}function _r(t){return'link[rel="stylesheet"]['+t+"]"}function _p(t){return x({},t,{"data-precedence":t.precedence,precedence:null})}function U2(t,e,i,r){t.querySelector('link[rel="preload"][as="style"]['+e+"]")?r.loading=1:(e=t.createElement("link"),r.preload=e,e.addEventListener("load",function(){return r.loading|=1}),e.addEventListener("error",function(){return r.loading|=2}),le(e,"link",i),Jt(e),t.head.appendChild(e))}function Ea(t){return'[src="'+ke(t)+'"]'}function Hr(t){return"script[async]"+t}function Hp(t,e,i){if(e.count++,e.instance===null)switch(e.type){case"style":var r=t.querySelector('style[data-href~="'+ke(i.href)+'"]');if(r)return e.instance=r,Jt(r),r;var s=x({},i,{"data-href":i.href,"data-precedence":i.precedence,href:null,precedence:null});return r=(t.ownerDocument||t).createElement("style"),Jt(r),le(r,"style",s),Dl(r,i.precedence,t),e.instance=r;case"stylesheet":s=Ta(i.href);var u=t.querySelector(_r(s));if(u)return e.state.loading|=4,e.instance=u,Jt(u),u;r=_p(i),(s=Ge.get(s))&&_u(r,s),u=(t.ownerDocument||t).createElement("link"),Jt(u);var y=u;return y._p=new Promise(function(v,w){y.onload=v,y.onerror=w}),le(u,"link",r),e.state.loading|=4,Dl(u,i.precedence,t),e.instance=u;case"script":return u=Ea(i.src),(s=t.querySelector(Hr(u)))?(e.instance=s,Jt(s),s):(r=i,(s=Ge.get(u))&&(r=x({},i),Hu(r,s)),t=t.ownerDocument||t,s=t.createElement("script"),Jt(s),le(s,"link",r),t.head.appendChild(s),e.instance=s);case"void":return null;default:throw Error(l(443,e.type))}else e.type==="stylesheet"&&(e.state.loading&4)===0&&(r=e.instance,e.state.loading|=4,Dl(r,i.precedence,t));return e.instance}function Dl(t,e,i){for(var r=i.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),s=r.length?r[r.length-1]:null,u=s,y=0;y<r.length;y++){var v=r[y];if(v.dataset.precedence===e)u=v;else if(u!==s)break}u?u.parentNode.insertBefore(t,u.nextSibling):(e=i.nodeType===9?i.head:i,e.insertBefore(t,e.firstChild))}function _u(t,e){t.crossOrigin==null&&(t.crossOrigin=e.crossOrigin),t.referrerPolicy==null&&(t.referrerPolicy=e.referrerPolicy),t.title==null&&(t.title=e.title)}function Hu(t,e){t.crossOrigin==null&&(t.crossOrigin=e.crossOrigin),t.referrerPolicy==null&&(t.referrerPolicy=e.referrerPolicy),t.integrity==null&&(t.integrity=e.integrity)}var Rl=null;function Gp(t,e,i){if(Rl===null){var r=new Map,s=Rl=new Map;s.set(i,r)}else s=Rl,r=s.get(i),r||(r=new Map,s.set(i,r));if(r.has(t))return r;for(r.set(t,null),i=i.getElementsByTagName(t),s=0;s<i.length;s++){var u=i[s];if(!(u[tr]||u[ue]||t==="link"&&u.getAttribute("rel")==="stylesheet")&&u.namespaceURI!=="http://www.w3.org/2000/svg"){var y=u.getAttribute(e)||"";y=t+y;var v=r.get(y);v?v.push(u):r.set(y,[u])}}return r}function Ip(t,e,i){t=t.ownerDocument||t,t.head.insertBefore(i,e==="title"?t.querySelector("head > title"):null)}function N2(t,e,i){if(i===1||e.itemProp!=null)return!1;switch(t){case"meta":case"title":return!0;case"style":if(typeof e.precedence!="string"||typeof e.href!="string"||e.href==="")break;return!0;case"link":if(typeof e.rel!="string"||typeof e.href!="string"||e.href===""||e.onLoad||e.onError)break;switch(e.rel){case"stylesheet":return t=e.disabled,typeof e.precedence=="string"&&t==null;default:return!0}case"script":if(e.async&&typeof e.async!="function"&&typeof e.async!="symbol"&&!e.onLoad&&!e.onError&&e.src&&typeof e.src=="string")return!0}return!1}function qp(t){return!(t.type==="stylesheet"&&(t.state.loading&3)===0)}var Gr=null;function _2(){}function H2(t,e,i){if(Gr===null)throw Error(l(475));var r=Gr;if(e.type==="stylesheet"&&(typeof i.media!="string"||matchMedia(i.media).matches!==!1)&&(e.state.loading&4)===0){if(e.instance===null){var s=Ta(i.href),u=t.querySelector(_r(s));if(u){t=u._p,t!==null&&typeof t=="object"&&typeof t.then=="function"&&(r.count++,r=Ll.bind(r),t.then(r,r)),e.state.loading|=4,e.instance=u,Jt(u);return}u=t.ownerDocument||t,i=_p(i),(s=Ge.get(s))&&_u(i,s),u=u.createElement("link"),Jt(u);var y=u;y._p=new Promise(function(v,w){y.onload=v,y.onerror=w}),le(u,"link",i),e.instance=u}r.stylesheets===null&&(r.stylesheets=new Map),r.stylesheets.set(e,t),(t=e.state.preload)&&(e.state.loading&3)===0&&(r.count++,e=Ll.bind(r),t.addEventListener("load",e),t.addEventListener("error",e))}}function G2(){if(Gr===null)throw Error(l(475));var t=Gr;return t.stylesheets&&t.count===0&&Gu(t,t.stylesheets),0<t.count?function(e){var i=setTimeout(function(){if(t.stylesheets&&Gu(t,t.stylesheets),t.unsuspend){var r=t.unsuspend;t.unsuspend=null,r()}},6e4);return t.unsuspend=e,function(){t.unsuspend=null,clearTimeout(i)}}:null}function Ll(){if(this.count--,this.count===0){if(this.stylesheets)Gu(this,this.stylesheets);else if(this.unsuspend){var t=this.unsuspend;this.unsuspend=null,t()}}}var Bl=null;function Gu(t,e){t.stylesheets=null,t.unsuspend!==null&&(t.count++,Bl=new Map,e.forEach(I2,t),Bl=null,Ll.call(t))}function I2(t,e){if(!(e.state.loading&4)){var i=Bl.get(t);if(i)var r=i.get(null);else{i=new Map,Bl.set(t,i);for(var s=t.querySelectorAll("link[data-precedence],style[data-precedence]"),u=0;u<s.length;u++){var y=s[u];(y.nodeName==="LINK"||y.getAttribute("media")!=="not all")&&(i.set(y.dataset.precedence,y),r=y)}r&&i.set(null,r)}s=e.instance,y=s.getAttribute("data-precedence"),u=i.get(y)||r,u===r&&i.set(null,s),i.set(y,s),this.count++,r=Ll.bind(this),s.addEventListener("load",r),s.addEventListener("error",r),u?u.parentNode.insertBefore(s,u.nextSibling):(t=t.nodeType===9?t.head:t,t.insertBefore(s,t.firstChild)),e.state.loading|=4}}var Ir={$$typeof:V,Provider:null,Consumer:null,_currentValue:W,_currentValue2:W,_threadCount:0};function q2(t,e,i,r,s,u,y,v){this.tag=1,this.containerInfo=t,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=Us(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Us(0),this.hiddenUpdates=Us(null),this.identifierPrefix=r,this.onUncaughtError=s,this.onCaughtError=u,this.onRecoverableError=y,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=v,this.incompleteTransitions=new Map}function Fp(t,e,i,r,s,u,y,v,w,L,N,I){return t=new q2(t,e,i,y,v,w,L,I),e=1,u===!0&&(e|=24),u=Te(3,null,null,e),t.current=u,u.stateNode=t,e=wc(),e.refCount++,t.pooledCache=e,e.refCount++,u.memoizedState={element:r,isDehydrated:i,cache:e},Mc(u),t}function Yp(t){return t?(t=ia,t):ia}function Xp(t,e,i,r,s,u){s=Yp(s),r.context===null?r.context=s:r.pendingContext=s,r=_n(e),r.payload={element:i},u=u===void 0?null:u,u!==null&&(r.callback=u),i=Hn(t,r,e),i!==null&&(De(i,t,e),vr(i,t,e))}function Kp(t,e){if(t=t.memoizedState,t!==null&&t.dehydrated!==null){var i=t.retryLane;t.retryLane=i!==0&&i<e?i:e}}function Iu(t,e){Kp(t,e),(t=t.alternate)&&Kp(t,e)}function $p(t){if(t.tag===13){var e=na(t,67108864);e!==null&&De(e,t,67108864),Iu(t,67108864)}}var zl=!0;function F2(t,e,i,r){var s=U.T;U.T=null;var u=Y.p;try{Y.p=2,qu(t,e,i,r)}finally{Y.p=u,U.T=s}}function Y2(t,e,i,r){var s=U.T;U.T=null;var u=Y.p;try{Y.p=8,qu(t,e,i,r)}finally{Y.p=u,U.T=s}}function qu(t,e,i,r){if(zl){var s=Fu(r);if(s===null)Ru(t,e,r,kl,i),Zp(t,r);else if(K2(s,t,e,i,r))r.stopPropagation();else if(Zp(t,r),e&4&&-1<X2.indexOf(t)){for(;s!==null;){var u=qi(s);if(u!==null)switch(u.tag){case 3:if(u=u.stateNode,u.current.memoizedState.isDehydrated){var y=hi(u.pendingLanes);if(y!==0){var v=u;for(v.pendingLanes|=2,v.entangledLanes|=2;y;){var w=1<<31-we(y);v.entanglements[1]|=w,y&=~w}on(u),(wt&6)===0&&(xl=tn()+500,Pr(0))}}break;case 13:v=na(u,2),v!==null&&De(v,u,2),bl(),Iu(u,2)}if(u=Fu(r),u===null&&Ru(t,e,r,kl,i),u===s)break;s=u}s!==null&&r.stopPropagation()}else Ru(t,e,r,null,i)}}function Fu(t){return t=Qs(t),Yu(t)}var kl=null;function Yu(t){if(kl=null,t=Ii(t),t!==null){var e=f(t);if(e===null)t=null;else{var i=e.tag;if(i===13){if(t=d(e),t!==null)return t;t=null}else if(i===3){if(e.stateNode.current.memoizedState.isDehydrated)return e.tag===3?e.stateNode.containerInfo:null;t=null}else e!==t&&(t=null)}}return kl=t,null}function Qp(t){switch(t){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(Lv()){case uh:return 2;case fh:return 8;case Mo:case Bv:return 32;case dh:return 268435456;default:return 32}default:return 32}}var Xu=!1,ti=null,ei=null,ni=null,qr=new Map,Fr=new Map,ii=[],X2="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function Zp(t,e){switch(t){case"focusin":case"focusout":ti=null;break;case"dragenter":case"dragleave":ei=null;break;case"mouseover":case"mouseout":ni=null;break;case"pointerover":case"pointerout":qr.delete(e.pointerId);break;case"gotpointercapture":case"lostpointercapture":Fr.delete(e.pointerId)}}function Yr(t,e,i,r,s,u){return t===null||t.nativeEvent!==u?(t={blockedOn:e,domEventName:i,eventSystemFlags:r,nativeEvent:u,targetContainers:[s]},e!==null&&(e=qi(e),e!==null&&$p(e)),t):(t.eventSystemFlags|=r,e=t.targetContainers,s!==null&&e.indexOf(s)===-1&&e.push(s),t)}function K2(t,e,i,r,s){switch(e){case"focusin":return ti=Yr(ti,t,e,i,r,s),!0;case"dragenter":return ei=Yr(ei,t,e,i,r,s),!0;case"mouseover":return ni=Yr(ni,t,e,i,r,s),!0;case"pointerover":var u=s.pointerId;return qr.set(u,Yr(qr.get(u)||null,t,e,i,r,s)),!0;case"gotpointercapture":return u=s.pointerId,Fr.set(u,Yr(Fr.get(u)||null,t,e,i,r,s)),!0}return!1}function Jp(t){var e=Ii(t.target);if(e!==null){var i=f(e);if(i!==null){if(e=i.tag,e===13){if(e=d(i),e!==null){t.blockedOn=e,Hv(t.priority,function(){if(i.tag===13){var r=Oe();r=Ns(r);var s=na(i,r);s!==null&&De(s,i,r),Iu(i,r)}});return}}else if(e===3&&i.stateNode.current.memoizedState.isDehydrated){t.blockedOn=i.tag===3?i.stateNode.containerInfo:null;return}}}t.blockedOn=null}function Pl(t){if(t.blockedOn!==null)return!1;for(var e=t.targetContainers;0<e.length;){var i=Fu(t.nativeEvent);if(i===null){i=t.nativeEvent;var r=new i.constructor(i.type,i);$s=r,i.target.dispatchEvent(r),$s=null}else return e=qi(i),e!==null&&$p(e),t.blockedOn=i,!1;e.shift()}return!0}function Wp(t,e,i){Pl(t)&&i.delete(e)}function $2(){Xu=!1,ti!==null&&Pl(ti)&&(ti=null),ei!==null&&Pl(ei)&&(ei=null),ni!==null&&Pl(ni)&&(ni=null),qr.forEach(Wp),Fr.forEach(Wp)}function Vl(t,e){t.blockedOn===e&&(t.blockedOn=null,Xu||(Xu=!0,n.unstable_scheduleCallback(n.unstable_NormalPriority,$2)))}var Ul=null;function tg(t){Ul!==t&&(Ul=t,n.unstable_scheduleCallback(n.unstable_NormalPriority,function(){Ul===t&&(Ul=null);for(var e=0;e<t.length;e+=3){var i=t[e],r=t[e+1],s=t[e+2];if(typeof r!="function"){if(Yu(r||i)===null)continue;break}var u=qi(i);u!==null&&(t.splice(e,3),e-=3,Yc(u,{pending:!0,data:s,method:i.method,action:r},r,s))}}))}function Xr(t){function e(w){return Vl(w,t)}ti!==null&&Vl(ti,t),ei!==null&&Vl(ei,t),ni!==null&&Vl(ni,t),qr.forEach(e),Fr.forEach(e);for(var i=0;i<ii.length;i++){var r=ii[i];r.blockedOn===t&&(r.blockedOn=null)}for(;0<ii.length&&(i=ii[0],i.blockedOn===null);)Jp(i),i.blockedOn===null&&ii.shift();if(i=(t.ownerDocument||t).$$reactFormReplay,i!=null)for(r=0;r<i.length;r+=3){var s=i[r],u=i[r+1],y=s[ge]||null;if(typeof u=="function")y||tg(i);else if(y){var v=null;if(u&&u.hasAttribute("formAction")){if(s=u,y=u[ge]||null)v=y.formAction;else if(Yu(s)!==null)continue}else v=y.action;typeof v=="function"?i[r+1]=v:(i.splice(r,3),r-=3),tg(i)}}}function Ku(t){this._internalRoot=t}Nl.prototype.render=Ku.prototype.render=function(t){var e=this._internalRoot;if(e===null)throw Error(l(409));var i=e.current,r=Oe();Xp(i,r,t,e,null,null)},Nl.prototype.unmount=Ku.prototype.unmount=function(){var t=this._internalRoot;if(t!==null){this._internalRoot=null;var e=t.containerInfo;Xp(t.current,2,null,t,null,null),bl(),e[Gi]=null}};function Nl(t){this._internalRoot=t}Nl.prototype.unstable_scheduleHydration=function(t){if(t){var e=yh();t={blockedOn:null,target:t,priority:e};for(var i=0;i<ii.length&&e!==0&&e<ii[i].priority;i++);ii.splice(i,0,t),i===0&&Jp(t)}};var eg=a.version;if(eg!=="19.1.0")throw Error(l(527,eg,"19.1.0"));Y.findDOMNode=function(t){var e=t._reactInternals;if(e===void 0)throw typeof t.render=="function"?Error(l(188)):(t=Object.keys(t).join(","),Error(l(268,t)));return t=p(e),t=t!==null?m(t):null,t=t===null?null:t.stateNode,t};var Q2={bundleType:0,version:"19.1.0",rendererPackageName:"react-dom",currentDispatcherRef:U,reconcilerVersion:"19.1.0"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var _l=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!_l.isDisabled&&_l.supportsFiber)try{Za=_l.inject(Q2),Ae=_l}catch{}}return $r.createRoot=function(t,e){if(!c(t))throw Error(l(299));var i=!1,r="",s=ym,u=xm,y=vm,v=null;return e!=null&&(e.unstable_strictMode===!0&&(i=!0),e.identifierPrefix!==void 0&&(r=e.identifierPrefix),e.onUncaughtError!==void 0&&(s=e.onUncaughtError),e.onCaughtError!==void 0&&(u=e.onCaughtError),e.onRecoverableError!==void 0&&(y=e.onRecoverableError),e.unstable_transitionCallbacks!==void 0&&(v=e.unstable_transitionCallbacks)),e=Fp(t,1,!1,null,null,i,r,s,u,y,v,null),t[Gi]=e.current,Du(t),new Ku(e)},$r.hydrateRoot=function(t,e,i){if(!c(t))throw Error(l(299));var r=!1,s="",u=ym,y=xm,v=vm,w=null,L=null;return i!=null&&(i.unstable_strictMode===!0&&(r=!0),i.identifierPrefix!==void 0&&(s=i.identifierPrefix),i.onUncaughtError!==void 0&&(u=i.onUncaughtError),i.onCaughtError!==void 0&&(y=i.onCaughtError),i.onRecoverableError!==void 0&&(v=i.onRecoverableError),i.unstable_transitionCallbacks!==void 0&&(w=i.unstable_transitionCallbacks),i.formState!==void 0&&(L=i.formState)),e=Fp(t,1,!0,e,i??null,r,s,u,y,v,w,L),e.context=Yp(null),i=e.current,r=Oe(),r=Ns(r),s=_n(r),s.callback=null,Hn(i,s,r),i=r,e.current.lanes=i,Wa(e,i),on(e),t[Gi]=e.current,Du(t),new Nl(e)},$r.version="19.1.0",$r}var fg;function o3(){if(fg)return Zu.exports;fg=1;function n(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)}catch(a){console.error(a)}}return n(),Zu.exports=r3(),Zu.exports}var l3=o3();/**
 * react-router v7.7.0
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */var dg="popstate";function s3(n={}){function a(l,c){let{pathname:f,search:d,hash:g}=l.location;return Nf("",{pathname:f,search:d,hash:g},c.state&&c.state.usr||null,c.state&&c.state.key||"default")}function o(l,c){return typeof c=="string"?c:so(c)}return u3(a,o,null,n)}function Pt(n,a){if(n===!1||n===null||typeof n>"u")throw new Error(a)}function fn(n,a){if(!n){typeof console<"u"&&console.warn(a);try{throw new Error(a)}catch{}}}function c3(){return Math.random().toString(36).substring(2,10)}function hg(n,a){return{usr:n.state,key:n.key,idx:a}}function Nf(n,a,o=null,l){return{pathname:typeof n=="string"?n:n.pathname,search:"",hash:"",...typeof a=="string"?qa(a):a,state:o,key:a&&a.key||l||c3()}}function so({pathname:n="/",search:a="",hash:o=""}){return a&&a!=="?"&&(n+=a.charAt(0)==="?"?a:"?"+a),o&&o!=="#"&&(n+=o.charAt(0)==="#"?o:"#"+o),n}function qa(n){let a={};if(n){let o=n.indexOf("#");o>=0&&(a.hash=n.substring(o),n=n.substring(0,o));let l=n.indexOf("?");l>=0&&(a.search=n.substring(l),n=n.substring(0,l)),n&&(a.pathname=n)}return a}function u3(n,a,o,l={}){let{window:c=document.defaultView,v5Compat:f=!1}=l,d=c.history,g="POP",p=null,m=x();m==null&&(m=0,d.replaceState({...d.state,idx:m},""));function x(){return(d.state||{idx:null}).idx}function A(){g="POP";let P=x(),R=P==null?null:P-m;m=P,p&&p({action:g,location:z.location,delta:R})}function b(P,R){g="PUSH";let H=Nf(z.location,P,R);m=x()+1;let V=hg(H,m),X=z.createHref(H);try{d.pushState(V,"",X)}catch(G){if(G instanceof DOMException&&G.name==="DataCloneError")throw G;c.location.assign(X)}f&&p&&p({action:g,location:z.location,delta:1})}function C(P,R){g="REPLACE";let H=Nf(z.location,P,R);m=x();let V=hg(H,m),X=z.createHref(H);d.replaceState(V,"",X),f&&p&&p({action:g,location:z.location,delta:0})}function O(P){return f3(P)}let z={get action(){return g},get location(){return n(c,d)},listen(P){if(p)throw new Error("A history only accepts one active listener");return c.addEventListener(dg,A),p=P,()=>{c.removeEventListener(dg,A),p=null}},createHref(P){return a(c,P)},createURL:O,encodeLocation(P){let R=O(P);return{pathname:R.pathname,search:R.search,hash:R.hash}},push:b,replace:C,go(P){return d.go(P)}};return z}function f3(n,a=!1){let o="http://localhost";typeof window<"u"&&(o=window.location.origin!=="null"?window.location.origin:window.location.href),Pt(o,"No window.location.(origin|href) available to create URL");let l=typeof n=="string"?n:so(n);return l=l.replace(/ $/,"%20"),!a&&l.startsWith("//")&&(l=o+l),new URL(l,o)}function i1(n,a,o="/"){return d3(n,a,o,!1)}function d3(n,a,o,l){let c=typeof a=="string"?qa(a):a,f=Ln(c.pathname||"/",o);if(f==null)return null;let d=a1(n);h3(d);let g=null;for(let p=0;g==null&&p<d.length;++p){let m=C3(f);g=A3(d[p],m,l)}return g}function a1(n,a=[],o=[],l=""){let c=(f,d,g)=>{let p={relativePath:g===void 0?f.path||"":g,caseSensitive:f.caseSensitive===!0,childrenIndex:d,route:f};p.relativePath.startsWith("/")&&(Pt(p.relativePath.startsWith(l),`Absolute route path "${p.relativePath}" nested under path "${l}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`),p.relativePath=p.relativePath.slice(l.length));let m=Rn([l,p.relativePath]),x=o.concat(p);f.children&&f.children.length>0&&(Pt(f.index!==!0,`Index routes must not have child routes. Please remove all child routes from route path "${m}".`),a1(f.children,a,x,m)),!(f.path==null&&!f.index)&&a.push({path:m,score:b3(m,f.index),routesMeta:x})};return n.forEach((f,d)=>{if(f.path===""||!f.path?.includes("?"))c(f,d);else for(let g of r1(f.path))c(f,d,g)}),a}function r1(n){let a=n.split("/");if(a.length===0)return[];let[o,...l]=a,c=o.endsWith("?"),f=o.replace(/\?$/,"");if(l.length===0)return c?[f,""]:[f];let d=r1(l.join("/")),g=[];return g.push(...d.map(p=>p===""?f:[f,p].join("/"))),c&&g.push(...d),g.map(p=>n.startsWith("/")&&p===""?"/":p)}function h3(n){n.sort((a,o)=>a.score!==o.score?o.score-a.score:S3(a.routesMeta.map(l=>l.childrenIndex),o.routesMeta.map(l=>l.childrenIndex)))}var m3=/^:[\w-]+$/,p3=3,g3=2,y3=1,x3=10,v3=-2,mg=n=>n==="*";function b3(n,a){let o=n.split("/"),l=o.length;return o.some(mg)&&(l+=v3),a&&(l+=g3),o.filter(c=>!mg(c)).reduce((c,f)=>c+(m3.test(f)?p3:f===""?y3:x3),l)}function S3(n,a){return n.length===a.length&&n.slice(0,-1).every((l,c)=>l===a[c])?n[n.length-1]-a[a.length-1]:0}function A3(n,a,o=!1){let{routesMeta:l}=n,c={},f="/",d=[];for(let g=0;g<l.length;++g){let p=l[g],m=g===l.length-1,x=f==="/"?a:a.slice(f.length)||"/",A=fs({path:p.relativePath,caseSensitive:p.caseSensitive,end:m},x),b=p.route;if(!A&&m&&o&&!l[l.length-1].route.index&&(A=fs({path:p.relativePath,caseSensitive:p.caseSensitive,end:!1},x)),!A)return null;Object.assign(c,A.params),d.push({params:c,pathname:Rn([f,A.pathname]),pathnameBase:j3(Rn([f,A.pathnameBase])),route:b}),A.pathnameBase!=="/"&&(f=Rn([f,A.pathnameBase]))}return d}function fs(n,a){typeof n=="string"&&(n={path:n,caseSensitive:!1,end:!0});let[o,l]=w3(n.path,n.caseSensitive,n.end),c=a.match(o);if(!c)return null;let f=c[0],d=f.replace(/(.)\/+$/,"$1"),g=c.slice(1);return{params:l.reduce((m,{paramName:x,isOptional:A},b)=>{if(x==="*"){let O=g[b]||"";d=f.slice(0,f.length-O.length).replace(/(.)\/+$/,"$1")}const C=g[b];return A&&!C?m[x]=void 0:m[x]=(C||"").replace(/%2F/g,"/"),m},{}),pathname:f,pathnameBase:d,pattern:n}}function w3(n,a=!1,o=!0){fn(n==="*"||!n.endsWith("*")||n.endsWith("/*"),`Route path "${n}" will be treated as if it were "${n.replace(/\*$/,"/*")}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${n.replace(/\*$/,"/*")}".`);let l=[],c="^"+n.replace(/\/*\*?$/,"").replace(/^\/*/,"/").replace(/[\\.*+^${}|()[\]]/g,"\\$&").replace(/\/:([\w-]+)(\?)?/g,(d,g,p)=>(l.push({paramName:g,isOptional:p!=null}),p?"/?([^\\/]+)?":"/([^\\/]+)"));return n.endsWith("*")?(l.push({paramName:"*"}),c+=n==="*"||n==="/*"?"(.*)$":"(?:\\/(.+)|\\/*)$"):o?c+="\\/*$":n!==""&&n!=="/"&&(c+="(?:(?=\\/|$))"),[new RegExp(c,a?void 0:"i"),l]}function C3(n){try{return n.split("/").map(a=>decodeURIComponent(a).replace(/\//g,"%2F")).join("/")}catch(a){return fn(!1,`The URL path "${n}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${a}).`),n}}function Ln(n,a){if(a==="/")return n;if(!n.toLowerCase().startsWith(a.toLowerCase()))return null;let o=a.endsWith("/")?a.length-1:a.length,l=n.charAt(o);return l&&l!=="/"?null:n.slice(o)||"/"}function T3(n,a="/"){let{pathname:o,search:l="",hash:c=""}=typeof n=="string"?qa(n):n;return{pathname:o?o.startsWith("/")?o:E3(o,a):a,search:O3(l),hash:D3(c)}}function E3(n,a){let o=a.replace(/\/+$/,"").split("/");return n.split("/").forEach(c=>{c===".."?o.length>1&&o.pop():c!=="."&&o.push(c)}),o.length>1?o.join("/"):"/"}function ef(n,a,o,l){return`Cannot include a '${n}' character in a manually specified \`to.${a}\` field [${JSON.stringify(l)}].  Please separate it out to the \`to.${o}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`}function M3(n){return n.filter((a,o)=>o===0||a.route.path&&a.route.path.length>0)}function o1(n){let a=M3(n);return a.map((o,l)=>l===a.length-1?o.pathname:o.pathnameBase)}function l1(n,a,o,l=!1){let c;typeof n=="string"?c=qa(n):(c={...n},Pt(!c.pathname||!c.pathname.includes("?"),ef("?","pathname","search",c)),Pt(!c.pathname||!c.pathname.includes("#"),ef("#","pathname","hash",c)),Pt(!c.search||!c.search.includes("#"),ef("#","search","hash",c)));let f=n===""||c.pathname==="",d=f?"/":c.pathname,g;if(d==null)g=o;else{let A=a.length-1;if(!l&&d.startsWith("..")){let b=d.split("/");for(;b[0]==="..";)b.shift(),A-=1;c.pathname=b.join("/")}g=A>=0?a[A]:"/"}let p=T3(c,g),m=d&&d!=="/"&&d.endsWith("/"),x=(f||d===".")&&o.endsWith("/");return!p.pathname.endsWith("/")&&(m||x)&&(p.pathname+="/"),p}var Rn=n=>n.join("/").replace(/\/\/+/g,"/"),j3=n=>n.replace(/\/+$/,"").replace(/^\/*/,"/"),O3=n=>!n||n==="?"?"":n.startsWith("?")?n:"?"+n,D3=n=>!n||n==="#"?"":n.startsWith("#")?n:"#"+n;function R3(n){return n!=null&&typeof n.status=="number"&&typeof n.statusText=="string"&&typeof n.internal=="boolean"&&"data"in n}var s1=["POST","PUT","PATCH","DELETE"];new Set(s1);var L3=["GET",...s1];new Set(L3);var Fa=E.createContext(null);Fa.displayName="DataRouter";var Cs=E.createContext(null);Cs.displayName="DataRouterState";E.createContext(!1);var c1=E.createContext({isTransitioning:!1});c1.displayName="ViewTransition";var B3=E.createContext(new Map);B3.displayName="Fetchers";var z3=E.createContext(null);z3.displayName="Await";var dn=E.createContext(null);dn.displayName="Navigation";var bo=E.createContext(null);bo.displayName="Location";var hn=E.createContext({outlet:null,matches:[],isDataRoute:!1});hn.displayName="Route";var gd=E.createContext(null);gd.displayName="RouteError";function k3(n,{relative:a}={}){Pt(So(),"useHref() may be used only in the context of a <Router> component.");let{basename:o,navigator:l}=E.useContext(dn),{hash:c,pathname:f,search:d}=Ao(n,{relative:a}),g=f;return o!=="/"&&(g=f==="/"?o:Rn([o,f])),l.createHref({pathname:g,search:d,hash:c})}function So(){return E.useContext(bo)!=null}function Hi(){return Pt(So(),"useLocation() may be used only in the context of a <Router> component."),E.useContext(bo).location}var u1="You should call navigate() in a React.useEffect(), not when your component is first rendered.";function f1(n){E.useContext(dn).static||E.useLayoutEffect(n)}function P3(){let{isDataRoute:n}=E.useContext(hn);return n?Z3():V3()}function V3(){Pt(So(),"useNavigate() may be used only in the context of a <Router> component.");let n=E.useContext(Fa),{basename:a,navigator:o}=E.useContext(dn),{matches:l}=E.useContext(hn),{pathname:c}=Hi(),f=JSON.stringify(o1(l)),d=E.useRef(!1);return f1(()=>{d.current=!0}),E.useCallback((p,m={})=>{if(fn(d.current,u1),!d.current)return;if(typeof p=="number"){o.go(p);return}let x=l1(p,JSON.parse(f),c,m.relative==="path");n==null&&a!=="/"&&(x.pathname=x.pathname==="/"?a:Rn([a,x.pathname])),(m.replace?o.replace:o.push)(x,m.state,m)},[a,o,f,c,n])}var U3=E.createContext(null);function N3(n){let a=E.useContext(hn).outlet;return a&&E.createElement(U3.Provider,{value:n},a)}function Ao(n,{relative:a}={}){let{matches:o}=E.useContext(hn),{pathname:l}=Hi(),c=JSON.stringify(o1(o));return E.useMemo(()=>l1(n,JSON.parse(c),l,a==="path"),[n,c,l,a])}function _3(n,a){return d1(n,a)}function d1(n,a,o,l){Pt(So(),"useRoutes() may be used only in the context of a <Router> component.");let{navigator:c}=E.useContext(dn),{matches:f}=E.useContext(hn),d=f[f.length-1],g=d?d.params:{},p=d?d.pathname:"/",m=d?d.pathnameBase:"/",x=d&&d.route;{let R=x&&x.path||"";h1(p,!x||R.endsWith("*")||R.endsWith("*?"),`You rendered descendant <Routes> (or called \`useRoutes()\`) at "${p}" (under <Route path="${R}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.

Please change the parent <Route path="${R}"> to <Route path="${R==="/"?"*":`${R}/*`}">.`)}let A=Hi(),b;if(a){let R=typeof a=="string"?qa(a):a;Pt(m==="/"||R.pathname?.startsWith(m),`When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${m}" but pathname "${R.pathname}" was given in the \`location\` prop.`),b=R}else b=A;let C=b.pathname||"/",O=C;if(m!=="/"){let R=m.replace(/^\//,"").split("/");O="/"+C.replace(/^\//,"").split("/").slice(R.length).join("/")}let z=i1(n,{pathname:O});fn(x||z!=null,`No routes matched location "${b.pathname}${b.search}${b.hash}" `),fn(z==null||z[z.length-1].route.element!==void 0||z[z.length-1].route.Component!==void 0||z[z.length-1].route.lazy!==void 0,`Matched leaf route at location "${b.pathname}${b.search}${b.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`);let P=F3(z&&z.map(R=>Object.assign({},R,{params:Object.assign({},g,R.params),pathname:Rn([m,c.encodeLocation?c.encodeLocation(R.pathname).pathname:R.pathname]),pathnameBase:R.pathnameBase==="/"?m:Rn([m,c.encodeLocation?c.encodeLocation(R.pathnameBase).pathname:R.pathnameBase])})),f,o,l);return a&&P?E.createElement(bo.Provider,{value:{location:{pathname:"/",search:"",hash:"",state:null,key:"default",...b},navigationType:"POP"}},P):P}function H3(){let n=Q3(),a=R3(n)?`${n.status} ${n.statusText}`:n instanceof Error?n.message:JSON.stringify(n),o=n instanceof Error?n.stack:null,l="rgba(200,200,200, 0.5)",c={padding:"0.5rem",backgroundColor:l},f={padding:"2px 4px",backgroundColor:l},d=null;return console.error("Error handled by React Router default ErrorBoundary:",n),d=E.createElement(E.Fragment,null,E.createElement("p",null,"💿 Hey developer 👋"),E.createElement("p",null,"You can provide a way better UX than this when your app throws errors by providing your own ",E.createElement("code",{style:f},"ErrorBoundary")," or"," ",E.createElement("code",{style:f},"errorElement")," prop on your route.")),E.createElement(E.Fragment,null,E.createElement("h2",null,"Unexpected Application Error!"),E.createElement("h3",{style:{fontStyle:"italic"}},a),o?E.createElement("pre",{style:c},o):null,d)}var G3=E.createElement(H3,null),I3=class extends E.Component{constructor(n){super(n),this.state={location:n.location,revalidation:n.revalidation,error:n.error}}static getDerivedStateFromError(n){return{error:n}}static getDerivedStateFromProps(n,a){return a.location!==n.location||a.revalidation!=="idle"&&n.revalidation==="idle"?{error:n.error,location:n.location,revalidation:n.revalidation}:{error:n.error!==void 0?n.error:a.error,location:a.location,revalidation:n.revalidation||a.revalidation}}componentDidCatch(n,a){console.error("React Router caught the following error during render",n,a)}render(){return this.state.error!==void 0?E.createElement(hn.Provider,{value:this.props.routeContext},E.createElement(gd.Provider,{value:this.state.error,children:this.props.component})):this.props.children}};function q3({routeContext:n,match:a,children:o}){let l=E.useContext(Fa);return l&&l.static&&l.staticContext&&(a.route.errorElement||a.route.ErrorBoundary)&&(l.staticContext._deepestRenderedBoundaryId=a.route.id),E.createElement(hn.Provider,{value:n},o)}function F3(n,a=[],o=null,l=null){if(n==null){if(!o)return null;if(o.errors)n=o.matches;else if(a.length===0&&!o.initialized&&o.matches.length>0)n=o.matches;else return null}let c=n,f=o?.errors;if(f!=null){let p=c.findIndex(m=>m.route.id&&f?.[m.route.id]!==void 0);Pt(p>=0,`Could not find a matching route for errors on route IDs: ${Object.keys(f).join(",")}`),c=c.slice(0,Math.min(c.length,p+1))}let d=!1,g=-1;if(o)for(let p=0;p<c.length;p++){let m=c[p];if((m.route.HydrateFallback||m.route.hydrateFallbackElement)&&(g=p),m.route.id){let{loaderData:x,errors:A}=o,b=m.route.loader&&!x.hasOwnProperty(m.route.id)&&(!A||A[m.route.id]===void 0);if(m.route.lazy||b){d=!0,g>=0?c=c.slice(0,g+1):c=[c[0]];break}}}return c.reduceRight((p,m,x)=>{let A,b=!1,C=null,O=null;o&&(A=f&&m.route.id?f[m.route.id]:void 0,C=m.route.errorElement||G3,d&&(g<0&&x===0?(h1("route-fallback",!1,"No `HydrateFallback` element provided to render during initial hydration"),b=!0,O=null):g===x&&(b=!0,O=m.route.hydrateFallbackElement||null)));let z=a.concat(c.slice(0,x+1)),P=()=>{let R;return A?R=C:b?R=O:m.route.Component?R=E.createElement(m.route.Component,null):m.route.element?R=m.route.element:R=p,E.createElement(q3,{match:m,routeContext:{outlet:p,matches:z,isDataRoute:o!=null},children:R})};return o&&(m.route.ErrorBoundary||m.route.errorElement||x===0)?E.createElement(I3,{location:o.location,revalidation:o.revalidation,component:C,error:A,children:P(),routeContext:{outlet:null,matches:z,isDataRoute:!0}}):P()},null)}function yd(n){return`${n} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function Y3(n){let a=E.useContext(Fa);return Pt(a,yd(n)),a}function X3(n){let a=E.useContext(Cs);return Pt(a,yd(n)),a}function K3(n){let a=E.useContext(hn);return Pt(a,yd(n)),a}function xd(n){let a=K3(n),o=a.matches[a.matches.length-1];return Pt(o.route.id,`${n} can only be used on routes that contain a unique "id"`),o.route.id}function $3(){return xd("useRouteId")}function Q3(){let n=E.useContext(gd),a=X3("useRouteError"),o=xd("useRouteError");return n!==void 0?n:a.errors?.[o]}function Z3(){let{router:n}=Y3("useNavigate"),a=xd("useNavigate"),o=E.useRef(!1);return f1(()=>{o.current=!0}),E.useCallback(async(c,f={})=>{fn(o.current,u1),o.current&&(typeof c=="number"?n.navigate(c):await n.navigate(c,{fromRouteId:a,...f}))},[n,a])}var pg={};function h1(n,a,o){!a&&!pg[n]&&(pg[n]=!0,fn(!1,o))}E.memo(J3);function J3({routes:n,future:a,state:o}){return d1(n,void 0,o,a)}function W3(n){return N3(n.context)}function Da(n){Pt(!1,"A <Route> is only ever to be used as the child of <Routes> element, never rendered directly. Please wrap your <Route> in a <Routes>.")}function tS({basename:n="/",children:a=null,location:o,navigationType:l="POP",navigator:c,static:f=!1}){Pt(!So(),"You cannot render a <Router> inside another <Router>. You should never have more than one in your app.");let d=n.replace(/^\/*/,"/"),g=E.useMemo(()=>({basename:d,navigator:c,static:f,future:{}}),[d,c,f]);typeof o=="string"&&(o=qa(o));let{pathname:p="/",search:m="",hash:x="",state:A=null,key:b="default"}=o,C=E.useMemo(()=>{let O=Ln(p,d);return O==null?null:{location:{pathname:O,search:m,hash:x,state:A,key:b},navigationType:l}},[d,p,m,x,A,b,l]);return fn(C!=null,`<Router basename="${d}"> is not able to match the URL "${p}${m}${x}" because it does not start with the basename, so the <Router> won't render anything.`),C==null?null:E.createElement(dn.Provider,{value:g},E.createElement(bo.Provider,{children:a,value:C}))}function eS({children:n,location:a}){return _3(_f(n),a)}function _f(n,a=[]){let o=[];return E.Children.forEach(n,(l,c)=>{if(!E.isValidElement(l))return;let f=[...a,c];if(l.type===E.Fragment){o.push.apply(o,_f(l.props.children,f));return}Pt(l.type===Da,`[${typeof l.type=="string"?l.type:l.type.name}] is not a <Route> component. All component children of <Routes> must be a <Route> or <React.Fragment>`),Pt(!l.props.index||!l.props.children,"An index route cannot have child routes.");let d={id:l.props.id||f.join("-"),caseSensitive:l.props.caseSensitive,element:l.props.element,Component:l.props.Component,index:l.props.index,path:l.props.path,loader:l.props.loader,action:l.props.action,hydrateFallbackElement:l.props.hydrateFallbackElement,HydrateFallback:l.props.HydrateFallback,errorElement:l.props.errorElement,ErrorBoundary:l.props.ErrorBoundary,hasErrorBoundary:l.props.hasErrorBoundary===!0||l.props.ErrorBoundary!=null||l.props.errorElement!=null,shouldRevalidate:l.props.shouldRevalidate,handle:l.props.handle,lazy:l.props.lazy};l.props.children&&(d.children=_f(l.props.children,f)),o.push(d)}),o}var ts="get",es="application/x-www-form-urlencoded";function Ts(n){return n!=null&&typeof n.tagName=="string"}function nS(n){return Ts(n)&&n.tagName.toLowerCase()==="button"}function iS(n){return Ts(n)&&n.tagName.toLowerCase()==="form"}function aS(n){return Ts(n)&&n.tagName.toLowerCase()==="input"}function rS(n){return!!(n.metaKey||n.altKey||n.ctrlKey||n.shiftKey)}function oS(n,a){return n.button===0&&(!a||a==="_self")&&!rS(n)}var Hl=null;function lS(){if(Hl===null)try{new FormData(document.createElement("form"),0),Hl=!1}catch{Hl=!0}return Hl}var sS=new Set(["application/x-www-form-urlencoded","multipart/form-data","text/plain"]);function nf(n){return n!=null&&!sS.has(n)?(fn(!1,`"${n}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${es}"`),null):n}function cS(n,a){let o,l,c,f,d;if(iS(n)){let g=n.getAttribute("action");l=g?Ln(g,a):null,o=n.getAttribute("method")||ts,c=nf(n.getAttribute("enctype"))||es,f=new FormData(n)}else if(nS(n)||aS(n)&&(n.type==="submit"||n.type==="image")){let g=n.form;if(g==null)throw new Error('Cannot submit a <button> or <input type="submit"> without a <form>');let p=n.getAttribute("formaction")||g.getAttribute("action");if(l=p?Ln(p,a):null,o=n.getAttribute("formmethod")||g.getAttribute("method")||ts,c=nf(n.getAttribute("formenctype"))||nf(g.getAttribute("enctype"))||es,f=new FormData(g,n),!lS()){let{name:m,type:x,value:A}=n;if(x==="image"){let b=m?`${m}.`:"";f.append(`${b}x`,"0"),f.append(`${b}y`,"0")}else m&&f.append(m,A)}}else{if(Ts(n))throw new Error('Cannot submit element that is not <form>, <button>, or <input type="submit|image">');o=ts,l=null,c=es,d=n}return f&&c==="text/plain"&&(d=f,f=void 0),{action:l,method:o.toLowerCase(),encType:c,formData:f,body:d}}Object.getOwnPropertyNames(Object.prototype).sort().join("\0");function vd(n,a){if(n===!1||n===null||typeof n>"u")throw new Error(a)}function uS(n,a,o){let l=typeof n=="string"?new URL(n,typeof window>"u"?"server://singlefetch/":window.location.origin):n;return l.pathname==="/"?l.pathname=`_root.${o}`:a&&Ln(l.pathname,a)==="/"?l.pathname=`${a.replace(/\/$/,"")}/_root.${o}`:l.pathname=`${l.pathname.replace(/\/$/,"")}.${o}`,l}async function fS(n,a){if(n.id in a)return a[n.id];try{let o=await import(n.module);return a[n.id]=o,o}catch(o){return console.error(`Error loading route module \`${n.module}\`, reloading page...`),console.error(o),window.__reactRouterContext&&window.__reactRouterContext.isSpaMode,window.location.reload(),new Promise(()=>{})}}function dS(n){return n==null?!1:n.href==null?n.rel==="preload"&&typeof n.imageSrcSet=="string"&&typeof n.imageSizes=="string":typeof n.rel=="string"&&typeof n.href=="string"}async function hS(n,a,o){let l=await Promise.all(n.map(async c=>{let f=a.routes[c.route.id];if(f){let d=await fS(f,o);return d.links?d.links():[]}return[]}));return yS(l.flat(1).filter(dS).filter(c=>c.rel==="stylesheet"||c.rel==="preload").map(c=>c.rel==="stylesheet"?{...c,rel:"prefetch",as:"style"}:{...c,rel:"prefetch"}))}function gg(n,a,o,l,c,f){let d=(p,m)=>o[m]?p.route.id!==o[m].route.id:!0,g=(p,m)=>o[m].pathname!==p.pathname||o[m].route.path?.endsWith("*")&&o[m].params["*"]!==p.params["*"];return f==="assets"?a.filter((p,m)=>d(p,m)||g(p,m)):f==="data"?a.filter((p,m)=>{let x=l.routes[p.route.id];if(!x||!x.hasLoader)return!1;if(d(p,m)||g(p,m))return!0;if(p.route.shouldRevalidate){let A=p.route.shouldRevalidate({currentUrl:new URL(c.pathname+c.search+c.hash,window.origin),currentParams:o[0]?.params||{},nextUrl:new URL(n,window.origin),nextParams:p.params,defaultShouldRevalidate:!0});if(typeof A=="boolean")return A}return!0}):[]}function mS(n,a,{includeHydrateFallback:o}={}){return pS(n.map(l=>{let c=a.routes[l.route.id];if(!c)return[];let f=[c.module];return c.clientActionModule&&(f=f.concat(c.clientActionModule)),c.clientLoaderModule&&(f=f.concat(c.clientLoaderModule)),o&&c.hydrateFallbackModule&&(f=f.concat(c.hydrateFallbackModule)),c.imports&&(f=f.concat(c.imports)),f}).flat(1))}function pS(n){return[...new Set(n)]}function gS(n){let a={},o=Object.keys(n).sort();for(let l of o)a[l]=n[l];return a}function yS(n,a){let o=new Set;return new Set(a),n.reduce((l,c)=>{let f=JSON.stringify(gS(c));return o.has(f)||(o.add(f),l.push({key:f,link:c})),l},[])}function m1(){let n=E.useContext(Fa);return vd(n,"You must render this element inside a <DataRouterContext.Provider> element"),n}function xS(){let n=E.useContext(Cs);return vd(n,"You must render this element inside a <DataRouterStateContext.Provider> element"),n}var bd=E.createContext(void 0);bd.displayName="FrameworkContext";function p1(){let n=E.useContext(bd);return vd(n,"You must render this element inside a <HydratedRouter> element"),n}function vS(n,a){let o=E.useContext(bd),[l,c]=E.useState(!1),[f,d]=E.useState(!1),{onFocus:g,onBlur:p,onMouseEnter:m,onMouseLeave:x,onTouchStart:A}=a,b=E.useRef(null);E.useEffect(()=>{if(n==="render"&&d(!0),n==="viewport"){let z=R=>{R.forEach(H=>{d(H.isIntersecting)})},P=new IntersectionObserver(z,{threshold:.5});return b.current&&P.observe(b.current),()=>{P.disconnect()}}},[n]),E.useEffect(()=>{if(l){let z=setTimeout(()=>{d(!0)},100);return()=>{clearTimeout(z)}}},[l]);let C=()=>{c(!0)},O=()=>{c(!1),d(!1)};return o?n!=="intent"?[f,b,{}]:[f,b,{onFocus:Qr(g,C),onBlur:Qr(p,O),onMouseEnter:Qr(m,C),onMouseLeave:Qr(x,O),onTouchStart:Qr(A,C)}]:[!1,b,{}]}function Qr(n,a){return o=>{n&&n(o),o.defaultPrevented||a(o)}}function bS({page:n,...a}){let{router:o}=m1(),l=E.useMemo(()=>i1(o.routes,n,o.basename),[o.routes,n,o.basename]);return l?E.createElement(AS,{page:n,matches:l,...a}):null}function SS(n){let{manifest:a,routeModules:o}=p1(),[l,c]=E.useState([]);return E.useEffect(()=>{let f=!1;return hS(n,a,o).then(d=>{f||c(d)}),()=>{f=!0}},[n,a,o]),l}function AS({page:n,matches:a,...o}){let l=Hi(),{manifest:c,routeModules:f}=p1(),{basename:d}=m1(),{loaderData:g,matches:p}=xS(),m=E.useMemo(()=>gg(n,a,p,c,l,"data"),[n,a,p,c,l]),x=E.useMemo(()=>gg(n,a,p,c,l,"assets"),[n,a,p,c,l]),A=E.useMemo(()=>{if(n===l.pathname+l.search+l.hash)return[];let O=new Set,z=!1;if(a.forEach(R=>{let H=c.routes[R.route.id];!H||!H.hasLoader||(!m.some(V=>V.route.id===R.route.id)&&R.route.id in g&&f[R.route.id]?.shouldRevalidate||H.hasClientLoader?z=!0:O.add(R.route.id))}),O.size===0)return[];let P=uS(n,d,"data");return z&&O.size>0&&P.searchParams.set("_routes",a.filter(R=>O.has(R.route.id)).map(R=>R.route.id).join(",")),[P.pathname+P.search]},[d,g,l,c,m,a,n,f]),b=E.useMemo(()=>mS(x,c),[x,c]),C=SS(x);return E.createElement(E.Fragment,null,A.map(O=>E.createElement("link",{key:O,rel:"prefetch",as:"fetch",href:O,...o})),b.map(O=>E.createElement("link",{key:O,rel:"modulepreload",href:O,...o})),C.map(({key:O,link:z})=>E.createElement("link",{key:O,...z})))}function wS(...n){return a=>{n.forEach(o=>{typeof o=="function"?o(a):o!=null&&(o.current=a)})}}var g1=typeof window<"u"&&typeof window.document<"u"&&typeof window.document.createElement<"u";try{g1&&(window.__reactRouterVersion="7.7.0")}catch{}function CS({basename:n,children:a,window:o}){let l=E.useRef();l.current==null&&(l.current=s3({window:o,v5Compat:!0}));let c=l.current,[f,d]=E.useState({action:c.action,location:c.location}),g=E.useCallback(p=>{E.startTransition(()=>d(p))},[d]);return E.useLayoutEffect(()=>c.listen(g),[c,g]),E.createElement(tS,{basename:n,children:a,location:f.location,navigationType:f.action,navigator:c})}var y1=/^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,ui=E.forwardRef(function({onClick:a,discover:o="render",prefetch:l="none",relative:c,reloadDocument:f,replace:d,state:g,target:p,to:m,preventScrollReset:x,viewTransition:A,...b},C){let{basename:O}=E.useContext(dn),z=typeof m=="string"&&y1.test(m),P,R=!1;if(typeof m=="string"&&z&&(P=m,g1))try{let lt=new URL(window.location.href),vt=m.startsWith("//")?new URL(lt.protocol+m):new URL(m),Bt=Ln(vt.pathname,O);vt.origin===lt.origin&&Bt!=null?m=Bt+vt.search+vt.hash:R=!0}catch{fn(!1,`<Link to="${m}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`)}let H=k3(m,{relative:c}),[V,X,G]=vS(l,b),K=jS(m,{replace:d,state:g,target:p,preventScrollReset:x,relative:c,viewTransition:A});function F(lt){a&&a(lt),lt.defaultPrevented||K(lt)}let Z=E.createElement("a",{...b,...G,href:P||H,onClick:R||f?a:F,ref:wS(C,X),target:p,"data-discover":!z&&o==="render"?"true":void 0});return V&&!z?E.createElement(E.Fragment,null,Z,E.createElement(bS,{page:H})):Z});ui.displayName="Link";var TS=E.forwardRef(function({"aria-current":a="page",caseSensitive:o=!1,className:l="",end:c=!1,style:f,to:d,viewTransition:g,children:p,...m},x){let A=Ao(d,{relative:m.relative}),b=Hi(),C=E.useContext(Cs),{navigator:O,basename:z}=E.useContext(dn),P=C!=null&&BS(A)&&g===!0,R=O.encodeLocation?O.encodeLocation(A).pathname:A.pathname,H=b.pathname,V=C&&C.navigation&&C.navigation.location?C.navigation.location.pathname:null;o||(H=H.toLowerCase(),V=V?V.toLowerCase():null,R=R.toLowerCase()),V&&z&&(V=Ln(V,z)||V);const X=R!=="/"&&R.endsWith("/")?R.length-1:R.length;let G=H===R||!c&&H.startsWith(R)&&H.charAt(X)==="/",K=V!=null&&(V===R||!c&&V.startsWith(R)&&V.charAt(R.length)==="/"),F={isActive:G,isPending:K,isTransitioning:P},Z=G?a:void 0,lt;typeof l=="function"?lt=l(F):lt=[l,G?"active":null,K?"pending":null,P?"transitioning":null].filter(Boolean).join(" ");let vt=typeof f=="function"?f(F):f;return E.createElement(ui,{...m,"aria-current":Z,className:lt,ref:x,style:vt,to:d,viewTransition:g},typeof p=="function"?p(F):p)});TS.displayName="NavLink";var ES=E.forwardRef(({discover:n="render",fetcherKey:a,navigate:o,reloadDocument:l,replace:c,state:f,method:d=ts,action:g,onSubmit:p,relative:m,preventScrollReset:x,viewTransition:A,...b},C)=>{let O=RS(),z=LS(g,{relative:m}),P=d.toLowerCase()==="get"?"get":"post",R=typeof g=="string"&&y1.test(g),H=V=>{if(p&&p(V),V.defaultPrevented)return;V.preventDefault();let X=V.nativeEvent.submitter,G=X?.getAttribute("formmethod")||d;O(X||V.currentTarget,{fetcherKey:a,method:G,navigate:o,replace:c,state:f,relative:m,preventScrollReset:x,viewTransition:A})};return E.createElement("form",{ref:C,method:P,action:z,onSubmit:l?p:H,...b,"data-discover":!R&&n==="render"?"true":void 0})});ES.displayName="Form";function MS(n){return`${n} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function x1(n){let a=E.useContext(Fa);return Pt(a,MS(n)),a}function jS(n,{target:a,replace:o,state:l,preventScrollReset:c,relative:f,viewTransition:d}={}){let g=P3(),p=Hi(),m=Ao(n,{relative:f});return E.useCallback(x=>{if(oS(x,a)){x.preventDefault();let A=o!==void 0?o:so(p)===so(m);g(n,{replace:A,state:l,preventScrollReset:c,relative:f,viewTransition:d})}},[p,g,m,o,l,a,n,c,f,d])}var OS=0,DS=()=>`__${String(++OS)}__`;function RS(){let{router:n}=x1("useSubmit"),{basename:a}=E.useContext(dn),o=$3();return E.useCallback(async(l,c={})=>{let{action:f,method:d,encType:g,formData:p,body:m}=cS(l,a);if(c.navigate===!1){let x=c.fetcherKey||DS();await n.fetch(x,o,c.action||f,{preventScrollReset:c.preventScrollReset,formData:p,body:m,formMethod:c.method||d,formEncType:c.encType||g,flushSync:c.flushSync})}else await n.navigate(c.action||f,{preventScrollReset:c.preventScrollReset,formData:p,body:m,formMethod:c.method||d,formEncType:c.encType||g,replace:c.replace,state:c.state,fromRouteId:o,flushSync:c.flushSync,viewTransition:c.viewTransition})},[n,a,o])}function LS(n,{relative:a}={}){let{basename:o}=E.useContext(dn),l=E.useContext(hn);Pt(l,"useFormAction must be used inside a RouteContext");let[c]=l.matches.slice(-1),f={...Ao(n||".",{relative:a})},d=Hi();if(n==null){f.search=d.search;let g=new URLSearchParams(f.search),p=g.getAll("index");if(p.some(x=>x==="")){g.delete("index"),p.filter(A=>A).forEach(A=>g.append("index",A));let x=g.toString();f.search=x?`?${x}`:""}}return(!n||n===".")&&c.route.index&&(f.search=f.search?f.search.replace(/^\?/,"?index&"):"?index"),o!=="/"&&(f.pathname=f.pathname==="/"?o:Rn([o,f.pathname])),so(f)}function BS(n,a={}){let o=E.useContext(c1);Pt(o!=null,"`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?");let{basename:l}=x1("useViewTransitionState"),c=Ao(n,{relative:a.relative});if(!o.isTransitioning)return!1;let f=Ln(o.currentLocation.pathname,l)||o.currentLocation.pathname,d=Ln(o.nextLocation.pathname,l)||o.nextLocation.pathname;return fs(c.pathname,d)!=null||fs(c.pathname,f)!=null}var ae=function(){return ae=Object.assign||function(a){for(var o,l=1,c=arguments.length;l<c;l++){o=arguments[l];for(var f in o)Object.prototype.hasOwnProperty.call(o,f)&&(a[f]=o[f])}return a},ae.apply(this,arguments)};function Va(n,a,o){if(o||arguments.length===2)for(var l=0,c=a.length,f;l<c;l++)(f||!(l in a))&&(f||(f=Array.prototype.slice.call(a,0,l)),f[l]=a[l]);return n.concat(f||Array.prototype.slice.call(a))}var Dt="-ms-",no="-moz-",At="-webkit-",v1="comm",Es="rule",Sd="decl",zS="@import",b1="@keyframes",kS="@layer",S1=Math.abs,Ad=String.fromCharCode,Hf=Object.assign;function PS(n,a){return ne(n,0)^45?(((a<<2^ne(n,0))<<2^ne(n,1))<<2^ne(n,2))<<2^ne(n,3):0}function A1(n){return n.trim()}function Dn(n,a){return(n=a.exec(n))?n[0]:n}function ut(n,a,o){return n.replace(a,o)}function ns(n,a,o){return n.indexOf(a,o)}function ne(n,a){return n.charCodeAt(a)|0}function Ua(n,a,o){return n.slice(a,o)}function ln(n){return n.length}function w1(n){return n.length}function to(n,a){return a.push(n),n}function VS(n,a){return n.map(a).join("")}function yg(n,a){return n.filter(function(o){return!Dn(o,a)})}var Ms=1,Na=1,C1=0,Ye=0,Xt=0,Ya="";function js(n,a,o,l,c,f,d,g){return{value:n,root:a,parent:o,type:l,props:c,children:f,line:Ms,column:Na,length:d,return:"",siblings:g}}function ri(n,a){return Hf(js("",null,null,"",null,null,0,n.siblings),n,{length:-n.length},a)}function Ma(n){for(;n.root;)n=ri(n.root,{children:[n]});to(n,n.siblings)}function US(){return Xt}function NS(){return Xt=Ye>0?ne(Ya,--Ye):0,Na--,Xt===10&&(Na=1,Ms--),Xt}function We(){return Xt=Ye<C1?ne(Ya,Ye++):0,Na++,Xt===10&&(Na=1,Ms++),Xt}function Pi(){return ne(Ya,Ye)}function is(){return Ye}function Os(n,a){return Ua(Ya,n,a)}function Gf(n){switch(n){case 0:case 9:case 10:case 13:case 32:return 5;case 33:case 43:case 44:case 47:case 62:case 64:case 126:case 59:case 123:case 125:return 4;case 58:return 3;case 34:case 39:case 40:case 91:return 2;case 41:case 93:return 1}return 0}function _S(n){return Ms=Na=1,C1=ln(Ya=n),Ye=0,[]}function HS(n){return Ya="",n}function af(n){return A1(Os(Ye-1,If(n===91?n+2:n===40?n+1:n)))}function GS(n){for(;(Xt=Pi())&&Xt<33;)We();return Gf(n)>2||Gf(Xt)>3?"":" "}function IS(n,a){for(;--a&&We()&&!(Xt<48||Xt>102||Xt>57&&Xt<65||Xt>70&&Xt<97););return Os(n,is()+(a<6&&Pi()==32&&We()==32))}function If(n){for(;We();)switch(Xt){case n:return Ye;case 34:case 39:n!==34&&n!==39&&If(Xt);break;case 40:n===41&&If(n);break;case 92:We();break}return Ye}function qS(n,a){for(;We()&&n+Xt!==57;)if(n+Xt===84&&Pi()===47)break;return"/*"+Os(a,Ye-1)+"*"+Ad(n===47?n:We())}function FS(n){for(;!Gf(Pi());)We();return Os(n,Ye)}function YS(n){return HS(as("",null,null,null,[""],n=_S(n),0,[0],n))}function as(n,a,o,l,c,f,d,g,p){for(var m=0,x=0,A=d,b=0,C=0,O=0,z=1,P=1,R=1,H=0,V="",X=c,G=f,K=l,F=V;P;)switch(O=H,H=We()){case 40:if(O!=108&&ne(F,A-1)==58){ns(F+=ut(af(H),"&","&\f"),"&\f",S1(m?g[m-1]:0))!=-1&&(R=-1);break}case 34:case 39:case 91:F+=af(H);break;case 9:case 10:case 13:case 32:F+=GS(O);break;case 92:F+=IS(is()-1,7);continue;case 47:switch(Pi()){case 42:case 47:to(XS(qS(We(),is()),a,o,p),p);break;default:F+="/"}break;case 123*z:g[m++]=ln(F)*R;case 125*z:case 59:case 0:switch(H){case 0:case 125:P=0;case 59+x:R==-1&&(F=ut(F,/\f/g,"")),C>0&&ln(F)-A&&to(C>32?vg(F+";",l,o,A-1,p):vg(ut(F," ","")+";",l,o,A-2,p),p);break;case 59:F+=";";default:if(to(K=xg(F,a,o,m,x,c,g,V,X=[],G=[],A,f),f),H===123)if(x===0)as(F,a,K,K,X,f,A,g,G);else switch(b===99&&ne(F,3)===110?100:b){case 100:case 108:case 109:case 115:as(n,K,K,l&&to(xg(n,K,K,0,0,c,g,V,c,X=[],A,G),G),c,G,A,g,l?X:G);break;default:as(F,K,K,K,[""],G,0,g,G)}}m=x=C=0,z=R=1,V=F="",A=d;break;case 58:A=1+ln(F),C=O;default:if(z<1){if(H==123)--z;else if(H==125&&z++==0&&NS()==125)continue}switch(F+=Ad(H),H*z){case 38:R=x>0?1:(F+="\f",-1);break;case 44:g[m++]=(ln(F)-1)*R,R=1;break;case 64:Pi()===45&&(F+=af(We())),b=Pi(),x=A=ln(V=F+=FS(is())),H++;break;case 45:O===45&&ln(F)==2&&(z=0)}}return f}function xg(n,a,o,l,c,f,d,g,p,m,x,A){for(var b=c-1,C=c===0?f:[""],O=w1(C),z=0,P=0,R=0;z<l;++z)for(var H=0,V=Ua(n,b+1,b=S1(P=d[z])),X=n;H<O;++H)(X=A1(P>0?C[H]+" "+V:ut(V,/&\f/g,C[H])))&&(p[R++]=X);return js(n,a,o,c===0?Es:g,p,m,x,A)}function XS(n,a,o,l){return js(n,a,o,v1,Ad(US()),Ua(n,2,-2),0,l)}function vg(n,a,o,l,c){return js(n,a,o,Sd,Ua(n,0,l),Ua(n,l+1,-1),l,c)}function T1(n,a,o){switch(PS(n,a)){case 5103:return At+"print-"+n+n;case 5737:case 4201:case 3177:case 3433:case 1641:case 4457:case 2921:case 5572:case 6356:case 5844:case 3191:case 6645:case 3005:case 6391:case 5879:case 5623:case 6135:case 4599:case 4855:case 4215:case 6389:case 5109:case 5365:case 5621:case 3829:return At+n+n;case 4789:return no+n+n;case 5349:case 4246:case 4810:case 6968:case 2756:return At+n+no+n+Dt+n+n;case 5936:switch(ne(n,a+11)){case 114:return At+n+Dt+ut(n,/[svh]\w+-[tblr]{2}/,"tb")+n;case 108:return At+n+Dt+ut(n,/[svh]\w+-[tblr]{2}/,"tb-rl")+n;case 45:return At+n+Dt+ut(n,/[svh]\w+-[tblr]{2}/,"lr")+n}case 6828:case 4268:case 2903:return At+n+Dt+n+n;case 6165:return At+n+Dt+"flex-"+n+n;case 5187:return At+n+ut(n,/(\w+).+(:[^]+)/,At+"box-$1$2"+Dt+"flex-$1$2")+n;case 5443:return At+n+Dt+"flex-item-"+ut(n,/flex-|-self/g,"")+(Dn(n,/flex-|baseline/)?"":Dt+"grid-row-"+ut(n,/flex-|-self/g,""))+n;case 4675:return At+n+Dt+"flex-line-pack"+ut(n,/align-content|flex-|-self/g,"")+n;case 5548:return At+n+Dt+ut(n,"shrink","negative")+n;case 5292:return At+n+Dt+ut(n,"basis","preferred-size")+n;case 6060:return At+"box-"+ut(n,"-grow","")+At+n+Dt+ut(n,"grow","positive")+n;case 4554:return At+ut(n,/([^-])(transform)/g,"$1"+At+"$2")+n;case 6187:return ut(ut(ut(n,/(zoom-|grab)/,At+"$1"),/(image-set)/,At+"$1"),n,"")+n;case 5495:case 3959:return ut(n,/(image-set\([^]*)/,At+"$1$`$1");case 4968:return ut(ut(n,/(.+:)(flex-)?(.*)/,At+"box-pack:$3"+Dt+"flex-pack:$3"),/s.+-b[^;]+/,"justify")+At+n+n;case 4200:if(!Dn(n,/flex-|baseline/))return Dt+"grid-column-align"+Ua(n,a)+n;break;case 2592:case 3360:return Dt+ut(n,"template-","")+n;case 4384:case 3616:return o&&o.some(function(l,c){return a=c,Dn(l.props,/grid-\w+-end/)})?~ns(n+(o=o[a].value),"span",0)?n:Dt+ut(n,"-start","")+n+Dt+"grid-row-span:"+(~ns(o,"span",0)?Dn(o,/\d+/):+Dn(o,/\d+/)-+Dn(n,/\d+/))+";":Dt+ut(n,"-start","")+n;case 4896:case 4128:return o&&o.some(function(l){return Dn(l.props,/grid-\w+-start/)})?n:Dt+ut(ut(n,"-end","-span"),"span ","")+n;case 4095:case 3583:case 4068:case 2532:return ut(n,/(.+)-inline(.+)/,At+"$1$2")+n;case 8116:case 7059:case 5753:case 5535:case 5445:case 5701:case 4933:case 4677:case 5533:case 5789:case 5021:case 4765:if(ln(n)-1-a>6)switch(ne(n,a+1)){case 109:if(ne(n,a+4)!==45)break;case 102:return ut(n,/(.+:)(.+)-([^]+)/,"$1"+At+"$2-$3$1"+no+(ne(n,a+3)==108?"$3":"$2-$3"))+n;case 115:return~ns(n,"stretch",0)?T1(ut(n,"stretch","fill-available"),a,o)+n:n}break;case 5152:case 5920:return ut(n,/(.+?):(\d+)(\s*\/\s*(span)?\s*(\d+))?(.*)/,function(l,c,f,d,g,p,m){return Dt+c+":"+f+m+(d?Dt+c+"-span:"+(g?p:+p-+f)+m:"")+n});case 4949:if(ne(n,a+6)===121)return ut(n,":",":"+At)+n;break;case 6444:switch(ne(n,ne(n,14)===45?18:11)){case 120:return ut(n,/(.+:)([^;\s!]+)(;|(\s+)?!.+)?/,"$1"+At+(ne(n,14)===45?"inline-":"")+"box$3$1"+At+"$2$3$1"+Dt+"$2box$3")+n;case 100:return ut(n,":",":"+Dt)+n}break;case 5719:case 2647:case 2135:case 3927:case 2391:return ut(n,"scroll-","scroll-snap-")+n}return n}function ds(n,a){for(var o="",l=0;l<n.length;l++)o+=a(n[l],l,n,a)||"";return o}function KS(n,a,o,l){switch(n.type){case kS:if(n.children.length)break;case zS:case Sd:return n.return=n.return||n.value;case v1:return"";case b1:return n.return=n.value+"{"+ds(n.children,l)+"}";case Es:if(!ln(n.value=n.props.join(",")))return""}return ln(o=ds(n.children,l))?n.return=n.value+"{"+o+"}":""}function $S(n){var a=w1(n);return function(o,l,c,f){for(var d="",g=0;g<a;g++)d+=n[g](o,l,c,f)||"";return d}}function QS(n){return function(a){a.root||(a=a.return)&&n(a)}}function ZS(n,a,o,l){if(n.length>-1&&!n.return)switch(n.type){case Sd:n.return=T1(n.value,n.length,o);return;case b1:return ds([ri(n,{value:ut(n.value,"@","@"+At)})],l);case Es:if(n.length)return VS(o=n.props,function(c){switch(Dn(c,l=/(::plac\w+|:read-\w+)/)){case":read-only":case":read-write":Ma(ri(n,{props:[ut(c,/:(read-\w+)/,":"+no+"$1")]})),Ma(ri(n,{props:[c]})),Hf(n,{props:yg(o,l)});break;case"::placeholder":Ma(ri(n,{props:[ut(c,/:(plac\w+)/,":"+At+"input-$1")]})),Ma(ri(n,{props:[ut(c,/:(plac\w+)/,":"+no+"$1")]})),Ma(ri(n,{props:[ut(c,/:(plac\w+)/,Dt+"input-$1")]})),Ma(ri(n,{props:[c]})),Hf(n,{props:yg(o,l)});break}return""})}}var JS={animationIterationCount:1,aspectRatio:1,borderImageOutset:1,borderImageSlice:1,borderImageWidth:1,boxFlex:1,boxFlexGroup:1,boxOrdinalGroup:1,columnCount:1,columns:1,flex:1,flexGrow:1,flexPositive:1,flexShrink:1,flexNegative:1,flexOrder:1,gridRow:1,gridRowEnd:1,gridRowSpan:1,gridRowStart:1,gridColumn:1,gridColumnEnd:1,gridColumnSpan:1,gridColumnStart:1,msGridRow:1,msGridRowSpan:1,msGridColumn:1,msGridColumnSpan:1,fontWeight:1,lineHeight:1,opacity:1,order:1,orphans:1,tabSize:1,widows:1,zIndex:1,zoom:1,WebkitLineClamp:1,fillOpacity:1,floodOpacity:1,stopOpacity:1,strokeDasharray:1,strokeDashoffset:1,strokeMiterlimit:1,strokeOpacity:1,strokeWidth:1},Re={},_a=typeof process<"u"&&Re!==void 0&&(Re.REACT_APP_SC_ATTR||Re.SC_ATTR)||"data-styled",E1="active",M1="data-styled-version",Ds="6.1.19",wd=`/*!sc*/
`,hs=typeof window<"u"&&typeof document<"u",WS=!!(typeof SC_DISABLE_SPEEDY=="boolean"?SC_DISABLE_SPEEDY:typeof process<"u"&&Re!==void 0&&Re.REACT_APP_SC_DISABLE_SPEEDY!==void 0&&Re.REACT_APP_SC_DISABLE_SPEEDY!==""?Re.REACT_APP_SC_DISABLE_SPEEDY!=="false"&&Re.REACT_APP_SC_DISABLE_SPEEDY:typeof process<"u"&&Re!==void 0&&Re.SC_DISABLE_SPEEDY!==void 0&&Re.SC_DISABLE_SPEEDY!==""&&Re.SC_DISABLE_SPEEDY!=="false"&&Re.SC_DISABLE_SPEEDY),t5={},Rs=Object.freeze([]),Ha=Object.freeze({});function j1(n,a,o){return o===void 0&&(o=Ha),n.theme!==o.theme&&n.theme||a||o.theme}var O1=new Set(["a","abbr","address","area","article","aside","audio","b","base","bdi","bdo","big","blockquote","body","br","button","canvas","caption","cite","code","col","colgroup","data","datalist","dd","del","details","dfn","dialog","div","dl","dt","em","embed","fieldset","figcaption","figure","footer","form","h1","h2","h3","h4","h5","h6","header","hgroup","hr","html","i","iframe","img","input","ins","kbd","keygen","label","legend","li","link","main","map","mark","menu","menuitem","meta","meter","nav","noscript","object","ol","optgroup","option","output","p","param","picture","pre","progress","q","rp","rt","ruby","s","samp","script","section","select","small","source","span","strong","style","sub","summary","sup","table","tbody","td","textarea","tfoot","th","thead","time","tr","track","u","ul","use","var","video","wbr","circle","clipPath","defs","ellipse","foreignObject","g","image","line","linearGradient","marker","mask","path","pattern","polygon","polyline","radialGradient","rect","stop","svg","text","tspan"]),e5=/[!"#$%&'()*+,./:;<=>?@[\\\]^`{|}~-]+/g,n5=/(^-|-$)/g;function bg(n){return n.replace(e5,"-").replace(n5,"")}var i5=/(a)(d)/gi,Gl=52,Sg=function(n){return String.fromCharCode(n+(n>25?39:97))};function qf(n){var a,o="";for(a=Math.abs(n);a>Gl;a=a/Gl|0)o=Sg(a%Gl)+o;return(Sg(a%Gl)+o).replace(i5,"$1-$2")}var rf,D1=5381,Ra=function(n,a){for(var o=a.length;o;)n=33*n^a.charCodeAt(--o);return n},R1=function(n){return Ra(D1,n)};function Cd(n){return qf(R1(n)>>>0)}function a5(n){return n.displayName||n.name||"Component"}function of(n){return typeof n=="string"&&!0}var L1=typeof Symbol=="function"&&Symbol.for,B1=L1?Symbol.for("react.memo"):60115,r5=L1?Symbol.for("react.forward_ref"):60112,o5={childContextTypes:!0,contextType:!0,contextTypes:!0,defaultProps:!0,displayName:!0,getDefaultProps:!0,getDerivedStateFromError:!0,getDerivedStateFromProps:!0,mixins:!0,propTypes:!0,type:!0},l5={name:!0,length:!0,prototype:!0,caller:!0,callee:!0,arguments:!0,arity:!0},z1={$$typeof:!0,compare:!0,defaultProps:!0,displayName:!0,propTypes:!0,type:!0},s5=((rf={})[r5]={$$typeof:!0,render:!0,defaultProps:!0,displayName:!0,propTypes:!0},rf[B1]=z1,rf);function Ag(n){return("type"in(a=n)&&a.type.$$typeof)===B1?z1:"$$typeof"in n?s5[n.$$typeof]:o5;var a}var c5=Object.defineProperty,u5=Object.getOwnPropertyNames,wg=Object.getOwnPropertySymbols,f5=Object.getOwnPropertyDescriptor,d5=Object.getPrototypeOf,Cg=Object.prototype;function k1(n,a,o){if(typeof a!="string"){if(Cg){var l=d5(a);l&&l!==Cg&&k1(n,l,o)}var c=u5(a);wg&&(c=c.concat(wg(a)));for(var f=Ag(n),d=Ag(a),g=0;g<c.length;++g){var p=c[g];if(!(p in l5||o&&o[p]||d&&p in d||f&&p in f)){var m=f5(a,p);try{c5(n,p,m)}catch{}}}}return n}function Ni(n){return typeof n=="function"}function Td(n){return typeof n=="object"&&"styledComponentId"in n}function Bi(n,a){return n&&a?"".concat(n," ").concat(a):n||a||""}function ms(n,a){if(n.length===0)return"";for(var o=n[0],l=1;l<n.length;l++)o+=n[l];return o}function co(n){return n!==null&&typeof n=="object"&&n.constructor.name===Object.name&&!("props"in n&&n.$$typeof)}function Ff(n,a,o){if(o===void 0&&(o=!1),!o&&!co(n)&&!Array.isArray(n))return a;if(Array.isArray(a))for(var l=0;l<a.length;l++)n[l]=Ff(n[l],a[l]);else if(co(a))for(var l in a)n[l]=Ff(n[l],a[l]);return n}function Ed(n,a){Object.defineProperty(n,"toString",{value:a})}function _i(n){for(var a=[],o=1;o<arguments.length;o++)a[o-1]=arguments[o];return new Error("An error occurred. See https://github.com/styled-components/styled-components/blob/main/packages/styled-components/src/utils/errors.md#".concat(n," for more information.").concat(a.length>0?" Args: ".concat(a.join(", ")):""))}var h5=function(){function n(a){this.groupSizes=new Uint32Array(512),this.length=512,this.tag=a}return n.prototype.indexOfGroup=function(a){for(var o=0,l=0;l<a;l++)o+=this.groupSizes[l];return o},n.prototype.insertRules=function(a,o){if(a>=this.groupSizes.length){for(var l=this.groupSizes,c=l.length,f=c;a>=f;)if((f<<=1)<0)throw _i(16,"".concat(a));this.groupSizes=new Uint32Array(f),this.groupSizes.set(l),this.length=f;for(var d=c;d<f;d++)this.groupSizes[d]=0}for(var g=this.indexOfGroup(a+1),p=(d=0,o.length);d<p;d++)this.tag.insertRule(g,o[d])&&(this.groupSizes[a]++,g++)},n.prototype.clearGroup=function(a){if(a<this.length){var o=this.groupSizes[a],l=this.indexOfGroup(a),c=l+o;this.groupSizes[a]=0;for(var f=l;f<c;f++)this.tag.deleteRule(l)}},n.prototype.getGroup=function(a){var o="";if(a>=this.length||this.groupSizes[a]===0)return o;for(var l=this.groupSizes[a],c=this.indexOfGroup(a),f=c+l,d=c;d<f;d++)o+="".concat(this.tag.getRule(d)).concat(wd);return o},n}(),rs=new Map,ps=new Map,os=1,Il=function(n){if(rs.has(n))return rs.get(n);for(;ps.has(os);)os++;var a=os++;return rs.set(n,a),ps.set(a,n),a},m5=function(n,a){os=a+1,rs.set(n,a),ps.set(a,n)},p5="style[".concat(_a,"][").concat(M1,'="').concat(Ds,'"]'),g5=new RegExp("^".concat(_a,'\\.g(\\d+)\\[id="([\\w\\d-]+)"\\].*?"([^"]*)')),y5=function(n,a,o){for(var l,c=o.split(","),f=0,d=c.length;f<d;f++)(l=c[f])&&n.registerName(a,l)},x5=function(n,a){for(var o,l=((o=a.textContent)!==null&&o!==void 0?o:"").split(wd),c=[],f=0,d=l.length;f<d;f++){var g=l[f].trim();if(g){var p=g.match(g5);if(p){var m=0|parseInt(p[1],10),x=p[2];m!==0&&(m5(x,m),y5(n,x,p[3]),n.getTag().insertRules(m,c)),c.length=0}else c.push(g)}}},Tg=function(n){for(var a=document.querySelectorAll(p5),o=0,l=a.length;o<l;o++){var c=a[o];c&&c.getAttribute(_a)!==E1&&(x5(n,c),c.parentNode&&c.parentNode.removeChild(c))}};function v5(){return typeof __webpack_nonce__<"u"?__webpack_nonce__:null}var P1=function(n){var a=document.head,o=n||a,l=document.createElement("style"),c=function(g){var p=Array.from(g.querySelectorAll("style[".concat(_a,"]")));return p[p.length-1]}(o),f=c!==void 0?c.nextSibling:null;l.setAttribute(_a,E1),l.setAttribute(M1,Ds);var d=v5();return d&&l.setAttribute("nonce",d),o.insertBefore(l,f),l},b5=function(){function n(a){this.element=P1(a),this.element.appendChild(document.createTextNode("")),this.sheet=function(o){if(o.sheet)return o.sheet;for(var l=document.styleSheets,c=0,f=l.length;c<f;c++){var d=l[c];if(d.ownerNode===o)return d}throw _i(17)}(this.element),this.length=0}return n.prototype.insertRule=function(a,o){try{return this.sheet.insertRule(o,a),this.length++,!0}catch{return!1}},n.prototype.deleteRule=function(a){this.sheet.deleteRule(a),this.length--},n.prototype.getRule=function(a){var o=this.sheet.cssRules[a];return o&&o.cssText?o.cssText:""},n}(),S5=function(){function n(a){this.element=P1(a),this.nodes=this.element.childNodes,this.length=0}return n.prototype.insertRule=function(a,o){if(a<=this.length&&a>=0){var l=document.createTextNode(o);return this.element.insertBefore(l,this.nodes[a]||null),this.length++,!0}return!1},n.prototype.deleteRule=function(a){this.element.removeChild(this.nodes[a]),this.length--},n.prototype.getRule=function(a){return a<this.length?this.nodes[a].textContent:""},n}(),A5=function(){function n(a){this.rules=[],this.length=0}return n.prototype.insertRule=function(a,o){return a<=this.length&&(this.rules.splice(a,0,o),this.length++,!0)},n.prototype.deleteRule=function(a){this.rules.splice(a,1),this.length--},n.prototype.getRule=function(a){return a<this.length?this.rules[a]:""},n}(),Eg=hs,w5={isServer:!hs,useCSSOMInjection:!WS},gs=function(){function n(a,o,l){a===void 0&&(a=Ha),o===void 0&&(o={});var c=this;this.options=ae(ae({},w5),a),this.gs=o,this.names=new Map(l),this.server=!!a.isServer,!this.server&&hs&&Eg&&(Eg=!1,Tg(this)),Ed(this,function(){return function(f){for(var d=f.getTag(),g=d.length,p="",m=function(A){var b=function(R){return ps.get(R)}(A);if(b===void 0)return"continue";var C=f.names.get(b),O=d.getGroup(A);if(C===void 0||!C.size||O.length===0)return"continue";var z="".concat(_a,".g").concat(A,'[id="').concat(b,'"]'),P="";C!==void 0&&C.forEach(function(R){R.length>0&&(P+="".concat(R,","))}),p+="".concat(O).concat(z,'{content:"').concat(P,'"}').concat(wd)},x=0;x<g;x++)m(x);return p}(c)})}return n.registerId=function(a){return Il(a)},n.prototype.rehydrate=function(){!this.server&&hs&&Tg(this)},n.prototype.reconstructWithOptions=function(a,o){return o===void 0&&(o=!0),new n(ae(ae({},this.options),a),this.gs,o&&this.names||void 0)},n.prototype.allocateGSInstance=function(a){return this.gs[a]=(this.gs[a]||0)+1},n.prototype.getTag=function(){return this.tag||(this.tag=(a=function(o){var l=o.useCSSOMInjection,c=o.target;return o.isServer?new A5(c):l?new b5(c):new S5(c)}(this.options),new h5(a)));var a},n.prototype.hasNameForId=function(a,o){return this.names.has(a)&&this.names.get(a).has(o)},n.prototype.registerName=function(a,o){if(Il(a),this.names.has(a))this.names.get(a).add(o);else{var l=new Set;l.add(o),this.names.set(a,l)}},n.prototype.insertRules=function(a,o,l){this.registerName(a,o),this.getTag().insertRules(Il(a),l)},n.prototype.clearNames=function(a){this.names.has(a)&&this.names.get(a).clear()},n.prototype.clearRules=function(a){this.getTag().clearGroup(Il(a)),this.clearNames(a)},n.prototype.clearTag=function(){this.tag=void 0},n}(),C5=/&/g,T5=/^\s*\/\/.*$/gm;function V1(n,a){return n.map(function(o){return o.type==="rule"&&(o.value="".concat(a," ").concat(o.value),o.value=o.value.replaceAll(",",",".concat(a," ")),o.props=o.props.map(function(l){return"".concat(a," ").concat(l)})),Array.isArray(o.children)&&o.type!=="@keyframes"&&(o.children=V1(o.children,a)),o})}function E5(n){var a,o,l,c=Ha,f=c.options,d=f===void 0?Ha:f,g=c.plugins,p=g===void 0?Rs:g,m=function(b,C,O){return O.startsWith(o)&&O.endsWith(o)&&O.replaceAll(o,"").length>0?".".concat(a):b},x=p.slice();x.push(function(b){b.type===Es&&b.value.includes("&")&&(b.props[0]=b.props[0].replace(C5,o).replace(l,m))}),d.prefix&&x.push(ZS),x.push(KS);var A=function(b,C,O,z){C===void 0&&(C=""),O===void 0&&(O=""),z===void 0&&(z="&"),a=z,o=C,l=new RegExp("\\".concat(o,"\\b"),"g");var P=b.replace(T5,""),R=YS(O||C?"".concat(O," ").concat(C," { ").concat(P," }"):P);d.namespace&&(R=V1(R,d.namespace));var H=[];return ds(R,$S(x.concat(QS(function(V){return H.push(V)})))),H};return A.hash=p.length?p.reduce(function(b,C){return C.name||_i(15),Ra(b,C.name)},D1).toString():"",A}var M5=new gs,Yf=E5(),U1=ie.createContext({shouldForwardProp:void 0,styleSheet:M5,stylis:Yf});U1.Consumer;ie.createContext(void 0);function Xf(){return E.useContext(U1)}var N1=function(){function n(a,o){var l=this;this.inject=function(c,f){f===void 0&&(f=Yf);var d=l.name+f.hash;c.hasNameForId(l.id,d)||c.insertRules(l.id,d,f(l.rules,d,"@keyframes"))},this.name=a,this.id="sc-keyframes-".concat(a),this.rules=o,Ed(this,function(){throw _i(12,String(l.name))})}return n.prototype.getName=function(a){return a===void 0&&(a=Yf),this.name+a.hash},n}(),j5=function(n){return n>="A"&&n<="Z"};function Mg(n){for(var a="",o=0;o<n.length;o++){var l=n[o];if(o===1&&l==="-"&&n[0]==="-")return n;j5(l)?a+="-"+l.toLowerCase():a+=l}return a.startsWith("ms-")?"-"+a:a}var _1=function(n){return n==null||n===!1||n===""},H1=function(n){var a,o,l=[];for(var c in n){var f=n[c];n.hasOwnProperty(c)&&!_1(f)&&(Array.isArray(f)&&f.isCss||Ni(f)?l.push("".concat(Mg(c),":"),f,";"):co(f)?l.push.apply(l,Va(Va(["".concat(c," {")],H1(f),!1),["}"],!1)):l.push("".concat(Mg(c),": ").concat((a=c,(o=f)==null||typeof o=="boolean"||o===""?"":typeof o!="number"||o===0||a in JS||a.startsWith("--")?String(o).trim():"".concat(o,"px")),";")))}return l};function li(n,a,o,l){if(_1(n))return[];if(Td(n))return[".".concat(n.styledComponentId)];if(Ni(n)){if(!Ni(f=n)||f.prototype&&f.prototype.isReactComponent||!a)return[n];var c=n(a);return li(c,a,o,l)}var f;return n instanceof N1?o?(n.inject(o,l),[n.getName(l)]):[n]:co(n)?H1(n):Array.isArray(n)?Array.prototype.concat.apply(Rs,n.map(function(d){return li(d,a,o,l)})):[n.toString()]}function G1(n){for(var a=0;a<n.length;a+=1){var o=n[a];if(Ni(o)&&!Td(o))return!1}return!0}var O5=R1(Ds),D5=function(){function n(a,o,l){this.rules=a,this.staticRulesId="",this.isStatic=(l===void 0||l.isStatic)&&G1(a),this.componentId=o,this.baseHash=Ra(O5,o),this.baseStyle=l,gs.registerId(o)}return n.prototype.generateAndInjectStyles=function(a,o,l){var c=this.baseStyle?this.baseStyle.generateAndInjectStyles(a,o,l):"";if(this.isStatic&&!l.hash)if(this.staticRulesId&&o.hasNameForId(this.componentId,this.staticRulesId))c=Bi(c,this.staticRulesId);else{var f=ms(li(this.rules,a,o,l)),d=qf(Ra(this.baseHash,f)>>>0);if(!o.hasNameForId(this.componentId,d)){var g=l(f,".".concat(d),void 0,this.componentId);o.insertRules(this.componentId,d,g)}c=Bi(c,d),this.staticRulesId=d}else{for(var p=Ra(this.baseHash,l.hash),m="",x=0;x<this.rules.length;x++){var A=this.rules[x];if(typeof A=="string")m+=A;else if(A){var b=ms(li(A,a,o,l));p=Ra(p,b+x),m+=b}}if(m){var C=qf(p>>>0);o.hasNameForId(this.componentId,C)||o.insertRules(this.componentId,C,l(m,".".concat(C),void 0,this.componentId)),c=Bi(c,C)}}return c},n}(),uo=ie.createContext(void 0);uo.Consumer;function R5(n){var a=ie.useContext(uo),o=E.useMemo(function(){return function(l,c){if(!l)throw _i(14);if(Ni(l)){var f=l(c);return f}if(Array.isArray(l)||typeof l!="object")throw _i(8);return c?ae(ae({},c),l):l}(n.theme,a)},[n.theme,a]);return n.children?ie.createElement(uo.Provider,{value:o},n.children):null}var lf={};function L5(n,a,o){var l=Td(n),c=n,f=!of(n),d=a.attrs,g=d===void 0?Rs:d,p=a.componentId,m=p===void 0?function(X,G){var K=typeof X!="string"?"sc":bg(X);lf[K]=(lf[K]||0)+1;var F="".concat(K,"-").concat(Cd(Ds+K+lf[K]));return G?"".concat(G,"-").concat(F):F}(a.displayName,a.parentComponentId):p,x=a.displayName,A=x===void 0?function(X){return of(X)?"styled.".concat(X):"Styled(".concat(a5(X),")")}(n):x,b=a.displayName&&a.componentId?"".concat(bg(a.displayName),"-").concat(a.componentId):a.componentId||m,C=l&&c.attrs?c.attrs.concat(g).filter(Boolean):g,O=a.shouldForwardProp;if(l&&c.shouldForwardProp){var z=c.shouldForwardProp;if(a.shouldForwardProp){var P=a.shouldForwardProp;O=function(X,G){return z(X,G)&&P(X,G)}}else O=z}var R=new D5(o,b,l?c.componentStyle:void 0);function H(X,G){return function(K,F,Z){var lt=K.attrs,vt=K.componentStyle,Bt=K.defaultProps,_t=K.foldedComponentIds,Xe=K.styledComponentId,Le=K.target,Kt=ie.useContext(uo),U=Xf(),Y=K.shouldForwardProp||U.shouldForwardProp,W=j1(F,Kt,Bt)||Ha,st=function(ht,it,Zt){for(var St,ce=ae(ae({},it),{className:void 0,theme:Zt}),di=0;di<ht.length;di+=1){var mn=Ni(St=ht[di])?St(ce):St;for(var Be in mn)ce[Be]=Be==="className"?Bi(ce[Be],mn[Be]):Be==="style"?ae(ae({},ce[Be]),mn[Be]):mn[Be]}return it.className&&(ce.className=Bi(ce.className,it.className)),ce}(lt,F,W),T=st.as||Le,q={};for(var $ in st)st[$]===void 0||$[0]==="$"||$==="as"||$==="theme"&&st.theme===W||($==="forwardedAs"?q.as=st.forwardedAs:Y&&!Y($,T)||(q[$]=st[$]));var Q=function(ht,it){var Zt=Xf(),St=ht.generateAndInjectStyles(it,Zt.styleSheet,Zt.stylis);return St}(vt,st),et=Bi(_t,Xe);return Q&&(et+=" "+Q),st.className&&(et+=" "+st.className),q[of(T)&&!O1.has(T)?"class":"className"]=et,Z&&(q.ref=Z),E.createElement(T,q)}(V,X,G)}H.displayName=A;var V=ie.forwardRef(H);return V.attrs=C,V.componentStyle=R,V.displayName=A,V.shouldForwardProp=O,V.foldedComponentIds=l?Bi(c.foldedComponentIds,c.styledComponentId):"",V.styledComponentId=b,V.target=l?c.target:n,Object.defineProperty(V,"defaultProps",{get:function(){return this._foldedDefaultProps},set:function(X){this._foldedDefaultProps=l?function(G){for(var K=[],F=1;F<arguments.length;F++)K[F-1]=arguments[F];for(var Z=0,lt=K;Z<lt.length;Z++)Ff(G,lt[Z],!0);return G}({},c.defaultProps,X):X}}),Ed(V,function(){return".".concat(V.styledComponentId)}),f&&k1(V,n,{attrs:!0,componentStyle:!0,displayName:!0,foldedComponentIds:!0,shouldForwardProp:!0,styledComponentId:!0,target:!0}),V}function jg(n,a){for(var o=[n[0]],l=0,c=a.length;l<c;l+=1)o.push(a[l],n[l+1]);return o}var Og=function(n){return Object.assign(n,{isCss:!0})};function Md(n){for(var a=[],o=1;o<arguments.length;o++)a[o-1]=arguments[o];if(Ni(n)||co(n))return Og(li(jg(Rs,Va([n],a,!0))));var l=n;return a.length===0&&l.length===1&&typeof l[0]=="string"?li(l):Og(li(jg(l,a)))}function Kf(n,a,o){if(o===void 0&&(o=Ha),!a)throw _i(1,a);var l=function(c){for(var f=[],d=1;d<arguments.length;d++)f[d-1]=arguments[d];return n(a,o,Md.apply(void 0,Va([c],f,!1)))};return l.attrs=function(c){return Kf(n,a,ae(ae({},o),{attrs:Array.prototype.concat(o.attrs,c).filter(Boolean)}))},l.withConfig=function(c){return Kf(n,a,ae(ae({},o),c))},l}var I1=function(n){return Kf(L5,n)},S=I1;O1.forEach(function(n){S[n]=I1(n)});var B5=function(){function n(a,o){this.rules=a,this.componentId=o,this.isStatic=G1(a),gs.registerId(this.componentId+1)}return n.prototype.createStyles=function(a,o,l,c){var f=c(ms(li(this.rules,o,l,c)),""),d=this.componentId+a;l.insertRules(d,d,f)},n.prototype.removeStyles=function(a,o){o.clearRules(this.componentId+a)},n.prototype.renderStyles=function(a,o,l,c){a>2&&gs.registerId(this.componentId+a),this.removeStyles(a,l),this.createStyles(a,o,l,c)},n}();function z5(n){for(var a=[],o=1;o<arguments.length;o++)a[o-1]=arguments[o];var l=Md.apply(void 0,Va([n],a,!1)),c="sc-global-".concat(Cd(JSON.stringify(l))),f=new B5(l,c),d=function(p){var m=Xf(),x=ie.useContext(uo),A=ie.useRef(m.styleSheet.allocateGSInstance(c)).current;return m.styleSheet.server&&g(A,p,m.styleSheet,x,m.stylis),ie.useLayoutEffect(function(){if(!m.styleSheet.server)return g(A,p,m.styleSheet,x,m.stylis),function(){return f.removeStyles(A,m.styleSheet)}},[A,p,m.styleSheet,x,m.stylis]),null};function g(p,m,x,A,b){if(f.isStatic)f.renderStyles(p,t5,x,b);else{var C=ae(ae({},m),{theme:j1(m,A,d.defaultProps)});f.renderStyles(p,C,x,b)}}return ie.memo(d)}function q1(n){for(var a=[],o=1;o<arguments.length;o++)a[o-1]=arguments[o];var l=ms(Md.apply(void 0,Va([n],a,!1))),c=Cd(l);return new N1(c,l)}const k5=z5`
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

  *, *::before, *::after {
    box-sizing: border-box;
  }

  html, body {
    margin: 0;
    padding: 0;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    font-size: 16px;
    line-height: 1.6;
    color: ${({theme:n})=>n.colors.text};
    background-color: ${({theme:n})=>n.colors.background};
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    scroll-behavior: smooth;

    /* remove the scrollbar */
    &::-webkit-scrollbar {
      width: 0;
      height: 0;
    }
    
  }

  a {
    color: ${({theme:n})=>n.colors.primary};
    text-decoration: none;
    transition: color 0.2s ease-in-out;

    &:hover {
      color: ${({theme:n})=>n.colors.secondary};
    }
  }

  h1, h2, h3, h4, h5, h6 {
    margin: 0;
    font-weight: 600;
    line-height: 1.2;
    color: ${({theme:n})=>n.colors.dark};
  }

  p {
    margin: 0;
    color: ${({theme:n})=>n.colors.text};
  }

  button {
    cursor: pointer;
    border: none;
    outline: none;
    background: none;
    transition: all 0.2s ease-in-out;
  }

  input, textarea, select, button {
    font-family: inherit;
    font-size: inherit;
    color: inherit;
  }

  img {
    max-width: 100%;
    display: block;
  }
`,P5=({filled:n})=>h.jsx("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:n?"#F5A623":"#E0E0E0",stroke:"none",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:h.jsx("polygon",{points:"12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"})}),V5=()=>h.jsx("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"white",stroke:"white",strokeWidth:"1",children:h.jsx("path",{d:"M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"})}),U5=S.section`
  background-color: #ffffff;
  padding: 4rem 2rem;
  font-family: 'Arial', sans-serif;
  display: flex;
  flex-direction: column;
  align-items: center;
`,N5=S.div`
  width: 100%;
  max-width: 1200px;
  margin-bottom: 2rem;
`,_5=S.h2`
  font-size: 1.25rem;
  color: #333;
  margin: 0;
  font-weight: normal;

  strong {
    font-size: 2rem;
    color: #000080; // A navy blue color
    display: block;
    font-weight: bold;
  }
`,H5=S.a`
  float: right;
  color: #000080;
  text-decoration: none;
  font-size: 0.9rem;

  &:hover {
    text-decoration: underline;
  }
`,G5=S.div`
  display: flex;
  border-bottom: 1px solid #e0e0e0;
  margin-bottom: 2.5rem;
  width: 100%;
  max-width: 1200px;
`,I5=S.button`
  padding: 0.75rem 1.5rem;
  font-size: 1rem;
  cursor: pointer;
  background-color: transparent;
  border: none;
  border-bottom: 3px solid transparent;
  color: #666;
  margin-right: 1rem;
  transition: all 0.3s ease;

  ${({active:n})=>n&&`
    border-bottom-color: #000080;
    color: #000080;
    font-weight: bold;
  `}

  &:hover {
    color: #000080;
  }
`,q5=S.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
  gap: 2rem;
  width: 100%;
  max-width: 1200px;
`,F5=S.div`
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  transition:
    transform 0.3s ease,
    box-shadow 0.3s ease;

  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
  }
`,Y5=S.div`
  position: relative;
  width: 100%;
  padding-top: 56.25%; /* 16:9 Aspect Ratio */
`,X5=S.img`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
`,K5=S.span`
  position: absolute;
  bottom: 10px;
  right: 10px;
  background-color: rgba(0, 0, 0, 0.6);
  color: white;
  padding: 0.3rem 0.8rem;
  border-radius: 4px;
  font-size: 0.8rem;
`,$5=S.button`
  position: absolute;
  top: 10px;
  right: 10px;
  background-color: rgba(0, 0, 0, 0.4);
  border: none;
  border-radius: 50%;
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;

  &:hover {
    background-color: rgba(0, 0, 0, 0.6);
  }
`,Q5=S.div`
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  flex-grow: 1;
`,Z5=S.h3`
  font-size: 1.1rem;
  font-weight: 600;
  color: #333;
  margin: 0 0 1rem 0;
  min-height: 44px; // Ensures alignment for 2-line titles
`,J5=S.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
`,W5=S.span`
  color: #555;
  font-size: 0.9rem;
`,t4=S.span`
  background-color: #f0f0f0;
  color: #666;
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  font-size: 0.8rem;
`,e4=S.div`
  margin-top: auto;
  padding-top: 1rem;
  border-top: 1px solid #f0f0f0;
`,n4=S.div`
  font-size: 0.8rem;
  color: #666;
  margin-bottom: 0.5rem;

  strong {
    font-size: 1.2rem;
    color: #333;
    font-weight: bold;
    display: block;
  }
`,i4=S.div`
  display: flex;
  align-items: center;
  justify-content: flex-end;
`,a4=S.div`
  display: flex;
  gap: 2px;
`,r4=S.span`
  margin-left: 0.5rem;
  font-size: 0.9rem;
  color: #555;
`,Dg=[{id:1,title:"Banking Pro - Certificate Programme",brand:"CCCOI",category:"Banking & Finance",salary:"₹ 2,70,000 PA",rating:4.9,imageUrl:"https://placehold.co/600x400/E0F2F1/333?text=Banking+Pro"},{id:2,title:"Certified Financial Planner Program",brand:"FinSchool",category:"Banking & Finance",salary:"₹ 3,50,000 PA",rating:4.8,imageUrl:"https://placehold.co/600x400/E0F2F1/333?text=CFP+Program"},{id:3,title:"Investment Banking Analyst Course",brand:"WallStreet Prep",category:"Banking & Finance",salary:"₹ 4,20,000 PA",rating:4.9,imageUrl:"https://placehold.co/600x400/E0F2F1/333?text=Investment+Banking"},{id:4,title:"Certificate in Logistics Management",brand:"CCCOI",category:"Operations & Supply Chain",salary:"₹ 1,44,000 PA",rating:4.8,imageUrl:"https://placehold.co/600x400/E3F2FD/333?text=Logistics"},{id:5,title:"PG in e-Commerce & Supply Chain",brand:"CCCOI",category:"Operations & Supply Chain",salary:"₹ 3,50,000 PA",rating:4.8,imageUrl:"https://placehold.co/600x400/E3F2FD/333?text=e-Commerce+SCM"},{id:6,title:"Certificate in Logistics Planning",brand:"Om Logistics",category:"Operations & Supply Chain",salary:"₹ 2,40,000 PA",rating:5,imageUrl:"https://placehold.co/600x400/E3F2FD/333?text=Logistics+Planning"},{id:7,title:"PG Advanced Certificate in Data Science",brand:"CCCOI",category:"Technology & Analytics",salary:"₹ 15,00,000 PA",rating:4.9,imageUrl:"https://placehold.co/600x400/D1C4E9/333?text=Data+Science"},{id:8,title:"Full Stack Web Development Course",brand:"DevAcademy",category:"Technology & Analytics",salary:"₹ 5,00,000 PA",rating:5,imageUrl:"https://placehold.co/600x400/D1C4E9/333?text=Full+Stack+Dev"},{id:9,title:"Cloud Computing & DevOps Certification",brand:"CloudPro",category:"Technology & Analytics",salary:"₹ 7,50,000 PA",rating:4.8,imageUrl:"https://placehold.co/600x400/D1C4E9/333?text=Cloud+Computing"},{id:10,title:"Certificate in Occupational English for Nurses",brand:"Jobizo",category:"Healthcare",salary:"₹ 23,80,219 PA",rating:4.8,imageUrl:"https://placehold.co/600x400/F8BBD0/333?text=Nursing+English"},{id:11,title:"Medical Coding and Billing Certificate",brand:"HealthCode",category:"Healthcare",salary:"₹ 3,00,000 PA",rating:4.7,imageUrl:"https://placehold.co/600x400/F8BBD0/333?text=Medical+Coding"},{id:12,title:"Hospital Administration Program",brand:"Medversity",category:"Healthcare",salary:"₹ 4,50,000 PA",rating:4.8,imageUrl:"https://placehold.co/600x400/F8BBD0/333?text=Hospital+Admin"},{id:13,title:"Certificate in Hospitality & Hotel Management",brand:"Marriott",category:"Hospitality",salary:"₹ 2,50,000 PA",rating:4.7,imageUrl:"https://placehold.co/600x400/FCE4EC/333?text=Hotel+Management"},{id:14,title:"Aviation & Cabin Crew Training",brand:"FlyHigh Academy",category:"Hospitality",salary:"₹ 4,00,000 PA",rating:4.9,imageUrl:"https://placehold.co/600x400/FCE4EC/333?text=Cabin+Crew"},{id:15,title:"Professional Chef Certification",brand:"Le Cordon Bleu",category:"Hospitality",salary:"₹ 3,80,000 PA",rating:4.9,imageUrl:"https://placehold.co/600x400/FCE4EC/333?text=Pro+Chef"},{id:16,title:"BIMTECH PG Diploma in Management (Online)",brand:"BIMTECH",category:"General Management",salary:"₹ 5,00,000 PA",rating:4.7,imageUrl:"https://placehold.co/600x400/C5CAE9/333?text=PGDM+Online"},{id:17,title:"Certificate in Business Administration",brand:"BizSchool",category:"General Management",salary:"₹ 3,20,000 PA",rating:4.6,imageUrl:"https://placehold.co/600x400/C5CAE9/333?text=Business+Admin"},{id:18,title:"Startup & Entrepreneurship Program",brand:"InnovateHub",category:"General Management",salary:"N/A",rating:4.8,imageUrl:"https://placehold.co/600x400/C5CAE9/333?text=Startup+Program"}],o4=["Popular","Banking & Finance","Operations & Supply Chain","Technology & Analytics","Healthcare","Hospitality","General Management"],l4=()=>{const[n,a]=E.useState("Popular"),[o,l]=E.useState([]);E.useEffect(()=>{const d=[...Dg].sort(()=>.5-Math.random());l(d.slice(0,3))},[]);const c=E.useMemo(()=>n==="Popular"?o:Dg.filter(d=>d.category===n),[n,o]),f=d=>{let p=[];for(let m=1;m<=5;m++)p.push(h.jsx(P5,{filled:m<=d},m));return p};return h.jsxs(U5,{children:[h.jsxs(N5,{children:[h.jsx(H5,{href:"#",children:"Explore All Early Career Courses →"}),h.jsxs(_5,{children:["Become job-ready with",h.jsx("strong",{children:"Early Career Courses"})]})]}),h.jsx(G5,{children:o4.map(d=>h.jsx(I5,{active:n===d,onClick:()=>a(d),children:d},d))}),h.jsx(q5,{children:c.map(d=>h.jsxs(F5,{children:[h.jsxs(Y5,{children:[h.jsx(X5,{src:d.imageUrl,alt:d.title}),h.jsx($5,{children:h.jsx(V5,{})}),h.jsx(K5,{children:"Admission Open"})]}),h.jsxs(Q5,{children:[h.jsx(Z5,{children:d.title}),h.jsxs(J5,{children:[h.jsx(W5,{children:d.brand}),h.jsx(t4,{children:d.category})]}),h.jsxs(e4,{children:[h.jsxs(n4,{children:["Salary Upto:",h.jsx("strong",{children:d.salary})]}),h.jsxs(i4,{children:[h.jsx(a4,{children:f(d.rating)}),h.jsxs(r4,{children:["(",d.rating,")"]})]})]})]})]},d.id))})]})},s4=({filled:n})=>h.jsx("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:n?"#F5A623":"#E0E0E0",stroke:"none",children:h.jsx("polygon",{points:"12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"})}),c4=()=>h.jsx("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"white",stroke:"white",strokeWidth:"1",children:h.jsx("path",{d:"M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"})}),u4=()=>h.jsxs("svg",{width:"20",height:"20",viewBox:"0 0 24 24",fill:"none",stroke:"#666",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[h.jsx("path",{d:"M12 2L2 7l10 5 10-5-10-5z"}),h.jsx("path",{d:"M2 17l10 5 10-5"}),h.jsx("path",{d:"M2 12l10 5 10-5"})]}),f4=()=>h.jsxs("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"#666",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[h.jsx("rect",{x:"3",y:"4",width:"18",height:"18",rx:"2",ry:"2"}),h.jsx("line",{x1:"16",y1:"2",x2:"16",y2:"6"}),h.jsx("line",{x1:"8",y1:"2",x2:"8",y2:"6"}),h.jsx("line",{x1:"3",y1:"10",x2:"21",y2:"10"})]}),d4=S.section`
  background-color: #ffffff;
  padding: 4rem 2rem;
  font-family: 'Arial', sans-serif;
  display: flex;
  flex-direction: column;
  align-items: center;
`,h4=S.div`
  width: 100%;
  max-width: 1200px;
  margin-bottom: 2rem;
  position: relative;
`,m4=S.h2`
  font-size: 1.25rem;
  color: #e55c20; // An orange color
  margin: 0;
  font-weight: normal;

  strong {
    font-size: 2rem;
    color: #000080; // A navy blue color
    display: block;
    font-weight: bold;
  }
`,p4=S.a`
  position: absolute;
  top: 10px;
  right: 0;
  color: #000080;
  text-decoration: none;
  font-size: 0.9rem;

  &:hover {
    text-decoration: underline;
  }
`,g4=S.div`
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
  margin-bottom: 2.5rem;
  width: 100%;
  max-width: 1200px;
`,y4=S.button`
  padding: 0.6rem 1.2rem;
  font-size: 0.875rem; /* Smaller font size */
  cursor: pointer;
  border: 1px solid #e0e0e0;
  border-radius: 6px; /* Rectangular with slightly rounded corners */
  transition: all 0.3s ease;
  font-weight: 500;

  ${({active:n})=>n?`
        background-color: #000080; /* Active tab background */
        color: #ffffff; /* Active tab text color */
        border-color: #000080;
      `:`
        background-color: #f7f7f7; /* Inactive tab background */
        color: #555; /* Inactive tab text color */
        &:hover {
          background-color: #e9e9e9;
          border-color: #ccc;
        }
      `}
`,x4=S.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
  gap: 2rem;
  width: 100%;
  max-width: 1200px;
`,v4=S.div`
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  transition:
    transform 0.3s ease,
    box-shadow 0.3s ease;

  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
  }
`,b4=S.div`
  position: relative;
  width: 100%;
  padding-top: 56.25%; /* 16:9 Aspect Ratio */
`,S4=S.img`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
`,A4=S.span`
  position: absolute;
  bottom: 10px;
  right: 10px;
  background-color: rgba(0, 0, 0, 0.6);
  color: white;
  padding: 0.3rem 0.8rem;
  border-radius: 4px;
  font-size: 0.8rem;
`,w4=S.button`
  position: absolute;
  top: 10px;
  right: 10px;
  background-color: rgba(0, 0, 0, 0.4);
  border: none;
  border-radius: 50%;
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;

  &:hover {
    background-color: rgba(0, 0, 0, 0.6);
  }
`,C4=S.div`
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  flex-grow: 1;
`,T4=S.h3`
  font-size: 1.1rem;
  font-weight: 600;
  color: #333;
  margin: 0 0 1rem 0;
  min-height: 44px;
`,E4=S.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
  color: #555;
  font-size: 0.9rem;
`,M4=S.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,j4=S.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,O4=S.div`
  margin-top: auto;
  padding-top: 1rem;
  border-top: 1px solid #f0f0f0;
  display: flex;
  justify-content: space-between;
  align-items: center;
`,D4=S.div`
  font-size: 0.8rem;
  color: #666;

  strong {
    font-size: 1.2rem;
    color: #333;
    font-weight: bold;
    display: block;
  }
`,R4=S.div`
  display: flex;
  align-items: center;
`,L4=S.div`
  display: flex;
  gap: 2px;
`,B4=S.span`
  margin-left: 0.5rem;
  font-size: 0.9rem;
  color: #555;
`,z4={Popular:[{id:1,title:"IIM Kozhikode Professional Certificate Programme in Fintech - Batch 07",institution:"IIM Kozhikode",startsIn:"7 days",fee:"₹ 2,10,000",rating:4.9,imageUrl:"https://placehold.co/600x400/bdc3c7/333?text=Fintech+Course"},{id:2,title:"IIM Calcutta Executive Programme in Business Management - Batch 31",institution:"IIM Calcutta",startsIn:"14 days",fee:"₹ 7,02,000",rating:4.9,imageUrl:"https://placehold.co/600x400/95a5a6/333?text=Business+Mngmt"},{id:3,title:"IIM Nagpur Certificate Programme in Project Management - Batch 07",institution:"IIM Nagpur",startsIn:"41 days",fee:"₹ 1,35,000",rating:4.9,imageUrl:"https://placehold.co/600x400/7f8c8d/333?text=Project+Mngmt"}],"Technology & Analytics":[{id:4,title:"IIT Delhi Executive Programme in Data Science & AI - Batch 12",institution:"IIT Delhi",startsIn:"10 days",fee:"₹ 3,50,000",rating:4.8,imageUrl:"https://placehold.co/600x400/3498db/333?text=Data+Science"},{id:5,title:"IIM Bangalore Advanced Certificate in Machine Learning - Batch 08",institution:"IIM Bangalore",startsIn:"21 days",fee:"₹ 2,75,000",rating:4.7,imageUrl:"https://placehold.co/600x400/9b59b6/333?text=ML+Analytics"},{id:6,title:"ISB Professional Certificate in Business Analytics - Batch 15",institution:"ISB Hyderabad",startsIn:"35 days",fee:"₹ 1,95,000",rating:4.8,imageUrl:"https://placehold.co/600x400/2ecc71/333?text=Business+Analytics"}],"Leadership & Strategy":[{id:7,title:"IIM Ahmedabad Advanced Management Programme - Batch 45",institution:"IIM Ahmedabad",startsIn:"5 days",fee:"₹ 8,50,000",rating:4.9,imageUrl:"https://placehold.co/600x400/e74c3c/333?text=Leadership+AMP"},{id:8,title:"XLRI Executive Programme in Strategic Leadership - Batch 22",institution:"XLRI Jamshedpur",startsIn:"18 days",fee:"₹ 6,25,000",rating:4.8,imageUrl:"https://placehold.co/600x400/f39c12/333?text=Strategic+Leadership"},{id:9,title:"FMS Delhi Certificate in Corporate Strategy - Batch 11",institution:"FMS Delhi",startsIn:"30 days",fee:"₹ 3,75,000",rating:4.7,imageUrl:"https://placehold.co/600x400/1abc9c/333?text=Corporate+Strategy"}],"General Management":[{id:10,title:"IIM Lucknow General Management Programme - Batch 28",institution:"IIM Lucknow",startsIn:"12 days",fee:"₹ 4,50,000",rating:4.8,imageUrl:"https://placehold.co/600x400/34495e/333?text=General+Management"},{id:11,title:"MDI Gurgaon Executive Development Programme - Batch 19",institution:"MDI Gurgaon",startsIn:"25 days",fee:"₹ 3,25,000",rating:4.7,imageUrl:"https://placehold.co/600x400/8e44ad/333?text=Executive+Dev"},{id:12,title:"SPJIMR Advanced General Management - Batch 16",institution:"SPJIMR Mumbai",startsIn:"38 days",fee:"₹ 5,75,000",rating:4.8,imageUrl:"https://placehold.co/600x400/d35400/333?text=Advanced+GM"}],"Operations & Supply Chain":[{id:13,title:"IIM Indore Certificate in Supply Chain Management - Batch 09",institution:"IIM Indore",startsIn:"8 days",fee:"₹ 2,85,000",rating:4.7,imageUrl:"https://placehold.co/600x400/27ae60/333?text=Supply+Chain"},{id:14,title:"NITIE Operations Excellence Programme - Batch 13",institution:"NITIE Mumbai",startsIn:"22 days",fee:"₹ 3,15,000",rating:4.6,imageUrl:"https://placehold.co/600x400/2980b9/333?text=Operations+Excel"},{id:15,title:"IIT Bombay Advanced Operations Management - Batch 07",institution:"IIT Bombay",startsIn:"45 days",fee:"₹ 2,45,000",rating:4.8,imageUrl:"https://placehold.co/600x400/16a085/333?text=Advanced+Ops"}],"Marketing & Sales":[{id:16,title:"IIM Calcutta Advanced Marketing Programme - Batch 24",institution:"IIM Calcutta",startsIn:"6 days",fee:"₹ 4,25,000",rating:4.9,imageUrl:"https://placehold.co/600x400/e67e22/333?text=Marketing+Prog"},{id:17,title:"MICA Certificate in Digital Marketing - Batch 18",institution:"MICA Ahmedabad",startsIn:"19 days",fee:"₹ 1,85,000",rating:4.6,imageUrl:"https://placehold.co/600x400/9c88ff/333?text=Digital+Marketing"},{id:18,title:"ISB Sales Leadership Programme - Batch 12",institution:"ISB Hyderabad",startsIn:"33 days",fee:"₹ 3,95,000",rating:4.7,imageUrl:"https://placehold.co/600x400/ff6b6b/333?text=Sales+Leadership"}],MBA:[{id:19,title:"IIM Kozhikode Executive MBA Programme - Batch 17",institution:"IIM Kozhikode",startsIn:"15 days",fee:"₹ 12,50,000",rating:4.9,imageUrl:"https://placehold.co/600x400/4ecdc4/333?text=Executive+MBA"},{id:20,title:"FMS Delhi Weekend MBA Programme - Batch 09",institution:"FMS Delhi",startsIn:"28 days",fee:"₹ 8,75,000",rating:4.8,imageUrl:"https://placehold.co/600x400/45b7d1/333?text=Weekend+MBA"},{id:21,title:"XLRI Global MBA Programme - Batch 06",institution:"XLRI Jamshedpur",startsIn:"42 days",fee:"₹ 15,25,000",rating:4.9,imageUrl:"https://placehold.co/600x400/f7b731/333?text=Global+MBA"}],"Banking & Finance":[{id:22,title:"IIM Bangalore Advanced Programme in Banking - Batch 14",institution:"IIM Bangalore",startsIn:"9 days",fee:"₹ 3,65,000",rating:4.8,imageUrl:"https://placehold.co/600x400/5f27cd/333?text=Banking+Prog"},{id:23,title:"JBIMS Certificate in Financial Management - Batch 21",institution:"JBIMS Mumbai",startsIn:"23 days",fee:"₹ 2,25,000",rating:4.7,imageUrl:"https://placehold.co/600x400/00d2d3/333?text=Financial+Mgmt"},{id:24,title:"ISB Risk Management Programme - Batch 08",institution:"ISB Hyderabad",startsIn:"36 days",fee:"₹ 4,15,000",rating:4.8,imageUrl:"https://placehold.co/600x400/ff9ff3/333?text=Risk+Management"}],"Innovation & Transformation":[{id:25,title:"IIT Delhi Innovation Leadership Programme - Batch 05",institution:"IIT Delhi",startsIn:"11 days",fee:"₹ 3,85,000",rating:4.7,imageUrl:"https://placehold.co/600x400/54a0ff/333?text=Innovation+Lead"},{id:26,title:"IIM Ahmedabad Digital Transformation - Batch 10",institution:"IIM Ahmedabad",startsIn:"26 days",fee:"₹ 4,95,000",rating:4.9,imageUrl:"https://placehold.co/600x400/2ed573/333?text=Digital+Transform"},{id:27,title:"BITS Pilani Innovation Management - Batch 07",institution:"BITS Pilani",startsIn:"39 days",fee:"₹ 2,65,000",rating:4.6,imageUrl:"https://placehold.co/600x400/ffa502/333?text=Innovation+Mgmt"}],"Human Resources":[{id:28,title:"XLRI Advanced HR Management Programme - Batch 26",institution:"XLRI Jamshedpur",startsIn:"7 days",fee:"₹ 3,45,000",rating:4.8,imageUrl:"https://placehold.co/600x400/ff6348/333?text=HR+Management"},{id:29,title:"TISS Strategic HR Leadership - Batch 15",institution:"TISS Mumbai",startsIn:"20 days",fee:"₹ 2,95,000",rating:4.7,imageUrl:"https://placehold.co/600x400/ff4757/333?text=HR+Leadership"},{id:30,title:"MDI Gurgaon People Analytics Programme - Batch 11",institution:"MDI Gurgaon",startsIn:"34 days",fee:"₹ 1,75,000",rating:4.6,imageUrl:"https://placehold.co/600x400/5352ed/333?text=People+Analytics"}],Healthcare:[{id:31,title:"IIHMR Healthcare Management Programme - Batch 12",institution:"IIHMR Delhi",startsIn:"13 days",fee:"₹ 2,85,000",rating:4.7,imageUrl:"https://placehold.co/600x400/3742fa/333?text=Healthcare+Mgmt"},{id:32,title:"IIM Lucknow Hospital Administration - Batch 08",institution:"IIM Lucknow",startsIn:"27 days",fee:"₹ 3,25,000",rating:4.6,imageUrl:"https://placehold.co/600x400/2f3542/333?text=Hospital+Admin"},{id:33,title:"AIIMS Healthcare Leadership Programme - Batch 06",institution:"AIIMS Delhi",startsIn:"40 days",fee:"₹ 2,15,000",rating:4.8,imageUrl:"https://placehold.co/600x400/ff3838/333?text=Healthcare+Lead"}],"Product Management":[{id:34,title:"ISB Product Strategy & Innovation - Batch 09",institution:"ISB Hyderabad",startsIn:"16 days",fee:"₹ 2,55,000",rating:4.7,imageUrl:"https://placehold.co/600x400/7bed9f/333?text=Product+Strategy"},{id:35,title:"IIT Bombay Digital Product Management - Batch 11",institution:"IIT Bombay",startsIn:"29 days",fee:"₹ 1,95,000",rating:4.6,imageUrl:"https://placehold.co/600x400/70a1ff/333?text=Digital+Product"},{id:36,title:"IIM Bangalore Product Leadership - Batch 13",institution:"IIM Bangalore",startsIn:"37 days",fee:"₹ 3,05,000",rating:4.8,imageUrl:"https://placehold.co/600x400/57606f/333?text=Product+Lead"}],"Web 3.0":[{id:37,title:"IIT Delhi Blockchain & Web 3.0 Programme - Batch 04",institution:"IIT Delhi",startsIn:"17 days",fee:"₹ 1,85,000",rating:4.5,imageUrl:"https://placehold.co/600x400/ffd32a/333?text=Blockchain+Web3"},{id:38,title:"IIM Kozhikode Cryptocurrency & DeFi - Batch 03",institution:"IIM Kozhikode",startsIn:"31 days",fee:"₹ 1,45,000",rating:4.4,imageUrl:"https://placehold.co/600x400/ff9500/333?text=Crypto+DeFi"},{id:39,title:"BITS Pilani NFT & Metaverse Programme - Batch 02",institution:"BITS Pilani",startsIn:"44 days",fee:"₹ 1,25,000",rating:4.3,imageUrl:"https://placehold.co/600x400/c44569/333?text=NFT+Metaverse"}],Law:[{id:40,title:"NLSIU Corporate Law Programme - Batch 18",institution:"NLSIU Bangalore",startsIn:"24 days",fee:"₹ 2,75,000",rating:4.8,imageUrl:"https://placehold.co/600x400/786fa6/333?text=Corporate+Law"},{id:41,title:"NALSAR IP & Technology Law - Batch 09",institution:"NALSAR Hyderabad",startsIn:"32 days",fee:"₹ 1,95,000",rating:4.7,imageUrl:"https://placehold.co/600x400/f8b500/333?text=IP+Tech+Law"},{id:42,title:"NUJS Banking & Finance Law - Batch 14",institution:"NUJS Kolkata",startsIn:"46 days",fee:"₹ 2,35,000",rating:4.6,imageUrl:"https://placehold.co/600x400/4b7bec/333?text=Banking+Law"}]},k4=["Popular","Technology & Analytics","Leadership & Strategy","General Management","Operations & Supply Chain","Marketing & Sales","MBA","Banking & Finance","Innovation & Transformation","Human Resources","Healthcare","Product Management","Web 3.0","Law"],P4=()=>{const[n,a]=E.useState("Popular"),o=z4[n]||[],l=c=>{let d=[];for(let g=1;g<=5;g++)d.push(h.jsx(s4,{filled:g<=c},g));return d};return h.jsxs(d4,{children:[h.jsxs(h4,{children:[h.jsx(p4,{href:"#",children:"Explore All Executive Education Courses →"}),h.jsxs(m4,{children:["Scale Up Your Career With",h.jsx("strong",{children:"Executive Education Courses"})]})]}),h.jsx(g4,{children:k4.map(c=>h.jsx(y4,{active:n===c,onClick:()=>a(c),children:c},c))}),h.jsx(x4,{children:o.map(c=>h.jsxs(v4,{children:[h.jsxs(b4,{children:[h.jsx(S4,{src:c.imageUrl,alt:c.title}),h.jsx(w4,{children:h.jsx(c4,{})}),h.jsx(A4,{children:"Admission Open"})]}),h.jsxs(C4,{children:[h.jsx(T4,{children:c.title}),h.jsxs(E4,{children:[h.jsxs(M4,{children:[h.jsx(u4,{}),c.institution]}),h.jsxs(j4,{children:[h.jsx(f4,{}),"Starts in ",c.startsIn]})]}),h.jsxs(O4,{children:[h.jsxs(D4,{children:["Course Fee",h.jsx("strong",{children:c.fee})]}),h.jsxs(R4,{children:[h.jsx(L4,{children:l(c.rating)}),h.jsxs(B4,{children:["(",c.rating,")"]})]})]})]})]},c.id))})]})},V4=S.section`
  background-color: #f9f9f9; // A slightly different background to distinguish sections
  padding: 4rem 2rem;
  font-family: 'Arial', sans-serif;
  display: flex;
  flex-direction: column;
  align-items: center;
`,U4=S.div`
  width: 100%;
  max-width: 1200px;
  margin-bottom: 2rem;
  position: relative;
`,N4=S.h2`
  font-size: 1.25rem;
  color: #333;
  margin: 0;
  font-weight: normal;

  strong {
    font-size: 2rem;
    color: #000080; // A navy blue color
    display: block;
    font-weight: bold;
  }
`,_4=S.a`
  position: absolute;
  top: 10px;
  right: 0;
  color: #000080;
  text-decoration: none;
  font-size: 0.9rem;

  &:hover {
    text-decoration: underline;
  }
`,H4=S.div`
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
  margin-bottom: 2.5rem;
  width: 100%;
  max-width: 1200px;
`,G4=S.button`
  padding: 0.6rem 1.2rem;
  font-size: 0.875rem;
  cursor: pointer;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  transition: all 0.3s ease;
  font-weight: 500;

  ${({active:n})=>n?`
        background-color: #000080;
        color: #ffffff;
        border-color: #000080;
      `:`
        background-color: #ffffff;
        color: #555;
        &:hover {
          background-color: #f0f0f0;
          border-color: #ccc;
        }
      `}
`,I4=S.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
  gap: 2rem;
  width: 100%;
  max-width: 1200px;
`,q4=S.div`
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  transition:
    transform 0.3s ease,
    box-shadow 0.3s ease;

  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
  }
`,F4=S.div`
  position: relative;
  width: 100%;
  padding-top: 56.25%; /* 16:9 Aspect Ratio */
`,Y4=S.img`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
`,X4=S.span`
  position: absolute;
  bottom: 10px;
  right: 10px;
  background-color: rgba(0, 0, 0, 0.6);
  color: white;
  padding: 0.3rem 0.8rem;
  border-radius: 4px;
  font-size: 0.8rem;
`,K4=S.div`
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  flex-grow: 1;
`,$4=S.h3`
  font-size: 1.1rem;
  font-weight: 600;
  color: #333;
  margin: 0 0 0.5rem 0;
  min-height: 44px;
`,Q4=S.span`
  color: #555;
  font-size: 0.9rem;
  margin-bottom: 1.5rem;
`,Z4=S.div`
  margin-top: auto;
  padding-top: 1rem;
  border-top: 1px solid #f0f0f0;
`,J4=S.div`
  font-size: 0.8rem;
  color: #666;

  strong {
    font-size: 1.2rem;
    color: #333;
    font-weight: bold;
    display: block;
  }
`,W4=[{id:1,title:"Certificate Program in Full Stack Web Development",brand:"CCCOI",fee:"₹ 9,499",imageUrl:"https://placehold.co/600x400/6c5ce7/ffffff?text=Full+Stack"},{id:2,title:"Certificate Program in Data Analytics and Data Visualisation",brand:"CCCOI",fee:"₹ 1,999",imageUrl:"https://placehold.co/600x400/00cec9/ffffff?text=Data+Analytics"},{id:3,title:"Certificate Program in Data Science and Artificial Intelligence",brand:"CCCOI",fee:"₹ 11,999",imageUrl:"https://placehold.co/600x400/0984e3/ffffff?text=Data+Science"}],tA=["Popular","Technology & Analytics","Banking & Finance","Soft skills","Hospitality","Operations & Supply Chain","Web 3.0"],eA=()=>{const[n,a]=E.useState("Popular");return h.jsxs(V4,{children:[h.jsxs(U4,{children:[h.jsx(_4,{href:"#",children:"Explore All Self-Paced Courses →"}),h.jsxs(N4,{children:["Get future ready at your convenience with",h.jsx("strong",{children:"Self-Paced Courses"})]})]}),h.jsx(H4,{children:tA.map(o=>h.jsx(G4,{active:n===o,onClick:()=>a(o),children:o},o))}),h.jsx(I4,{children:W4.map(o=>h.jsxs(q4,{children:[h.jsxs(F4,{children:[h.jsx(Y4,{src:o.imageUrl,alt:o.title}),h.jsx(X4,{children:"Admission Open"})]}),h.jsxs(K4,{children:[h.jsx($4,{children:o.title}),h.jsx(Q4,{children:o.brand}),h.jsx(Z4,{children:h.jsxs(J4,{children:["Course Fee",h.jsx("strong",{children:o.fee})]})})]})]},o.id))})]})},nA=S.section`
  background-color: #f0f2f5; // Light grey background
  padding: 4rem 2rem;
  font-family: 'Arial', sans-serif;
  display: flex;
  flex-direction: column;
  align-items: center;
`,iA=S.div`
  width: 100%;
  max-width: 1200px;
  margin-bottom: 2.5rem;
  text-align: left;
`,aA=S.h2`
  font-size: 1.25rem;
  color: #333;
  margin: 0;
  font-weight: normal;

  strong {
    font-size: 2rem;
    color: #000080; // Navy blue color
    display: block;
    font-weight: bold;
  }
`,rA=S.p`
  font-size: 1rem;
  color: #555;
  margin-top: 0.5rem;
`,oA=S.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(450px, 1fr));
  gap: 1.5rem;
  width: 100%;
  max-width: 1200px;
`,lA=S.div`
  background-color: #ffffff;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.07);
  display: flex;
  overflow: hidden;
  transition:
    transform 0.3s ease,
    box-shadow 0.3s ease;

  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
  }
`,sA=S.div`
  flex-shrink: 0;
  width: 200px;
  background-image: url(${n=>n.src});
  background-size: cover;
  background-position: center;
`,cA=S.div`
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
`,uA=S.h3`
  font-size: 1.1rem;
  font-weight: 600;
  color: #333;
  margin: 0 0 0.75rem 0;
`,fA=S.p`
  font-size: 0.9rem;
  color: #666;
  line-height: 1.5;
  margin: 0 0 1.5rem 0;
  flex-grow: 1;
`,dA=S.a`
  display: inline-block;
  background-color: #d9534f; // Red color from screenshot
  color: #ffffff;
  padding: 0.6rem 1.2rem;
  border-radius: 4px;
  text-decoration: none;
  font-weight: 500;
  font-size: 0.9rem;
  transition: background-color 0.3s ease;
  align-self: flex-start;

  &:hover {
    background-color: #c9302c;
  }
`,hA=[{title:"Organisational Development Consulting",description:"A bouquet of services to help organisations reinvent their people, processes, and organisational goals to rema...",imageUrl:"https://placehold.co/400x400/d7d7d7/333?text=Consulting"},{title:"Executive Education @ Work",description:"Executive Education @ Work by TimesPro offers customised corporate training solutions to organisations to enge...",imageUrl:"https://placehold.co/400x400/c7c7c7/333?text=Education"},{title:"Learning Experience Platform (LXP)",description:"Our LXP’s help you engage your workforce with learning interventions based on compelling content designed to be...",imageUrl:"https://placehold.co/400x400/b7b7b7/333?text=LXP"},{title:"Content Solutions",description:"TimesPro’s content creation services leverage its expertise and experience in developing over 18,000 hours of...",imageUrl:"https://placehold.co/400x400/a7a7a7/333?text=Content"},{title:"Technology Programmes",description:"TimesPro’s technology training programmes service specific needs of corporates to train their teams on emergin...",imageUrl:"https://placehold.co/400x400/979797/333?text=Tech"},{title:"L&D Solutions",description:"Our range of process-driven and outcome-based Learning and Development interventions are carefully crafted to...",imageUrl:"https://placehold.co/400x400/878787/333?text=L%26D"}],mA=()=>h.jsxs(nA,{children:[h.jsxs(iA,{children:[h.jsxs(aA,{children:["Achieve organisational growth with",h.jsx("strong",{children:"Enterprise Solutions"})]}),h.jsx(rA,{children:"Customised learning solutions to empower talent and drive business objectives"})]}),h.jsx(oA,{children:hA.map((n,a)=>h.jsxs(lA,{children:[h.jsx(sA,{src:n.imageUrl}),h.jsxs(cA,{children:[h.jsx(uA,{children:n.title}),h.jsx(fA,{children:n.description}),h.jsx(dA,{href:"#",children:"Know More →"})]})]},a))})]}),pA=()=>h.jsxs("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"white",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[h.jsx("circle",{cx:"12",cy:"12",r:"10"}),h.jsx("line",{x1:"12",y1:"16",x2:"12",y2:"12"}),h.jsx("line",{x1:"12",y1:"8",x2:"12.01",y2:"8"})]}),gA=S.section`
  background-color: #f8f9fa;
  padding: 4rem 2rem;
  font-family: 'Arial', sans-serif;
  display: flex;
  flex-direction: column;
  align-items: center;
`,yA=S.div`
  width: 100%;
  max-width: 1200px;
  margin-bottom: 2.5rem;
  text-align: left;
`,xA=S.h2`
  font-size: 1.25rem;
  color: #d9534f; // Red color
  margin: 0;
  font-weight: normal;

  strong {
    font-size: 2rem;
    color: #000080; // Navy blue color
    display: block;
    font-weight: bold;
  }
`,vA=S.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  gap: 1.5rem;
  width: 100%;
  max-width: 1200px;
`,F1=S.div`
  background-color: #ffffff;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
  transition: all 0.3s ease;
  cursor: pointer;

  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
  }
`,bA=S(F1)`
  display: flex;
  align-items: center;
  gap: 1rem;
`,SA=S.div`
  flex-shrink: 0;
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background-color: #000080; // Navy blue
  display: flex;
  align-items: center;
  justify-content: center;
`,AA=S.div`
  display: flex;
  flex-direction: column;
`,wA=S.h3`
  font-size: 1rem;
  font-weight: 600;
  color: #333;
  margin: 0;
`,CA=S.p`
  font-size: 0.9rem;
  color: #666;
  margin: 0.25rem 0 0 0;
`,TA=S(F1)`
  background-color: #f0f2f5;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #000080;
  font-weight: 600;
  font-size: 1rem;

  &:hover {
    background-color: #e9ecf0;
  }
`,EA=[{name:"General Management",courses:27},{name:"MBA",courses:14},{name:"Leadership & Strategy",courses:30},{name:"Technology & Analytics",courses:93},{name:"Operations & Supply Chain",courses:27},{name:"Banking & Finance",courses:36},{name:"Marketing & Sales",courses:15},{name:"Healthcare",courses:5},{name:"Product Management",courses:2}],MA=()=>h.jsxs(gA,{children:[h.jsx(yA,{children:h.jsxs(xA,{children:["Select Courses from",h.jsx("strong",{children:"In-demand Domains"})]})}),h.jsxs(vA,{children:[EA.map((n,a)=>h.jsxs(bA,{children:[h.jsx(SA,{children:h.jsx(pA,{})}),h.jsxs(AA,{children:[h.jsx(wA,{children:n.name}),h.jsxs(CA,{children:[n.courses," Courses"]})]})]},a)),h.jsx(TA,{children:"View Courses From All Categories →"})]})]}),jA=S.section`
  background-color: #f8f9fa;
  padding: 4rem 2rem;
  font-family: 'Arial', sans-serif;
  display: flex;
  flex-direction: column;
  align-items: center;
`,OA=S.div`
  width: 100%;
  max-width: 1200px;
  margin-bottom: 2.5rem;
  text-align: left;
`,DA=S.h2`
  font-size: 1.25rem;
  color: #d9534f; // Red color
  margin: 0;
  font-weight: normal;

  strong {
    font-size: 2rem;
    color: #000080; // Navy blue color
    display: block;
    font-weight: bold;
  }
`,RA=S.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  gap: 1.5rem;
  width: 100%;
  max-width: 1200px;
`,Y1=S.div`
  background-color: #ffffff;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 4px_15px rgba(0, 0, 0, 0.05);
  transition: all 0.3s ease;
  cursor: pointer;

  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
  }
`,LA=S(Y1)`
  display: flex;
  align-items: center;
  gap: 1rem;
`,BA=S.img`
  flex-shrink: 0;
  width: 50px;
  height: 50px;
  object-fit: contain;
`,zA=S.div`
  display: flex;
  flex-direction: column;
`,kA=S.h3`
  font-size: 1rem;
  font-weight: 600;
  color: #333;
  margin: 0;
`,PA=S.p`
  font-size: 0.9rem;
  color: #666;
  margin: 0.25rem 0 0 0;
`,VA=S(Y1)`
  background-color: #f0f2f5;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #000080;
  font-weight: 600;
  font-size: 1rem;

  &:hover {
    background-color: #e9ecf0;
  }
`,UA=[{name:"IISc Bangalore",courses:3,logo:"https://placehold.co/100x100/ccc/333?text=IISc"},{name:"Manipal University Jaipur",courses:1,logo:"https://placehold.co/100x100/ccc/333?text=MUJ"},{name:"IIM Kozhikode",courses:24,logo:"https://placehold.co/100x100/ccc/333?text=IIM-K"},{name:"IIM Calcutta",courses:14,logo:"https://placehold.co/100x100/ccc/333?text=IIM-C"},{name:"IIT Delhi",courses:21,logo:"https://placehold.co/100x100/ccc/333?text=IIT-D"},{name:"IIM Lucknow",courses:13,logo:"https://placehold.co/100x100/ccc/333?text=IIM-L"},{name:"IIM Indore",courses:20,logo:"https://placehold.co/100x100/ccc/333?text=IIM-I"},{name:"XLRI Jamshedpur",courses:3,logo:"https://placehold.co/100x100/ccc/333?text=XLRI"},{name:"IIM Raipur",courses:2,logo:"https://placehold.co/100x100/ccc/333?text=IIM-R"}],NA=()=>h.jsxs(jA,{children:[h.jsx(OA,{children:h.jsxs(DA,{children:["Get Certifications from",h.jsx("strong",{children:"Premier Institutes"})]})}),h.jsxs(RA,{children:[UA.map((n,a)=>h.jsxs(LA,{children:[h.jsx(BA,{src:n.logo,alt:`${n.name} logo`}),h.jsxs(zA,{children:[h.jsx(kA,{children:n.name}),h.jsxs(PA,{children:[n.courses," Course",n.courses>1?"s":""]})]})]},a)),h.jsx(VA,{children:"View Courses From All Institutions →"})]})]}),_A=S.section`
  background-color: #ffffff;
  padding: 5rem 2rem;
  font-family: 'Arial', sans-serif;
  position: relative;
  overflow: hidden;
  border-bottom: 3px solid #f0f2f5; // Add a subtle separator line
`,HA=S.div`
  max-width: 1200px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: minmax(0, 1.1fr) minmax(0, 0.9fr); // Give slightly more space to text
  gap: 4rem; // Increased gap for better separation
  align-items: center;
  /* border: 2px solid red; */

  @media (max-width: 992px) {
    grid-template-columns: 1fr;
    gap: 3rem;
  }
`,GA=S.div`
  // Decorative corner bracket for the text block
  position: relative;
  padding-left: 20px;
  &::before {
    content: '';
    position: absolute;
    top: -15px;
    left: -15px;
    width: 50px;
    height: 50px;
    border-color: #d9534f;
    border-style: solid;
    border-width: 8px 0 0 8px;
  }
`,IA=S.p`
  color: #333;
  font-size: 1.1rem;
  font-weight: 600;
  margin: 0 0 0.5rem 0;
`,qA=S.h2`
  color: #000080; // Navy blue
  font-size: 2.5rem;
  font-weight: bold;
  margin: 0 0 1.5rem 0;
  line-height: 1.2;
`,FA=S.p`
  color: #555;
  font-size: 1rem;
  line-height: 1.6;
  margin-bottom: 2.5rem;
`,YA=S.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 2rem 1rem;
  margin-bottom: 2.5rem;

  @media (max-width: 576px) {
    grid-template-columns: 1fr;
  }
`,XA=S.div`
  display: flex;
  align-items: center;
  gap: 1rem;
`,KA=S.div`
  width: 70px;
  height: 70px;
  flex-shrink: 0;
  border-radius: 50%;
  background-color: #000080;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.25rem;
  font-weight: bold;
  box-shadow: 0 5px 15px rgba(0, 0, 128, 0.2);
`,$A=S.div``,QA=S.div`
  font-size: 1.5rem;
  font-weight: bold;
  color: #000080;
`,ZA=S.span`
  font-size: 0.9rem;
  color: #666;
  font-weight: 500;
  line-height: 1.3;
`,JA=S.a`
  display: inline-block;
  background-color: #d9534f;
  color: #ffffff;
  padding: 0.8rem 2rem;
  border-radius: 4px;
  text-decoration: none;
  font-weight: bold;
  font-size: 1rem;
  transition:
    background-color 0.3s ease,
    transform 0.3s ease;
  box-shadow: 0 4px 10px rgba(217, 83, 79, 0.3);

  &:hover {
    background-color: #c9302c;
    transform: translateY(-2px);
  }
`,WA=S.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-template-rows: auto auto;
  gap: 1.5rem;
  position: relative;

  // Decorative corner bracket for the image grid
  &::after {
    content: '';
    position: absolute;
    bottom: -35px;
    right: -25px;
    width: 50px;
    height: 50px;
    border-color: #000080;
    border-style: solid;
    border-width: 0 8px 8px 0;
  }
`,tw=S.div`
  position: relative;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  aspect-ratio: 1 / 1; // Makes the images square

  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
    transition: transform 0.3s ease;
  }

  &:hover img {
    transform: scale(1.05);
  }
`,ew=S.div`
  position: absolute;
  bottom: 10px;
  left: 10px;
  background-color: rgba(255, 255, 255, 0.9);
  padding: 0.5rem 1rem;
  border-radius: 6px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
  font-weight: 600;
  color: #333;
  font-size: 0.8rem;
  backdrop-filter: blur(4px);
`,nw=S.div`
  position: absolute;
  bottom: -3px;
  left: 5%;
  width: 90%;
  height: 3px;
  background: linear-gradient(to right, #000080 50%, #d9534f 50%);
`,iw=[{value:"1.75L+",label:"Learners Empowered"},{value:"500+",label:"Recruitment Partners"},{value:"70K+",label:"Placement Opportunities"},{value:"5000+",label:"Hrs of e-Learning Content"}],aw=[{src:"https://placehold.co/400x400/a29bfe/ffffff?text=Faculty",tag:"Best-in-class Faculty"},{src:"https://placehold.co/400x400/74b9ff/ffffff?text=Courses",tag:"Recommended Courses"},{src:"https://placehold.co/400x400/81ecec/ffffff?text=Finance",tag:"Assured Finance Options"},{src:"https://placehold.co/400x400/55efc4/ffffff?text=Success",tag:"Proven Career Success"}],rw=()=>h.jsxs(_A,{children:[h.jsxs(HA,{children:[h.jsxs(GA,{children:[h.jsx(IA,{children:"Why us?"}),h.jsx(qA,{children:"The Career Counselling Corporation of India Advantage"}),h.jsx(FA,{children:"Because we are focused on you, your learning outcomes, and your career development. No matter what stage of career you are at, you can choose from our wide range of learning and career development solutions that will equip you to rise in a competitive world."}),h.jsx(YA,{children:iw.map((n,a)=>h.jsxs(XA,{children:[h.jsx(KA,{children:n.value.split("+")[0].replace(/[^\d.]/g,"")}),h.jsxs($A,{children:[h.jsx(QA,{children:n.value}),h.jsx(ZA,{children:n.label})]})]},a))}),h.jsx(JA,{href:"#",children:"Know More"})]}),h.jsx(WA,{children:aw.map((n,a)=>h.jsxs(tw,{children:[h.jsx("img",{src:n.src,alt:n.tag}),h.jsx(ew,{children:n.tag})]},a))})]}),h.jsx(nw,{})]}),ow=()=>h.jsx("svg",{width:"48",height:"48",viewBox:"0 0 24 24",fill:"white",children:h.jsx("path",{d:"M8 5v14l11-7z"})}),lw=S.section`
  background-color: #f8f9fa;
  padding: 5rem 2rem;
  font-family: 'Arial', sans-serif;
  display: flex;
  flex-direction: column;
  align-items: center;
`,sw=S.div`
  width: 100%;
  max-width: 1200px;
  margin-bottom: 1.5rem;
  text-align: left;
`,cw=S.p`
  color: #d9534f;
  font-size: 1.1rem;
  font-weight: 600;
  margin: 0 0 0.5rem 0;
`,uw=S.h2`
  color: #000080;
  font-size: 2.5rem;
  font-weight: bold;
  margin: 0 0 2rem 0;
`,fw=S.div`
  display: flex;
  gap: 0.75rem;
  margin-bottom: 2.5rem;
  width: 100%;
  max-width: 1200px;
`,sf=S.button`
  padding: 0.6rem 1.5rem;
  font-size: 0.9rem;
  cursor: pointer;
  border-radius: 6px;
  transition: all 0.3s ease;
  font-weight: 500;
  border: 1px solid transparent;

  ${({active:n})=>n?`
        background-color: #000080;
        color: #ffffff;
      `:`
        background-color: #e9ecef;
        color: #555;
        border-color: #dee2e6;
        &:hover {
          background-color: #dde1e5;
        }
      `}
`,dw=S.div`
  width: 100%;
  max-width: 1200px;
  position: relative;
  overflow: hidden;
`,hw=q1`
  from { opacity: 0; transform: translateX(20px); }
  to { opacity: 1; transform: translateX(0); }
`,mw=S.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 3rem;
  align-items: center;
  animation: ${hw} 0.6s ease-in-out;

  @media (max-width: 992px) {
    grid-template-columns: 1fr;
  }
`,pw=S.div`
  background-color: #ffffff;
  border-radius: 12px;
  padding: 2rem;
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.07);
  display: flex;
  flex-direction: column;
  height: 100%;
`,gw=S.div`
  display: flex;
  align-items: center;
  gap: 1.5rem;
  margin-bottom: 1.5rem;
`,yw=S.img`
  width: 80px;
  height: 80px;
  border-radius: 50%;
  object-fit: cover;
  border: 3px solid #000080;
`,xw=S.div``,vw=S.h3`
  font-size: 1.2rem;
  font-weight: bold;
  color: #000080;
  margin: 0 0 0.25rem 0;
`,bw=S.p`
  font-size: 0.9rem;
  color: #555;
  margin: 0;
  line-height: 1.4;
`,Sw=S.p`
  font-size: 1rem;
  color: #333;
  line-height: 1.7;
  font-style: italic;
  margin: 0;

  strong {
    font-style: normal;
    font-weight: 600;
    color: #000080;
  }
`,jd=S.div`
  position: relative;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.07);
  cursor: pointer;

  img {
    width: 100%;
    display: block;
  }
`,Aw=S.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.3);
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 1;
  transition: opacity 0.3s ease;

  ${jd}:hover & {
    opacity: 0.8;
  }
`,ww=S.div`
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background-color: rgba(217, 83, 79, 0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  transition: transform 0.3s ease;

  ${jd}:hover & {
    transform: scale(1.1);
  }
`,Cw=S.div`
  text-align: center;
  margin-top: 1rem;
`,Tw=S.h3`
  font-size: 1.2rem;
  font-weight: bold;
  color: #000080;
  margin: 0 0 0.25rem 0;
`,Ew=S.p`
  font-size: 0.9rem;
  color: #555;
  margin: 0;
`,Mw=S.div`
  display: flex;
  justify-content: center;
  gap: 0.75rem;
  margin-top: 2.5rem;
`,jw=S.button`
  width: 12px;
  height: 12px;
  border-radius: 50%;
  border: 2px solid #000080;
  background-color: ${({active:n})=>n?"#000080":"transparent"};
  cursor: pointer;
  padding: 0;
  transition: background-color 0.3s ease;
`,Rg=[{type:"text",name:"Dr. Amitabh Mehta",course:"IIM Indore Executive Programme in Healthcare Management - Batch 04",testimonial:"I wanted to do a course for gaining insight into hospital and healthcare management. I have learnt a lot about general management, financial management and learnt the art of dealing with staff with whom I interact in my daily life.",title:"Associate Consultant, Non-invasive Cardiology",image:"https://placehold.co/150x150/e0e0e0/333?text=A.M."},{type:"video",name:"Momita Chakraborty",course:"IIM Calcutta Executive Programme in Business Management",videoThumbnail:"https://placehold.co/800x450/d8d8d8/333?text=Video+Thumbnail"},{type:"text",name:"Jane Doe",course:"Early Career Programme in Data Science",testimonial:"This program completely transformed my career path. The hands-on projects and mentorship were invaluable. I landed my dream job just weeks after graduating!",title:"Data Scientist at TechCorp",image:"https://placehold.co/150x150/f0e0e0/333?text=J.D."},{type:"video",name:"John Smith",course:"Executive Programme in Digital Marketing",videoThumbnail:"https://placehold.co/800x450/e8d8d8/333?text=Video+Thumbnail"}],Ow=()=>{const[n,a]=E.useState("All"),[o,l]=E.useState(0),c=Math.ceil(Rg.length/2),f=p=>{l(p)};E.useEffect(()=>{const p=setInterval(()=>{l(m=>(m+1)%c)},5e3);return()=>clearInterval(p)},[c]);const d=o*2,g=Rg.slice(d,d+2);return h.jsxs(lw,{children:[h.jsxs(sw,{children:[h.jsx(cw,{children:"Alumni Speak"}),h.jsx(uw,{children:"Success Stories"})]}),h.jsxs(fw,{children:[h.jsx(sf,{active:n==="All",onClick:()=>a("All"),children:"All"}),h.jsx(sf,{active:n==="Early",onClick:()=>a("Early"),children:"Early Career Courses"}),h.jsx(sf,{active:n==="Exec",onClick:()=>a("Exec"),children:"Executive Education Courses"})]}),h.jsx(dw,{children:h.jsx(mw,{children:g.map((p,m)=>p.type==="text"?h.jsxs(pw,{children:[h.jsxs(gw,{children:[h.jsx(yw,{src:p.image,alt:p.name}),h.jsxs(xw,{children:[h.jsx(vw,{children:p.name}),h.jsx(bw,{children:p.course})]})]}),h.jsxs(Sw,{children:[h.jsxs("strong",{children:[p.title,": "]}),'"',p.testimonial,'"']})]},m):h.jsxs("div",{children:[h.jsxs(jd,{children:[h.jsx("img",{src:p.videoThumbnail,alt:`Testimonial from ${p.name}`}),h.jsx(Aw,{children:h.jsx(ww,{children:h.jsx(ow,{})})})]}),h.jsxs(Cw,{children:[h.jsx(Tw,{children:p.name}),h.jsx(Ew,{children:p.course})]})]},m))})}),h.jsx(Mw,{children:Array.from({length:c}).map((p,m)=>h.jsx(jw,{active:m===o,onClick:()=>f(m)},m))})]})},Od=E.createContext({});function Dd(n){const a=E.useRef(null);return a.current===null&&(a.current=n()),a.current}const Rd=typeof window<"u",X1=Rd?E.useLayoutEffect:E.useEffect,Ls=E.createContext(null);function Ld(n,a){n.indexOf(a)===-1&&n.push(a)}function Bd(n,a){const o=n.indexOf(a);o>-1&&n.splice(o,1)}const Bn=(n,a,o)=>o>a?a:o<n?n:o;let zd=()=>{};const zn={},K1=n=>/^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(n);function $1(n){return typeof n=="object"&&n!==null}const Q1=n=>/^0[^.\s]+$/u.test(n);function kd(n){let a;return()=>(a===void 0&&(a=n()),a)}const Fe=n=>n,Dw=(n,a)=>o=>a(n(o)),wo=(...n)=>n.reduce(Dw),fo=(n,a,o)=>{const l=a-n;return l===0?1:(o-n)/l};class Pd{constructor(){this.subscriptions=[]}add(a){return Ld(this.subscriptions,a),()=>Bd(this.subscriptions,a)}notify(a,o,l){const c=this.subscriptions.length;if(c)if(c===1)this.subscriptions[0](a,o,l);else for(let f=0;f<c;f++){const d=this.subscriptions[f];d&&d(a,o,l)}}getSize(){return this.subscriptions.length}clear(){this.subscriptions.length=0}}const sn=n=>n*1e3,cn=n=>n/1e3;function Z1(n,a){return a?n*(1e3/a):0}const J1=(n,a,o)=>(((1-3*o+3*a)*n+(3*o-6*a))*n+3*a)*n,Rw=1e-7,Lw=12;function Bw(n,a,o,l,c){let f,d,g=0;do d=a+(o-a)/2,f=J1(d,l,c)-n,f>0?o=d:a=d;while(Math.abs(f)>Rw&&++g<Lw);return d}function Co(n,a,o,l){if(n===a&&o===l)return Fe;const c=f=>Bw(f,0,1,n,o);return f=>f===0||f===1?f:J1(c(f),a,l)}const W1=n=>a=>a<=.5?n(2*a)/2:(2-n(2*(1-a)))/2,tx=n=>a=>1-n(1-a),ex=Co(.33,1.53,.69,.99),Vd=tx(ex),nx=W1(Vd),ix=n=>(n*=2)<1?.5*Vd(n):.5*(2-Math.pow(2,-10*(n-1))),Ud=n=>1-Math.sin(Math.acos(n)),ax=tx(Ud),rx=W1(Ud),zw=Co(.42,0,1,1),kw=Co(0,0,.58,1),ox=Co(.42,0,.58,1),Pw=n=>Array.isArray(n)&&typeof n[0]!="number",lx=n=>Array.isArray(n)&&typeof n[0]=="number",Vw={linear:Fe,easeIn:zw,easeInOut:ox,easeOut:kw,circIn:Ud,circInOut:rx,circOut:ax,backIn:Vd,backInOut:nx,backOut:ex,anticipate:ix},Uw=n=>typeof n=="string",Lg=n=>{if(lx(n)){zd(n.length===4);const[a,o,l,c]=n;return Co(a,o,l,c)}else if(Uw(n))return Vw[n];return n},ql=["setup","read","resolveKeyframes","preUpdate","update","preRender","render","postRender"];function Nw(n,a){let o=new Set,l=new Set,c=!1,f=!1;const d=new WeakSet;let g={delta:0,timestamp:0,isProcessing:!1};function p(x){d.has(x)&&(m.schedule(x),n()),x(g)}const m={schedule:(x,A=!1,b=!1)=>{const O=b&&c?o:l;return A&&d.add(x),O.has(x)||O.add(x),x},cancel:x=>{l.delete(x),d.delete(x)},process:x=>{if(g=x,c){f=!0;return}c=!0,[o,l]=[l,o],o.forEach(p),o.clear(),c=!1,f&&(f=!1,m.process(x))}};return m}const _w=40;function sx(n,a){let o=!1,l=!0;const c={delta:0,timestamp:0,isProcessing:!1},f=()=>o=!0,d=ql.reduce((V,X)=>(V[X]=Nw(f),V),{}),{setup:g,read:p,resolveKeyframes:m,preUpdate:x,update:A,preRender:b,render:C,postRender:O}=d,z=()=>{const V=zn.useManualTiming?c.timestamp:performance.now();o=!1,zn.useManualTiming||(c.delta=l?1e3/60:Math.max(Math.min(V-c.timestamp,_w),1)),c.timestamp=V,c.isProcessing=!0,g.process(c),p.process(c),m.process(c),x.process(c),A.process(c),b.process(c),C.process(c),O.process(c),c.isProcessing=!1,o&&a&&(l=!1,n(z))},P=()=>{o=!0,l=!0,c.isProcessing||n(z)};return{schedule:ql.reduce((V,X)=>{const G=d[X];return V[X]=(K,F=!1,Z=!1)=>(o||P(),G.schedule(K,F,Z)),V},{}),cancel:V=>{for(let X=0;X<ql.length;X++)d[ql[X]].cancel(V)},state:c,steps:d}}const{schedule:Lt,cancel:si,state:se,steps:cf}=sx(typeof requestAnimationFrame<"u"?requestAnimationFrame:Fe,!0);let ls;function Hw(){ls=void 0}const Se={now:()=>(ls===void 0&&Se.set(se.isProcessing||zn.useManualTiming?se.timestamp:performance.now()),ls),set:n=>{ls=n,queueMicrotask(Hw)}},cx=n=>a=>typeof a=="string"&&a.startsWith(n),Nd=cx("--"),Gw=cx("var(--"),_d=n=>Gw(n)?Iw.test(n.split("/*")[0].trim()):!1,Iw=/var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu,Xa={test:n=>typeof n=="number",parse:parseFloat,transform:n=>n},ho={...Xa,transform:n=>Bn(0,1,n)},Fl={...Xa,default:1},io=n=>Math.round(n*1e5)/1e5,Hd=/-?(?:\d+(?:\.\d+)?|\.\d+)/gu;function qw(n){return n==null}const Fw=/^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,Gd=(n,a)=>o=>!!(typeof o=="string"&&Fw.test(o)&&o.startsWith(n)||a&&!qw(o)&&Object.prototype.hasOwnProperty.call(o,a)),ux=(n,a,o)=>l=>{if(typeof l!="string")return l;const[c,f,d,g]=l.match(Hd);return{[n]:parseFloat(c),[a]:parseFloat(f),[o]:parseFloat(d),alpha:g!==void 0?parseFloat(g):1}},Yw=n=>Bn(0,255,n),uf={...Xa,transform:n=>Math.round(Yw(n))},zi={test:Gd("rgb","red"),parse:ux("red","green","blue"),transform:({red:n,green:a,blue:o,alpha:l=1})=>"rgba("+uf.transform(n)+", "+uf.transform(a)+", "+uf.transform(o)+", "+io(ho.transform(l))+")"};function Xw(n){let a="",o="",l="",c="";return n.length>5?(a=n.substring(1,3),o=n.substring(3,5),l=n.substring(5,7),c=n.substring(7,9)):(a=n.substring(1,2),o=n.substring(2,3),l=n.substring(3,4),c=n.substring(4,5),a+=a,o+=o,l+=l,c+=c),{red:parseInt(a,16),green:parseInt(o,16),blue:parseInt(l,16),alpha:c?parseInt(c,16)/255:1}}const $f={test:Gd("#"),parse:Xw,transform:zi.transform},To=n=>({test:a=>typeof a=="string"&&a.endsWith(n)&&a.split(" ").length===1,parse:parseFloat,transform:a=>`${a}${n}`}),oi=To("deg"),un=To("%"),ot=To("px"),Kw=To("vh"),$w=To("vw"),Bg={...un,parse:n=>un.parse(n)/100,transform:n=>un.transform(n*100)},La={test:Gd("hsl","hue"),parse:ux("hue","saturation","lightness"),transform:({hue:n,saturation:a,lightness:o,alpha:l=1})=>"hsla("+Math.round(n)+", "+un.transform(io(a))+", "+un.transform(io(o))+", "+io(ho.transform(l))+")"},Yt={test:n=>zi.test(n)||$f.test(n)||La.test(n),parse:n=>zi.test(n)?zi.parse(n):La.test(n)?La.parse(n):$f.parse(n),transform:n=>typeof n=="string"?n:n.hasOwnProperty("red")?zi.transform(n):La.transform(n),getAnimatableNone:n=>{const a=Yt.parse(n);return a.alpha=0,Yt.transform(a)}},Qw=/(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;function Zw(n){return isNaN(n)&&typeof n=="string"&&(n.match(Hd)?.length||0)+(n.match(Qw)?.length||0)>0}const fx="number",dx="color",Jw="var",Ww="var(",zg="${}",tC=/var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;function mo(n){const a=n.toString(),o=[],l={color:[],number:[],var:[]},c=[];let f=0;const g=a.replace(tC,p=>(Yt.test(p)?(l.color.push(f),c.push(dx),o.push(Yt.parse(p))):p.startsWith(Ww)?(l.var.push(f),c.push(Jw),o.push(p)):(l.number.push(f),c.push(fx),o.push(parseFloat(p))),++f,zg)).split(zg);return{values:o,split:g,indexes:l,types:c}}function hx(n){return mo(n).values}function mx(n){const{split:a,types:o}=mo(n),l=a.length;return c=>{let f="";for(let d=0;d<l;d++)if(f+=a[d],c[d]!==void 0){const g=o[d];g===fx?f+=io(c[d]):g===dx?f+=Yt.transform(c[d]):f+=c[d]}return f}}const eC=n=>typeof n=="number"?0:Yt.test(n)?Yt.getAnimatableNone(n):n;function nC(n){const a=hx(n);return mx(n)(a.map(eC))}const ci={test:Zw,parse:hx,createTransformer:mx,getAnimatableNone:nC};function ff(n,a,o){return o<0&&(o+=1),o>1&&(o-=1),o<1/6?n+(a-n)*6*o:o<1/2?a:o<2/3?n+(a-n)*(2/3-o)*6:n}function iC({hue:n,saturation:a,lightness:o,alpha:l}){n/=360,a/=100,o/=100;let c=0,f=0,d=0;if(!a)c=f=d=o;else{const g=o<.5?o*(1+a):o+a-o*a,p=2*o-g;c=ff(p,g,n+1/3),f=ff(p,g,n),d=ff(p,g,n-1/3)}return{red:Math.round(c*255),green:Math.round(f*255),blue:Math.round(d*255),alpha:l}}function ys(n,a){return o=>o>0?a:n}const kt=(n,a,o)=>n+(a-n)*o,df=(n,a,o)=>{const l=n*n,c=o*(a*a-l)+l;return c<0?0:Math.sqrt(c)},aC=[$f,zi,La],rC=n=>aC.find(a=>a.test(n));function kg(n){const a=rC(n);if(!a)return!1;let o=a.parse(n);return a===La&&(o=iC(o)),o}const Pg=(n,a)=>{const o=kg(n),l=kg(a);if(!o||!l)return ys(n,a);const c={...o};return f=>(c.red=df(o.red,l.red,f),c.green=df(o.green,l.green,f),c.blue=df(o.blue,l.blue,f),c.alpha=kt(o.alpha,l.alpha,f),zi.transform(c))},Qf=new Set(["none","hidden"]);function oC(n,a){return Qf.has(n)?o=>o<=0?n:a:o=>o>=1?a:n}function lC(n,a){return o=>kt(n,a,o)}function Id(n){return typeof n=="number"?lC:typeof n=="string"?_d(n)?ys:Yt.test(n)?Pg:uC:Array.isArray(n)?px:typeof n=="object"?Yt.test(n)?Pg:sC:ys}function px(n,a){const o=[...n],l=o.length,c=n.map((f,d)=>Id(f)(f,a[d]));return f=>{for(let d=0;d<l;d++)o[d]=c[d](f);return o}}function sC(n,a){const o={...n,...a},l={};for(const c in o)n[c]!==void 0&&a[c]!==void 0&&(l[c]=Id(n[c])(n[c],a[c]));return c=>{for(const f in l)o[f]=l[f](c);return o}}function cC(n,a){const o=[],l={color:0,var:0,number:0};for(let c=0;c<a.values.length;c++){const f=a.types[c],d=n.indexes[f][l[f]],g=n.values[d]??0;o[c]=g,l[f]++}return o}const uC=(n,a)=>{const o=ci.createTransformer(a),l=mo(n),c=mo(a);return l.indexes.var.length===c.indexes.var.length&&l.indexes.color.length===c.indexes.color.length&&l.indexes.number.length>=c.indexes.number.length?Qf.has(n)&&!c.values.length||Qf.has(a)&&!l.values.length?oC(n,a):wo(px(cC(l,c),c.values),o):ys(n,a)};function gx(n,a,o){return typeof n=="number"&&typeof a=="number"&&typeof o=="number"?kt(n,a,o):Id(n)(n,a)}const fC=n=>{const a=({timestamp:o})=>n(o);return{start:(o=!0)=>Lt.update(a,o),stop:()=>si(a),now:()=>se.isProcessing?se.timestamp:Se.now()}},yx=(n,a,o=10)=>{let l="";const c=Math.max(Math.round(a/o),2);for(let f=0;f<c;f++)l+=Math.round(n(f/(c-1))*1e4)/1e4+", ";return`linear(${l.substring(0,l.length-2)})`},xs=2e4;function qd(n){let a=0;const o=50;let l=n.next(a);for(;!l.done&&a<xs;)a+=o,l=n.next(a);return a>=xs?1/0:a}function dC(n,a=100,o){const l=o({...n,keyframes:[0,a]}),c=Math.min(qd(l),xs);return{type:"keyframes",ease:f=>l.next(c*f).value/a,duration:cn(c)}}const hC=5;function xx(n,a,o){const l=Math.max(a-hC,0);return Z1(o-n(l),a-l)}const Nt={stiffness:100,damping:10,mass:1,velocity:0,duration:800,bounce:.3,visualDuration:.3,restSpeed:{granular:.01,default:2},restDelta:{granular:.005,default:.5},minDuration:.01,maxDuration:10,minDamping:.05,maxDamping:1},hf=.001;function mC({duration:n=Nt.duration,bounce:a=Nt.bounce,velocity:o=Nt.velocity,mass:l=Nt.mass}){let c,f,d=1-a;d=Bn(Nt.minDamping,Nt.maxDamping,d),n=Bn(Nt.minDuration,Nt.maxDuration,cn(n)),d<1?(c=m=>{const x=m*d,A=x*n,b=x-o,C=Zf(m,d),O=Math.exp(-A);return hf-b/C*O},f=m=>{const A=m*d*n,b=A*o+o,C=Math.pow(d,2)*Math.pow(m,2)*n,O=Math.exp(-A),z=Zf(Math.pow(m,2),d);return(-c(m)+hf>0?-1:1)*((b-C)*O)/z}):(c=m=>{const x=Math.exp(-m*n),A=(m-o)*n+1;return-hf+x*A},f=m=>{const x=Math.exp(-m*n),A=(o-m)*(n*n);return x*A});const g=5/n,p=gC(c,f,g);if(n=sn(n),isNaN(p))return{stiffness:Nt.stiffness,damping:Nt.damping,duration:n};{const m=Math.pow(p,2)*l;return{stiffness:m,damping:d*2*Math.sqrt(l*m),duration:n}}}const pC=12;function gC(n,a,o){let l=o;for(let c=1;c<pC;c++)l=l-n(l)/a(l);return l}function Zf(n,a){return n*Math.sqrt(1-a*a)}const yC=["duration","bounce"],xC=["stiffness","damping","mass"];function Vg(n,a){return a.some(o=>n[o]!==void 0)}function vC(n){let a={velocity:Nt.velocity,stiffness:Nt.stiffness,damping:Nt.damping,mass:Nt.mass,isResolvedFromDuration:!1,...n};if(!Vg(n,xC)&&Vg(n,yC))if(n.visualDuration){const o=n.visualDuration,l=2*Math.PI/(o*1.2),c=l*l,f=2*Bn(.05,1,1-(n.bounce||0))*Math.sqrt(c);a={...a,mass:Nt.mass,stiffness:c,damping:f}}else{const o=mC(n);a={...a,...o,mass:Nt.mass},a.isResolvedFromDuration=!0}return a}function vs(n=Nt.visualDuration,a=Nt.bounce){const o=typeof n!="object"?{visualDuration:n,keyframes:[0,1],bounce:a}:n;let{restSpeed:l,restDelta:c}=o;const f=o.keyframes[0],d=o.keyframes[o.keyframes.length-1],g={done:!1,value:f},{stiffness:p,damping:m,mass:x,duration:A,velocity:b,isResolvedFromDuration:C}=vC({...o,velocity:-cn(o.velocity||0)}),O=b||0,z=m/(2*Math.sqrt(p*x)),P=d-f,R=cn(Math.sqrt(p/x)),H=Math.abs(P)<5;l||(l=H?Nt.restSpeed.granular:Nt.restSpeed.default),c||(c=H?Nt.restDelta.granular:Nt.restDelta.default);let V;if(z<1){const G=Zf(R,z);V=K=>{const F=Math.exp(-z*R*K);return d-F*((O+z*R*P)/G*Math.sin(G*K)+P*Math.cos(G*K))}}else if(z===1)V=G=>d-Math.exp(-R*G)*(P+(O+R*P)*G);else{const G=R*Math.sqrt(z*z-1);V=K=>{const F=Math.exp(-z*R*K),Z=Math.min(G*K,300);return d-F*((O+z*R*P)*Math.sinh(Z)+G*P*Math.cosh(Z))/G}}const X={calculatedDuration:C&&A||null,next:G=>{const K=V(G);if(C)g.done=G>=A;else{let F=G===0?O:0;z<1&&(F=G===0?sn(O):xx(V,G,K));const Z=Math.abs(F)<=l,lt=Math.abs(d-K)<=c;g.done=Z&&lt}return g.value=g.done?d:K,g},toString:()=>{const G=Math.min(qd(X),xs),K=yx(F=>X.next(G*F).value,G,30);return G+"ms "+K},toTransition:()=>{}};return X}vs.applyToOptions=n=>{const a=dC(n,100,vs);return n.ease=a.ease,n.duration=sn(a.duration),n.type="keyframes",n};function Jf({keyframes:n,velocity:a=0,power:o=.8,timeConstant:l=325,bounceDamping:c=10,bounceStiffness:f=500,modifyTarget:d,min:g,max:p,restDelta:m=.5,restSpeed:x}){const A=n[0],b={done:!1,value:A},C=Z=>g!==void 0&&Z<g||p!==void 0&&Z>p,O=Z=>g===void 0?p:p===void 0||Math.abs(g-Z)<Math.abs(p-Z)?g:p;let z=o*a;const P=A+z,R=d===void 0?P:d(P);R!==P&&(z=R-A);const H=Z=>-z*Math.exp(-Z/l),V=Z=>R+H(Z),X=Z=>{const lt=H(Z),vt=V(Z);b.done=Math.abs(lt)<=m,b.value=b.done?R:vt};let G,K;const F=Z=>{C(b.value)&&(G=Z,K=vs({keyframes:[b.value,O(b.value)],velocity:xx(V,Z,b.value),damping:c,stiffness:f,restDelta:m,restSpeed:x}))};return F(0),{calculatedDuration:null,next:Z=>{let lt=!1;return!K&&G===void 0&&(lt=!0,X(Z),F(Z)),G!==void 0&&Z>=G?K.next(Z-G):(!lt&&X(Z),b)}}}function bC(n,a,o){const l=[],c=o||zn.mix||gx,f=n.length-1;for(let d=0;d<f;d++){let g=c(n[d],n[d+1]);if(a){const p=Array.isArray(a)?a[d]||Fe:a;g=wo(p,g)}l.push(g)}return l}function SC(n,a,{clamp:o=!0,ease:l,mixer:c}={}){const f=n.length;if(zd(f===a.length),f===1)return()=>a[0];if(f===2&&a[0]===a[1])return()=>a[1];const d=n[0]===n[1];n[0]>n[f-1]&&(n=[...n].reverse(),a=[...a].reverse());const g=bC(a,l,c),p=g.length,m=x=>{if(d&&x<n[0])return a[0];let A=0;if(p>1)for(;A<n.length-2&&!(x<n[A+1]);A++);const b=fo(n[A],n[A+1],x);return g[A](b)};return o?x=>m(Bn(n[0],n[f-1],x)):m}function AC(n,a){const o=n[n.length-1];for(let l=1;l<=a;l++){const c=fo(0,a,l);n.push(kt(o,1,c))}}function wC(n){const a=[0];return AC(a,n.length-1),a}function CC(n,a){return n.map(o=>o*a)}function TC(n,a){return n.map(()=>a||ox).splice(0,n.length-1)}function ao({duration:n=300,keyframes:a,times:o,ease:l="easeInOut"}){const c=Pw(l)?l.map(Lg):Lg(l),f={done:!1,value:a[0]},d=CC(o&&o.length===a.length?o:wC(a),n),g=SC(d,a,{ease:Array.isArray(c)?c:TC(a,c)});return{calculatedDuration:n,next:p=>(f.value=g(p),f.done=p>=n,f)}}const EC=n=>n!==null;function Fd(n,{repeat:a,repeatType:o="loop"},l,c=1){const f=n.filter(EC),g=c<0||a&&o!=="loop"&&a%2===1?0:f.length-1;return!g||l===void 0?f[g]:l}const MC={decay:Jf,inertia:Jf,tween:ao,keyframes:ao,spring:vs};function vx(n){typeof n.type=="string"&&(n.type=MC[n.type])}class Yd{constructor(){this.updateFinished()}get finished(){return this._finished}updateFinished(){this._finished=new Promise(a=>{this.resolve=a})}notifyFinished(){this.resolve()}then(a,o){return this.finished.then(a,o)}}const jC=n=>n/100;class Xd extends Yd{constructor(a){super(),this.state="idle",this.startTime=null,this.isStopped=!1,this.currentTime=0,this.holdTime=null,this.playbackSpeed=1,this.stop=()=>{const{motionValue:o}=this.options;o&&o.updatedAt!==Se.now()&&this.tick(Se.now()),this.isStopped=!0,this.state!=="idle"&&(this.teardown(),this.options.onStop?.())},this.options=a,this.initAnimation(),this.play(),a.autoplay===!1&&this.pause()}initAnimation(){const{options:a}=this;vx(a);const{type:o=ao,repeat:l=0,repeatDelay:c=0,repeatType:f,velocity:d=0}=a;let{keyframes:g}=a;const p=o||ao;p!==ao&&typeof g[0]!="number"&&(this.mixKeyframes=wo(jC,gx(g[0],g[1])),g=[0,100]);const m=p({...a,keyframes:g});f==="mirror"&&(this.mirroredGenerator=p({...a,keyframes:[...g].reverse(),velocity:-d})),m.calculatedDuration===null&&(m.calculatedDuration=qd(m));const{calculatedDuration:x}=m;this.calculatedDuration=x,this.resolvedDuration=x+c,this.totalDuration=this.resolvedDuration*(l+1)-c,this.generator=m}updateTime(a){const o=Math.round(a-this.startTime)*this.playbackSpeed;this.holdTime!==null?this.currentTime=this.holdTime:this.currentTime=o}tick(a,o=!1){const{generator:l,totalDuration:c,mixKeyframes:f,mirroredGenerator:d,resolvedDuration:g,calculatedDuration:p}=this;if(this.startTime===null)return l.next(0);const{delay:m=0,keyframes:x,repeat:A,repeatType:b,repeatDelay:C,type:O,onUpdate:z,finalKeyframe:P}=this.options;this.speed>0?this.startTime=Math.min(this.startTime,a):this.speed<0&&(this.startTime=Math.min(a-c/this.speed,this.startTime)),o?this.currentTime=a:this.updateTime(a);const R=this.currentTime-m*(this.playbackSpeed>=0?1:-1),H=this.playbackSpeed>=0?R<0:R>c;this.currentTime=Math.max(R,0),this.state==="finished"&&this.holdTime===null&&(this.currentTime=c);let V=this.currentTime,X=l;if(A){const Z=Math.min(this.currentTime,c)/g;let lt=Math.floor(Z),vt=Z%1;!vt&&Z>=1&&(vt=1),vt===1&&lt--,lt=Math.min(lt,A+1),!!(lt%2)&&(b==="reverse"?(vt=1-vt,C&&(vt-=C/g)):b==="mirror"&&(X=d)),V=Bn(0,1,vt)*g}const G=H?{done:!1,value:x[0]}:X.next(V);f&&(G.value=f(G.value));let{done:K}=G;!H&&p!==null&&(K=this.playbackSpeed>=0?this.currentTime>=c:this.currentTime<=0);const F=this.holdTime===null&&(this.state==="finished"||this.state==="running"&&K);return F&&O!==Jf&&(G.value=Fd(x,this.options,P,this.speed)),z&&z(G.value),F&&this.finish(),G}then(a,o){return this.finished.then(a,o)}get duration(){return cn(this.calculatedDuration)}get time(){return cn(this.currentTime)}set time(a){a=sn(a),this.currentTime=a,this.startTime===null||this.holdTime!==null||this.playbackSpeed===0?this.holdTime=a:this.driver&&(this.startTime=this.driver.now()-a/this.playbackSpeed),this.driver?.start(!1)}get speed(){return this.playbackSpeed}set speed(a){this.updateTime(Se.now());const o=this.playbackSpeed!==a;this.playbackSpeed=a,o&&(this.time=cn(this.currentTime))}play(){if(this.isStopped)return;const{driver:a=fC,startTime:o}=this.options;this.driver||(this.driver=a(c=>this.tick(c))),this.options.onPlay?.();const l=this.driver.now();this.state==="finished"?(this.updateFinished(),this.startTime=l):this.holdTime!==null?this.startTime=l-this.holdTime:this.startTime||(this.startTime=o??l),this.state==="finished"&&this.speed<0&&(this.startTime+=this.calculatedDuration),this.holdTime=null,this.state="running",this.driver.start()}pause(){this.state="paused",this.updateTime(Se.now()),this.holdTime=this.currentTime}complete(){this.state!=="running"&&this.play(),this.state="finished",this.holdTime=null}finish(){this.notifyFinished(),this.teardown(),this.state="finished",this.options.onComplete?.()}cancel(){this.holdTime=null,this.startTime=0,this.tick(0),this.teardown(),this.options.onCancel?.()}teardown(){this.state="idle",this.stopDriver(),this.startTime=this.holdTime=null}stopDriver(){this.driver&&(this.driver.stop(),this.driver=void 0)}sample(a){return this.startTime=0,this.tick(a,!0)}attachTimeline(a){return this.options.allowFlatten&&(this.options.type="keyframes",this.options.ease="linear",this.initAnimation()),this.driver?.stop(),a.observe(this)}}function OC(n){for(let a=1;a<n.length;a++)n[a]??(n[a]=n[a-1])}const ki=n=>n*180/Math.PI,Wf=n=>{const a=ki(Math.atan2(n[1],n[0]));return td(a)},DC={x:4,y:5,translateX:4,translateY:5,scaleX:0,scaleY:3,scale:n=>(Math.abs(n[0])+Math.abs(n[3]))/2,rotate:Wf,rotateZ:Wf,skewX:n=>ki(Math.atan(n[1])),skewY:n=>ki(Math.atan(n[2])),skew:n=>(Math.abs(n[1])+Math.abs(n[2]))/2},td=n=>(n=n%360,n<0&&(n+=360),n),Ug=Wf,Ng=n=>Math.sqrt(n[0]*n[0]+n[1]*n[1]),_g=n=>Math.sqrt(n[4]*n[4]+n[5]*n[5]),RC={x:12,y:13,z:14,translateX:12,translateY:13,translateZ:14,scaleX:Ng,scaleY:_g,scale:n=>(Ng(n)+_g(n))/2,rotateX:n=>td(ki(Math.atan2(n[6],n[5]))),rotateY:n=>td(ki(Math.atan2(-n[2],n[0]))),rotateZ:Ug,rotate:Ug,skewX:n=>ki(Math.atan(n[4])),skewY:n=>ki(Math.atan(n[1])),skew:n=>(Math.abs(n[1])+Math.abs(n[4]))/2};function ed(n){return n.includes("scale")?1:0}function nd(n,a){if(!n||n==="none")return ed(a);const o=n.match(/^matrix3d\(([-\d.e\s,]+)\)$/u);let l,c;if(o)l=RC,c=o;else{const g=n.match(/^matrix\(([-\d.e\s,]+)\)$/u);l=DC,c=g}if(!c)return ed(a);const f=l[a],d=c[1].split(",").map(BC);return typeof f=="function"?f(d):d[f]}const LC=(n,a)=>{const{transform:o="none"}=getComputedStyle(n);return nd(o,a)};function BC(n){return parseFloat(n.trim())}const Ka=["transformPerspective","x","y","z","translateX","translateY","translateZ","scale","scaleX","scaleY","rotate","rotateX","rotateY","rotateZ","skew","skewX","skewY"],$a=new Set(Ka),Hg=n=>n===Xa||n===ot,zC=new Set(["x","y","z"]),kC=Ka.filter(n=>!zC.has(n));function PC(n){const a=[];return kC.forEach(o=>{const l=n.getValue(o);l!==void 0&&(a.push([o,l.get()]),l.set(o.startsWith("scale")?1:0))}),a}const Vi={width:({x:n},{paddingLeft:a="0",paddingRight:o="0"})=>n.max-n.min-parseFloat(a)-parseFloat(o),height:({y:n},{paddingTop:a="0",paddingBottom:o="0"})=>n.max-n.min-parseFloat(a)-parseFloat(o),top:(n,{top:a})=>parseFloat(a),left:(n,{left:a})=>parseFloat(a),bottom:({y:n},{top:a})=>parseFloat(a)+(n.max-n.min),right:({x:n},{left:a})=>parseFloat(a)+(n.max-n.min),x:(n,{transform:a})=>nd(a,"x"),y:(n,{transform:a})=>nd(a,"y")};Vi.translateX=Vi.x;Vi.translateY=Vi.y;const Ui=new Set;let id=!1,ad=!1,rd=!1;function bx(){if(ad){const n=Array.from(Ui).filter(l=>l.needsMeasurement),a=new Set(n.map(l=>l.element)),o=new Map;a.forEach(l=>{const c=PC(l);c.length&&(o.set(l,c),l.render())}),n.forEach(l=>l.measureInitialState()),a.forEach(l=>{l.render();const c=o.get(l);c&&c.forEach(([f,d])=>{l.getValue(f)?.set(d)})}),n.forEach(l=>l.measureEndState()),n.forEach(l=>{l.suspendedScrollY!==void 0&&window.scrollTo(0,l.suspendedScrollY)})}ad=!1,id=!1,Ui.forEach(n=>n.complete(rd)),Ui.clear()}function Sx(){Ui.forEach(n=>{n.readKeyframes(),n.needsMeasurement&&(ad=!0)})}function VC(){rd=!0,Sx(),bx(),rd=!1}class Kd{constructor(a,o,l,c,f,d=!1){this.state="pending",this.isAsync=!1,this.needsMeasurement=!1,this.unresolvedKeyframes=[...a],this.onComplete=o,this.name=l,this.motionValue=c,this.element=f,this.isAsync=d}scheduleResolve(){this.state="scheduled",this.isAsync?(Ui.add(this),id||(id=!0,Lt.read(Sx),Lt.resolveKeyframes(bx))):(this.readKeyframes(),this.complete())}readKeyframes(){const{unresolvedKeyframes:a,name:o,element:l,motionValue:c}=this;if(a[0]===null){const f=c?.get(),d=a[a.length-1];if(f!==void 0)a[0]=f;else if(l&&o){const g=l.readValue(o,d);g!=null&&(a[0]=g)}a[0]===void 0&&(a[0]=d),c&&f===void 0&&c.set(a[0])}OC(a)}setFinalKeyframe(){}measureInitialState(){}renderEndStyles(){}measureEndState(){}complete(a=!1){this.state="complete",this.onComplete(this.unresolvedKeyframes,this.finalKeyframe,a),Ui.delete(this)}cancel(){this.state==="scheduled"&&(Ui.delete(this),this.state="pending")}resume(){this.state==="pending"&&this.scheduleResolve()}}const UC=n=>n.startsWith("--");function NC(n,a,o){UC(a)?n.style.setProperty(a,o):n.style[a]=o}const _C=kd(()=>window.ScrollTimeline!==void 0),HC={};function GC(n,a){const o=kd(n);return()=>HC[a]??o()}const Ax=GC(()=>{try{document.createElement("div").animate({opacity:0},{easing:"linear(0, 1)"})}catch{return!1}return!0},"linearEasing"),eo=([n,a,o,l])=>`cubic-bezier(${n}, ${a}, ${o}, ${l})`,Gg={linear:"linear",ease:"ease",easeIn:"ease-in",easeOut:"ease-out",easeInOut:"ease-in-out",circIn:eo([0,.65,.55,1]),circOut:eo([.55,0,1,.45]),backIn:eo([.31,.01,.66,-.59]),backOut:eo([.33,1.53,.69,.99])};function wx(n,a){if(n)return typeof n=="function"?Ax()?yx(n,a):"ease-out":lx(n)?eo(n):Array.isArray(n)?n.map(o=>wx(o,a)||Gg.easeOut):Gg[n]}function IC(n,a,o,{delay:l=0,duration:c=300,repeat:f=0,repeatType:d="loop",ease:g="easeOut",times:p}={},m=void 0){const x={[a]:o};p&&(x.offset=p);const A=wx(g,c);Array.isArray(A)&&(x.easing=A);const b={delay:l,duration:c,easing:Array.isArray(A)?"linear":A,fill:"both",iterations:f+1,direction:d==="reverse"?"alternate":"normal"};return m&&(b.pseudoElement=m),n.animate(x,b)}function Cx(n){return typeof n=="function"&&"applyToOptions"in n}function qC({type:n,...a}){return Cx(n)&&Ax()?n.applyToOptions(a):(a.duration??(a.duration=300),a.ease??(a.ease="easeOut"),a)}class FC extends Yd{constructor(a){if(super(),this.finishedTime=null,this.isStopped=!1,!a)return;const{element:o,name:l,keyframes:c,pseudoElement:f,allowFlatten:d=!1,finalKeyframe:g,onComplete:p}=a;this.isPseudoElement=!!f,this.allowFlatten=d,this.options=a,zd(typeof a.type!="string");const m=qC(a);this.animation=IC(o,l,c,m,f),m.autoplay===!1&&this.animation.pause(),this.animation.onfinish=()=>{if(this.finishedTime=this.time,!f){const x=Fd(c,this.options,g,this.speed);this.updateMotionValue?this.updateMotionValue(x):NC(o,l,x),this.animation.cancel()}p?.(),this.notifyFinished()}}play(){this.isStopped||(this.animation.play(),this.state==="finished"&&this.updateFinished())}pause(){this.animation.pause()}complete(){this.animation.finish?.()}cancel(){try{this.animation.cancel()}catch{}}stop(){if(this.isStopped)return;this.isStopped=!0;const{state:a}=this;a==="idle"||a==="finished"||(this.updateMotionValue?this.updateMotionValue():this.commitStyles(),this.isPseudoElement||this.cancel())}commitStyles(){this.isPseudoElement||this.animation.commitStyles?.()}get duration(){const a=this.animation.effect?.getComputedTiming?.().duration||0;return cn(Number(a))}get time(){return cn(Number(this.animation.currentTime)||0)}set time(a){this.finishedTime=null,this.animation.currentTime=sn(a)}get speed(){return this.animation.playbackRate}set speed(a){a<0&&(this.finishedTime=null),this.animation.playbackRate=a}get state(){return this.finishedTime!==null?"finished":this.animation.playState}get startTime(){return Number(this.animation.startTime)}set startTime(a){this.animation.startTime=a}attachTimeline({timeline:a,observe:o}){return this.allowFlatten&&this.animation.effect?.updateTiming({easing:"linear"}),this.animation.onfinish=null,a&&_C()?(this.animation.timeline=a,Fe):o(this)}}const Tx={anticipate:ix,backInOut:nx,circInOut:rx};function YC(n){return n in Tx}function XC(n){typeof n.ease=="string"&&YC(n.ease)&&(n.ease=Tx[n.ease])}const Ig=10;class KC extends FC{constructor(a){XC(a),vx(a),super(a),a.startTime&&(this.startTime=a.startTime),this.options=a}updateMotionValue(a){const{motionValue:o,onUpdate:l,onComplete:c,element:f,...d}=this.options;if(!o)return;if(a!==void 0){o.set(a);return}const g=new Xd({...d,autoplay:!1}),p=sn(this.finishedTime??this.time);o.setWithVelocity(g.sample(p-Ig).value,g.sample(p).value,Ig),g.stop()}}const qg=(n,a)=>a==="zIndex"?!1:!!(typeof n=="number"||Array.isArray(n)||typeof n=="string"&&(ci.test(n)||n==="0")&&!n.startsWith("url("));function $C(n){const a=n[0];if(n.length===1)return!0;for(let o=0;o<n.length;o++)if(n[o]!==a)return!0}function QC(n,a,o,l){const c=n[0];if(c===null)return!1;if(a==="display"||a==="visibility")return!0;const f=n[n.length-1],d=qg(c,a),g=qg(f,a);return!d||!g?!1:$C(n)||(o==="spring"||Cx(o))&&l}const ZC=new Set(["opacity","clipPath","filter","transform"]),JC=kd(()=>Object.hasOwnProperty.call(Element.prototype,"animate"));function WC(n){const{motionValue:a,name:o,repeatDelay:l,repeatType:c,damping:f,type:d}=n;if(!(a?.owner?.current instanceof HTMLElement))return!1;const{onUpdate:p,transformTemplate:m}=a.owner.getProps();return JC()&&o&&ZC.has(o)&&(o!=="transform"||!m)&&!p&&!l&&c!=="mirror"&&f!==0&&d!=="inertia"}const tT=40;class eT extends Yd{constructor({autoplay:a=!0,delay:o=0,type:l="keyframes",repeat:c=0,repeatDelay:f=0,repeatType:d="loop",keyframes:g,name:p,motionValue:m,element:x,...A}){super(),this.stop=()=>{this._animation&&(this._animation.stop(),this.stopTimeline?.()),this.keyframeResolver?.cancel()},this.createdAt=Se.now();const b={autoplay:a,delay:o,type:l,repeat:c,repeatDelay:f,repeatType:d,name:p,motionValue:m,element:x,...A},C=x?.KeyframeResolver||Kd;this.keyframeResolver=new C(g,(O,z,P)=>this.onKeyframesResolved(O,z,b,!P),p,m,x),this.keyframeResolver?.scheduleResolve()}onKeyframesResolved(a,o,l,c){this.keyframeResolver=void 0;const{name:f,type:d,velocity:g,delay:p,isHandoff:m,onUpdate:x}=l;this.resolvedAt=Se.now(),QC(a,f,d,g)||((zn.instantAnimations||!p)&&x?.(Fd(a,l,o)),a[0]=a[a.length-1],l.duration=0,l.repeat=0);const b={startTime:c?this.resolvedAt?this.resolvedAt-this.createdAt>tT?this.resolvedAt:this.createdAt:this.createdAt:void 0,finalKeyframe:o,...l,keyframes:a},C=!m&&WC(b)?new KC({...b,element:b.motionValue.owner.current}):new Xd(b);C.finished.then(()=>this.notifyFinished()).catch(Fe),this.pendingTimeline&&(this.stopTimeline=C.attachTimeline(this.pendingTimeline),this.pendingTimeline=void 0),this._animation=C}get finished(){return this._animation?this.animation.finished:this._finished}then(a,o){return this.finished.finally(a).then(()=>{})}get animation(){return this._animation||(this.keyframeResolver?.resume(),VC()),this._animation}get duration(){return this.animation.duration}get time(){return this.animation.time}set time(a){this.animation.time=a}get speed(){return this.animation.speed}get state(){return this.animation.state}set speed(a){this.animation.speed=a}get startTime(){return this.animation.startTime}attachTimeline(a){return this._animation?this.stopTimeline=this.animation.attachTimeline(a):this.pendingTimeline=a,()=>this.stop()}play(){this.animation.play()}pause(){this.animation.pause()}complete(){this.animation.complete()}cancel(){this._animation&&this.animation.cancel(),this.keyframeResolver?.cancel()}}const nT=/^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;function iT(n){const a=nT.exec(n);if(!a)return[,];const[,o,l,c]=a;return[`--${o??l}`,c]}function Ex(n,a,o=1){const[l,c]=iT(n);if(!l)return;const f=window.getComputedStyle(a).getPropertyValue(l);if(f){const d=f.trim();return K1(d)?parseFloat(d):d}return _d(c)?Ex(c,a,o+1):c}function $d(n,a){return n?.[a]??n?.default??n}const Mx=new Set(["width","height","top","left","right","bottom",...Ka]),aT={test:n=>n==="auto",parse:n=>n},jx=n=>a=>a.test(n),Ox=[Xa,ot,un,oi,$w,Kw,aT],Fg=n=>Ox.find(jx(n));function rT(n){return typeof n=="number"?n===0:n!==null?n==="none"||n==="0"||Q1(n):!0}const oT=new Set(["brightness","contrast","saturate","opacity"]);function lT(n){const[a,o]=n.slice(0,-1).split("(");if(a==="drop-shadow")return n;const[l]=o.match(Hd)||[];if(!l)return n;const c=o.replace(l,"");let f=oT.has(a)?1:0;return l!==o&&(f*=100),a+"("+f+c+")"}const sT=/\b([a-z-]*)\(.*?\)/gu,od={...ci,getAnimatableNone:n=>{const a=n.match(sT);return a?a.map(lT).join(" "):n}},Yg={...Xa,transform:Math.round},cT={rotate:oi,rotateX:oi,rotateY:oi,rotateZ:oi,scale:Fl,scaleX:Fl,scaleY:Fl,scaleZ:Fl,skew:oi,skewX:oi,skewY:oi,distance:ot,translateX:ot,translateY:ot,translateZ:ot,x:ot,y:ot,z:ot,perspective:ot,transformPerspective:ot,opacity:ho,originX:Bg,originY:Bg,originZ:ot},Qd={borderWidth:ot,borderTopWidth:ot,borderRightWidth:ot,borderBottomWidth:ot,borderLeftWidth:ot,borderRadius:ot,radius:ot,borderTopLeftRadius:ot,borderTopRightRadius:ot,borderBottomRightRadius:ot,borderBottomLeftRadius:ot,width:ot,maxWidth:ot,height:ot,maxHeight:ot,top:ot,right:ot,bottom:ot,left:ot,padding:ot,paddingTop:ot,paddingRight:ot,paddingBottom:ot,paddingLeft:ot,margin:ot,marginTop:ot,marginRight:ot,marginBottom:ot,marginLeft:ot,backgroundPositionX:ot,backgroundPositionY:ot,...cT,zIndex:Yg,fillOpacity:ho,strokeOpacity:ho,numOctaves:Yg},uT={...Qd,color:Yt,backgroundColor:Yt,outlineColor:Yt,fill:Yt,stroke:Yt,borderColor:Yt,borderTopColor:Yt,borderRightColor:Yt,borderBottomColor:Yt,borderLeftColor:Yt,filter:od,WebkitFilter:od},Dx=n=>uT[n];function Rx(n,a){let o=Dx(n);return o!==od&&(o=ci),o.getAnimatableNone?o.getAnimatableNone(a):void 0}const fT=new Set(["auto","none","0"]);function dT(n,a,o){let l=0,c;for(;l<n.length&&!c;){const f=n[l];typeof f=="string"&&!fT.has(f)&&mo(f).values.length&&(c=n[l]),l++}if(c&&o)for(const f of a)n[f]=Rx(o,c)}class hT extends Kd{constructor(a,o,l,c,f){super(a,o,l,c,f,!0)}readKeyframes(){const{unresolvedKeyframes:a,element:o,name:l}=this;if(!o||!o.current)return;super.readKeyframes();for(let p=0;p<a.length;p++){let m=a[p];if(typeof m=="string"&&(m=m.trim(),_d(m))){const x=Ex(m,o.current);x!==void 0&&(a[p]=x),p===a.length-1&&(this.finalKeyframe=m)}}if(this.resolveNoneKeyframes(),!Mx.has(l)||a.length!==2)return;const[c,f]=a,d=Fg(c),g=Fg(f);if(d!==g)if(Hg(d)&&Hg(g))for(let p=0;p<a.length;p++){const m=a[p];typeof m=="string"&&(a[p]=parseFloat(m))}else Vi[l]&&(this.needsMeasurement=!0)}resolveNoneKeyframes(){const{unresolvedKeyframes:a,name:o}=this,l=[];for(let c=0;c<a.length;c++)(a[c]===null||rT(a[c]))&&l.push(c);l.length&&dT(a,l,o)}measureInitialState(){const{element:a,unresolvedKeyframes:o,name:l}=this;if(!a||!a.current)return;l==="height"&&(this.suspendedScrollY=window.pageYOffset),this.measuredOrigin=Vi[l](a.measureViewportBox(),window.getComputedStyle(a.current)),o[0]=this.measuredOrigin;const c=o[o.length-1];c!==void 0&&a.getValue(l,c).jump(c,!1)}measureEndState(){const{element:a,name:o,unresolvedKeyframes:l}=this;if(!a||!a.current)return;const c=a.getValue(o);c&&c.jump(this.measuredOrigin,!1);const f=l.length-1,d=l[f];l[f]=Vi[o](a.measureViewportBox(),window.getComputedStyle(a.current)),d!==null&&this.finalKeyframe===void 0&&(this.finalKeyframe=d),this.removedTransforms?.length&&this.removedTransforms.forEach(([g,p])=>{a.getValue(g).set(p)}),this.resolveNoneKeyframes()}}function mT(n,a,o){if(n instanceof EventTarget)return[n];if(typeof n=="string"){let l=document;const c=o?.[n]??l.querySelectorAll(n);return c?Array.from(c):[]}return Array.from(n)}const Lx=(n,a)=>a&&typeof n=="number"?a.transform(n):n;function Bx(n){return $1(n)&&"offsetHeight"in n}const Xg=30,pT=n=>!isNaN(parseFloat(n));class gT{constructor(a,o={}){this.canTrackVelocity=null,this.events={},this.updateAndNotify=(l,c=!0)=>{const f=Se.now();if(this.updatedAt!==f&&this.setPrevFrameValue(),this.prev=this.current,this.setCurrent(l),this.current!==this.prev&&(this.events.change?.notify(this.current),this.dependents))for(const d of this.dependents)d.dirty();c&&this.events.renderRequest?.notify(this.current)},this.hasAnimated=!1,this.setCurrent(a),this.owner=o.owner}setCurrent(a){this.current=a,this.updatedAt=Se.now(),this.canTrackVelocity===null&&a!==void 0&&(this.canTrackVelocity=pT(this.current))}setPrevFrameValue(a=this.current){this.prevFrameValue=a,this.prevUpdatedAt=this.updatedAt}onChange(a){return this.on("change",a)}on(a,o){this.events[a]||(this.events[a]=new Pd);const l=this.events[a].add(o);return a==="change"?()=>{l(),Lt.read(()=>{this.events.change.getSize()||this.stop()})}:l}clearListeners(){for(const a in this.events)this.events[a].clear()}attach(a,o){this.passiveEffect=a,this.stopPassiveEffect=o}set(a,o=!0){!o||!this.passiveEffect?this.updateAndNotify(a,o):this.passiveEffect(a,this.updateAndNotify)}setWithVelocity(a,o,l){this.set(o),this.prev=void 0,this.prevFrameValue=a,this.prevUpdatedAt=this.updatedAt-l}jump(a,o=!0){this.updateAndNotify(a),this.prev=a,this.prevUpdatedAt=this.prevFrameValue=void 0,o&&this.stop(),this.stopPassiveEffect&&this.stopPassiveEffect()}dirty(){this.events.change?.notify(this.current)}addDependent(a){this.dependents||(this.dependents=new Set),this.dependents.add(a)}removeDependent(a){this.dependents&&this.dependents.delete(a)}get(){return this.current}getPrevious(){return this.prev}getVelocity(){const a=Se.now();if(!this.canTrackVelocity||this.prevFrameValue===void 0||a-this.updatedAt>Xg)return 0;const o=Math.min(this.updatedAt-this.prevUpdatedAt,Xg);return Z1(parseFloat(this.current)-parseFloat(this.prevFrameValue),o)}start(a){return this.stop(),new Promise(o=>{this.hasAnimated=!0,this.animation=a(o),this.events.animationStart&&this.events.animationStart.notify()}).then(()=>{this.events.animationComplete&&this.events.animationComplete.notify(),this.clearAnimation()})}stop(){this.animation&&(this.animation.stop(),this.events.animationCancel&&this.events.animationCancel.notify()),this.clearAnimation()}isAnimating(){return!!this.animation}clearAnimation(){delete this.animation}destroy(){this.dependents?.clear(),this.events.destroy?.notify(),this.clearListeners(),this.stop(),this.stopPassiveEffect&&this.stopPassiveEffect()}}function Ga(n,a){return new gT(n,a)}const{schedule:Zd}=sx(queueMicrotask,!1),Je={x:!1,y:!1};function zx(){return Je.x||Je.y}function yT(n){return n==="x"||n==="y"?Je[n]?null:(Je[n]=!0,()=>{Je[n]=!1}):Je.x||Je.y?null:(Je.x=Je.y=!0,()=>{Je.x=Je.y=!1})}function kx(n,a){const o=mT(n),l=new AbortController,c={passive:!0,...a,signal:l.signal};return[o,c,()=>l.abort()]}function Kg(n){return!(n.pointerType==="touch"||zx())}function xT(n,a,o={}){const[l,c,f]=kx(n,o),d=g=>{if(!Kg(g))return;const{target:p}=g,m=a(p,g);if(typeof m!="function"||!p)return;const x=A=>{Kg(A)&&(m(A),p.removeEventListener("pointerleave",x))};p.addEventListener("pointerleave",x,c)};return l.forEach(g=>{g.addEventListener("pointerenter",d,c)}),f}const Px=(n,a)=>a?n===a?!0:Px(n,a.parentElement):!1,Jd=n=>n.pointerType==="mouse"?typeof n.button!="number"||n.button<=0:n.isPrimary!==!1,vT=new Set(["BUTTON","INPUT","SELECT","TEXTAREA","A"]);function bT(n){return vT.has(n.tagName)||n.tabIndex!==-1}const ss=new WeakSet;function $g(n){return a=>{a.key==="Enter"&&n(a)}}function mf(n,a){n.dispatchEvent(new PointerEvent("pointer"+a,{isPrimary:!0,bubbles:!0}))}const ST=(n,a)=>{const o=n.currentTarget;if(!o)return;const l=$g(()=>{if(ss.has(o))return;mf(o,"down");const c=$g(()=>{mf(o,"up")}),f=()=>mf(o,"cancel");o.addEventListener("keyup",c,a),o.addEventListener("blur",f,a)});o.addEventListener("keydown",l,a),o.addEventListener("blur",()=>o.removeEventListener("keydown",l),a)};function Qg(n){return Jd(n)&&!zx()}function AT(n,a,o={}){const[l,c,f]=kx(n,o),d=g=>{const p=g.currentTarget;if(!Qg(g))return;ss.add(p);const m=a(p,g),x=(C,O)=>{window.removeEventListener("pointerup",A),window.removeEventListener("pointercancel",b),ss.has(p)&&ss.delete(p),Qg(C)&&typeof m=="function"&&m(C,{success:O})},A=C=>{x(C,p===window||p===document||o.useGlobalTarget||Px(p,C.target))},b=C=>{x(C,!1)};window.addEventListener("pointerup",A,c),window.addEventListener("pointercancel",b,c)};return l.forEach(g=>{(o.useGlobalTarget?window:g).addEventListener("pointerdown",d,c),Bx(g)&&(g.addEventListener("focus",m=>ST(m,c)),!bT(g)&&!g.hasAttribute("tabindex")&&(g.tabIndex=0))}),f}function Vx(n){return $1(n)&&"ownerSVGElement"in n}function wT(n){return Vx(n)&&n.tagName==="svg"}const he=n=>!!(n&&n.getVelocity),CT=[...Ox,Yt,ci],TT=n=>CT.find(jx(n)),Wd=E.createContext({transformPagePoint:n=>n,isStatic:!1,reducedMotion:"never"});class ET extends E.Component{getSnapshotBeforeUpdate(a){const o=this.props.childRef.current;if(o&&a.isPresent&&!this.props.isPresent){const l=o.offsetParent,c=Bx(l)&&l.offsetWidth||0,f=this.props.sizeRef.current;f.height=o.offsetHeight||0,f.width=o.offsetWidth||0,f.top=o.offsetTop,f.left=o.offsetLeft,f.right=c-f.width-f.left}return null}componentDidUpdate(){}render(){return this.props.children}}function MT({children:n,isPresent:a,anchorX:o,root:l}){const c=E.useId(),f=E.useRef(null),d=E.useRef({width:0,height:0,top:0,left:0,right:0}),{nonce:g}=E.useContext(Wd);return E.useInsertionEffect(()=>{const{width:p,height:m,top:x,left:A,right:b}=d.current;if(a||!f.current||!p||!m)return;const C=o==="left"?`left: ${A}`:`right: ${b}`;f.current.dataset.motionPopId=c;const O=document.createElement("style");g&&(O.nonce=g);const z=l??document.head;return z.appendChild(O),O.sheet&&O.sheet.insertRule(`
          [data-motion-pop-id="${c}"] {
            position: absolute !important;
            width: ${p}px !important;
            height: ${m}px !important;
            ${C}px !important;
            top: ${x}px !important;
          }
        `),()=>{z.removeChild(O),z.contains(O)&&z.removeChild(O)}},[a]),h.jsx(ET,{isPresent:a,childRef:f,sizeRef:d,children:E.cloneElement(n,{ref:f})})}const jT=({children:n,initial:a,isPresent:o,onExitComplete:l,custom:c,presenceAffectsLayout:f,mode:d,anchorX:g,root:p})=>{const m=Dd(OT),x=E.useId();let A=!0,b=E.useMemo(()=>(A=!1,{id:x,initial:a,isPresent:o,custom:c,onExitComplete:C=>{m.set(C,!0);for(const O of m.values())if(!O)return;l&&l()},register:C=>(m.set(C,!1),()=>m.delete(C))}),[o,m,l]);return f&&A&&(b={...b}),E.useMemo(()=>{m.forEach((C,O)=>m.set(O,!1))},[o]),E.useEffect(()=>{!o&&!m.size&&l&&l()},[o]),d==="popLayout"&&(n=h.jsx(MT,{isPresent:o,anchorX:g,root:p,children:n})),h.jsx(Ls.Provider,{value:b,children:n})};function OT(){return new Map}function Ux(n=!0){const a=E.useContext(Ls);if(a===null)return[!0,null];const{isPresent:o,onExitComplete:l,register:c}=a,f=E.useId();E.useEffect(()=>{if(n)return c(f)},[n]);const d=E.useCallback(()=>n&&l&&l(f),[f,l,n]);return!o&&l?[!1,d]:[!0]}const Yl=n=>n.key||"";function Zg(n){const a=[];return E.Children.forEach(n,o=>{E.isValidElement(o)&&a.push(o)}),a}const po=({children:n,custom:a,initial:o=!0,onExitComplete:l,presenceAffectsLayout:c=!0,mode:f="sync",propagate:d=!1,anchorX:g="left",root:p})=>{const[m,x]=Ux(d),A=E.useMemo(()=>Zg(n),[n]),b=d&&!m?[]:A.map(Yl),C=E.useRef(!0),O=E.useRef(A),z=Dd(()=>new Map),[P,R]=E.useState(A),[H,V]=E.useState(A);X1(()=>{C.current=!1,O.current=A;for(let K=0;K<H.length;K++){const F=Yl(H[K]);b.includes(F)?z.delete(F):z.get(F)!==!0&&z.set(F,!1)}},[H,b.length,b.join("-")]);const X=[];if(A!==P){let K=[...A];for(let F=0;F<H.length;F++){const Z=H[F],lt=Yl(Z);b.includes(lt)||(K.splice(F,0,Z),X.push(Z))}return f==="wait"&&X.length&&(K=X),V(Zg(K)),R(A),null}const{forceRender:G}=E.useContext(Od);return h.jsx(h.Fragment,{children:H.map(K=>{const F=Yl(K),Z=d&&!m?!1:A===H||b.includes(F),lt=()=>{if(z.has(F))z.set(F,!0);else return;let vt=!0;z.forEach(Bt=>{Bt||(vt=!1)}),vt&&(G?.(),V(O.current),d&&x?.(),l&&l())};return h.jsx(jT,{isPresent:Z,initial:!C.current||o?void 0:!1,custom:a,presenceAffectsLayout:c,mode:f,root:p,onExitComplete:Z?void 0:lt,anchorX:g,children:K},F)})})},Nx=E.createContext({strict:!1}),Jg={animation:["animate","variants","whileHover","whileTap","exit","whileInView","whileFocus","whileDrag"],exit:["exit"],drag:["drag","dragControls"],focus:["whileFocus"],hover:["whileHover","onHoverStart","onHoverEnd"],tap:["whileTap","onTap","onTapStart","onTapCancel"],pan:["onPan","onPanStart","onPanSessionStart","onPanEnd"],inView:["whileInView","onViewportEnter","onViewportLeave"],layout:["layout","layoutId"]},Ia={};for(const n in Jg)Ia[n]={isEnabled:a=>Jg[n].some(o=>!!a[o])};function DT(n){for(const a in n)Ia[a]={...Ia[a],...n[a]}}const RT=new Set(["animate","exit","variants","initial","style","values","variants","transition","transformTemplate","custom","inherit","onBeforeLayoutMeasure","onAnimationStart","onAnimationComplete","onUpdate","onDragStart","onDrag","onDragEnd","onMeasureDragConstraints","onDirectionLock","onDragTransitionEnd","_dragX","_dragY","onHoverStart","onHoverEnd","onViewportEnter","onViewportLeave","globalTapTarget","ignoreStrict","viewport"]);function bs(n){return n.startsWith("while")||n.startsWith("drag")&&n!=="draggable"||n.startsWith("layout")||n.startsWith("onTap")||n.startsWith("onPan")||n.startsWith("onLayout")||RT.has(n)}let _x=n=>!bs(n);function LT(n){typeof n=="function"&&(_x=a=>a.startsWith("on")?!bs(a):n(a))}try{LT(require("@emotion/is-prop-valid").default)}catch{}function BT(n,a,o){const l={};for(const c in n)c==="values"&&typeof n.values=="object"||(_x(c)||o===!0&&bs(c)||!a&&!bs(c)||n.draggable&&c.startsWith("onDrag"))&&(l[c]=n[c]);return l}const Bs=E.createContext({});function zs(n){return n!==null&&typeof n=="object"&&typeof n.start=="function"}function go(n){return typeof n=="string"||Array.isArray(n)}const th=["animate","whileInView","whileFocus","whileHover","whileTap","whileDrag","exit"],eh=["initial",...th];function ks(n){return zs(n.animate)||eh.some(a=>go(n[a]))}function Hx(n){return!!(ks(n)||n.variants)}function zT(n,a){if(ks(n)){const{initial:o,animate:l}=n;return{initial:o===!1||go(o)?o:void 0,animate:go(l)?l:void 0}}return n.inherit!==!1?a:{}}function kT(n){const{initial:a,animate:o}=zT(n,E.useContext(Bs));return E.useMemo(()=>({initial:a,animate:o}),[Wg(a),Wg(o)])}function Wg(n){return Array.isArray(n)?n.join(" "):n}const yo={};function PT(n){for(const a in n)yo[a]=n[a],Nd(a)&&(yo[a].isCSSVariable=!0)}function Gx(n,{layout:a,layoutId:o}){return $a.has(n)||n.startsWith("origin")||(a||o!==void 0)&&(!!yo[n]||n==="opacity")}const VT={x:"translateX",y:"translateY",z:"translateZ",transformPerspective:"perspective"},UT=Ka.length;function NT(n,a,o){let l="",c=!0;for(let f=0;f<UT;f++){const d=Ka[f],g=n[d];if(g===void 0)continue;let p=!0;if(typeof g=="number"?p=g===(d.startsWith("scale")?1:0):p=parseFloat(g)===0,!p||o){const m=Lx(g,Qd[d]);if(!p){c=!1;const x=VT[d]||d;l+=`${x}(${m}) `}o&&(a[d]=m)}}return l=l.trim(),o?l=o(a,c?"":l):c&&(l="none"),l}function nh(n,a,o){const{style:l,vars:c,transformOrigin:f}=n;let d=!1,g=!1;for(const p in a){const m=a[p];if($a.has(p)){d=!0;continue}else if(Nd(p)){c[p]=m;continue}else{const x=Lx(m,Qd[p]);p.startsWith("origin")?(g=!0,f[p]=x):l[p]=x}}if(a.transform||(d||o?l.transform=NT(a,n.transform,o):l.transform&&(l.transform="none")),g){const{originX:p="50%",originY:m="50%",originZ:x=0}=f;l.transformOrigin=`${p} ${m} ${x}`}}const ih=()=>({style:{},transform:{},transformOrigin:{},vars:{}});function Ix(n,a,o){for(const l in a)!he(a[l])&&!Gx(l,o)&&(n[l]=a[l])}function _T({transformTemplate:n},a){return E.useMemo(()=>{const o=ih();return nh(o,a,n),Object.assign({},o.vars,o.style)},[a])}function HT(n,a){const o=n.style||{},l={};return Ix(l,o,n),Object.assign(l,_T(n,a)),l}function GT(n,a){const o={},l=HT(n,a);return n.drag&&n.dragListener!==!1&&(o.draggable=!1,l.userSelect=l.WebkitUserSelect=l.WebkitTouchCallout="none",l.touchAction=n.drag===!0?"none":`pan-${n.drag==="x"?"y":"x"}`),n.tabIndex===void 0&&(n.onTap||n.onTapStart||n.whileTap)&&(o.tabIndex=0),o.style=l,o}const IT={offset:"stroke-dashoffset",array:"stroke-dasharray"},qT={offset:"strokeDashoffset",array:"strokeDasharray"};function FT(n,a,o=1,l=0,c=!0){n.pathLength=1;const f=c?IT:qT;n[f.offset]=ot.transform(-l);const d=ot.transform(a),g=ot.transform(o);n[f.array]=`${d} ${g}`}function qx(n,{attrX:a,attrY:o,attrScale:l,pathLength:c,pathSpacing:f=1,pathOffset:d=0,...g},p,m,x){if(nh(n,g,m),p){n.style.viewBox&&(n.attrs.viewBox=n.style.viewBox);return}n.attrs=n.style,n.style={};const{attrs:A,style:b}=n;A.transform&&(b.transform=A.transform,delete A.transform),(b.transform||A.transformOrigin)&&(b.transformOrigin=A.transformOrigin??"50% 50%",delete A.transformOrigin),b.transform&&(b.transformBox=x?.transformBox??"fill-box",delete A.transformBox),a!==void 0&&(A.x=a),o!==void 0&&(A.y=o),l!==void 0&&(A.scale=l),c!==void 0&&FT(A,c,f,d,!1)}const Fx=()=>({...ih(),attrs:{}}),Yx=n=>typeof n=="string"&&n.toLowerCase()==="svg";function YT(n,a,o,l){const c=E.useMemo(()=>{const f=Fx();return qx(f,a,Yx(l),n.transformTemplate,n.style),{...f.attrs,style:{...f.style}}},[a]);if(n.style){const f={};Ix(f,n.style,n),c.style={...f,...c.style}}return c}const XT=["animate","circle","defs","desc","ellipse","g","image","line","filter","marker","mask","metadata","path","pattern","polygon","polyline","rect","stop","switch","symbol","svg","text","tspan","use","view"];function ah(n){return typeof n!="string"||n.includes("-")?!1:!!(XT.indexOf(n)>-1||/[A-Z]/u.test(n))}function KT(n,a,o,{latestValues:l},c,f=!1){const g=(ah(n)?YT:GT)(a,l,c,n),p=BT(a,typeof n=="string",f),m=n!==E.Fragment?{...p,...g,ref:o}:{},{children:x}=a,A=E.useMemo(()=>he(x)?x.get():x,[x]);return E.createElement(n,{...m,children:A})}function ty(n){const a=[{},{}];return n?.values.forEach((o,l)=>{a[0][l]=o.get(),a[1][l]=o.getVelocity()}),a}function rh(n,a,o,l){if(typeof a=="function"){const[c,f]=ty(l);a=a(o!==void 0?o:n.custom,c,f)}if(typeof a=="string"&&(a=n.variants&&n.variants[a]),typeof a=="function"){const[c,f]=ty(l);a=a(o!==void 0?o:n.custom,c,f)}return a}function cs(n){return he(n)?n.get():n}function $T({scrapeMotionValuesFromProps:n,createRenderState:a},o,l,c){return{latestValues:QT(o,l,c,n),renderState:a()}}function QT(n,a,o,l){const c={},f=l(n,{});for(const b in f)c[b]=cs(f[b]);let{initial:d,animate:g}=n;const p=ks(n),m=Hx(n);a&&m&&!p&&n.inherit!==!1&&(d===void 0&&(d=a.initial),g===void 0&&(g=a.animate));let x=o?o.initial===!1:!1;x=x||d===!1;const A=x?g:d;if(A&&typeof A!="boolean"&&!zs(A)){const b=Array.isArray(A)?A:[A];for(let C=0;C<b.length;C++){const O=rh(n,b[C]);if(O){const{transitionEnd:z,transition:P,...R}=O;for(const H in R){let V=R[H];if(Array.isArray(V)){const X=x?V.length-1:0;V=V[X]}V!==null&&(c[H]=V)}for(const H in z)c[H]=z[H]}}}return c}const Xx=n=>(a,o)=>{const l=E.useContext(Bs),c=E.useContext(Ls),f=()=>$T(n,a,l,c);return o?f():Dd(f)};function oh(n,a,o){const{style:l}=n,c={};for(const f in l)(he(l[f])||a.style&&he(a.style[f])||Gx(f,n)||o?.getValue(f)?.liveStyle!==void 0)&&(c[f]=l[f]);return c}const ZT=Xx({scrapeMotionValuesFromProps:oh,createRenderState:ih});function Kx(n,a,o){const l=oh(n,a,o);for(const c in n)if(he(n[c])||he(a[c])){const f=Ka.indexOf(c)!==-1?"attr"+c.charAt(0).toUpperCase()+c.substring(1):c;l[f]=n[c]}return l}const JT=Xx({scrapeMotionValuesFromProps:Kx,createRenderState:Fx}),WT=Symbol.for("motionComponentSymbol");function Ba(n){return n&&typeof n=="object"&&Object.prototype.hasOwnProperty.call(n,"current")}function t8(n,a,o){return E.useCallback(l=>{l&&n.onMount&&n.onMount(l),a&&(l?a.mount(l):a.unmount()),o&&(typeof o=="function"?o(l):Ba(o)&&(o.current=l))},[a])}const lh=n=>n.replace(/([a-z])([A-Z])/gu,"$1-$2").toLowerCase(),e8="framerAppearId",$x="data-"+lh(e8),Qx=E.createContext({});function n8(n,a,o,l,c){const{visualElement:f}=E.useContext(Bs),d=E.useContext(Nx),g=E.useContext(Ls),p=E.useContext(Wd).reducedMotion,m=E.useRef(null);l=l||d.renderer,!m.current&&l&&(m.current=l(n,{visualState:a,parent:f,props:o,presenceContext:g,blockInitialAnimation:g?g.initial===!1:!1,reducedMotionConfig:p}));const x=m.current,A=E.useContext(Qx);x&&!x.projection&&c&&(x.type==="html"||x.type==="svg")&&i8(m.current,o,c,A);const b=E.useRef(!1);E.useInsertionEffect(()=>{x&&b.current&&x.update(o,g)});const C=o[$x],O=E.useRef(!!C&&!window.MotionHandoffIsComplete?.(C)&&window.MotionHasOptimisedAnimation?.(C));return X1(()=>{x&&(b.current=!0,window.MotionIsMounted=!0,x.updateFeatures(),x.scheduleRenderMicrotask(),O.current&&x.animationState&&x.animationState.animateChanges())}),E.useEffect(()=>{x&&(!O.current&&x.animationState&&x.animationState.animateChanges(),O.current&&(queueMicrotask(()=>{window.MotionHandoffMarkAsComplete?.(C)}),O.current=!1))}),x}function i8(n,a,o,l){const{layoutId:c,layout:f,drag:d,dragConstraints:g,layoutScroll:p,layoutRoot:m,layoutCrossfade:x}=a;n.projection=new o(n.latestValues,a["data-framer-portal-id"]?void 0:Zx(n.parent)),n.projection.setOptions({layoutId:c,layout:f,alwaysMeasureLayout:!!d||g&&Ba(g),visualElement:n,animationType:typeof f=="string"?f:"both",initialPromotionConfig:l,crossfade:x,layoutScroll:p,layoutRoot:m})}function Zx(n){if(n)return n.options.allowProjection!==!1?n.projection:Zx(n.parent)}function pf(n,{forwardMotionProps:a=!1}={},o,l){o&&DT(o);const c=ah(n)?JT:ZT;function f(g,p){let m;const x={...E.useContext(Wd),...g,layoutId:a8(g)},{isStatic:A}=x,b=kT(g),C=c(g,A);if(!A&&Rd){r8();const O=o8(x);m=O.MeasureLayout,b.visualElement=n8(n,C,x,l,O.ProjectionNode)}return h.jsxs(Bs.Provider,{value:b,children:[m&&b.visualElement?h.jsx(m,{visualElement:b.visualElement,...x}):null,KT(n,g,t8(C,b.visualElement,p),C,A,a)]})}f.displayName=`motion.${typeof n=="string"?n:`create(${n.displayName??n.name??""})`}`;const d=E.forwardRef(f);return d[WT]=n,d}function a8({layoutId:n}){const a=E.useContext(Od).id;return a&&n!==void 0?a+"-"+n:n}function r8(n,a){E.useContext(Nx).strict}function o8(n){const{drag:a,layout:o}=Ia;if(!a&&!o)return{};const l={...a,...o};return{MeasureLayout:a?.isEnabled(n)||o?.isEnabled(n)?l.MeasureLayout:void 0,ProjectionNode:l.ProjectionNode}}function l8(n,a){if(typeof Proxy>"u")return pf;const o=new Map,l=(f,d)=>pf(f,d,n,a),c=(f,d)=>l(f,d);return new Proxy(c,{get:(f,d)=>d==="create"?l:(o.has(d)||o.set(d,pf(d,void 0,n,a)),o.get(d))})}function Jx({top:n,left:a,right:o,bottom:l}){return{x:{min:a,max:o},y:{min:n,max:l}}}function s8({x:n,y:a}){return{top:a.min,right:n.max,bottom:a.max,left:n.min}}function c8(n,a){if(!a)return n;const o=a({x:n.left,y:n.top}),l=a({x:n.right,y:n.bottom});return{top:o.y,left:o.x,bottom:l.y,right:l.x}}function gf(n){return n===void 0||n===1}function ld({scale:n,scaleX:a,scaleY:o}){return!gf(n)||!gf(a)||!gf(o)}function Li(n){return ld(n)||Wx(n)||n.z||n.rotate||n.rotateX||n.rotateY||n.skewX||n.skewY}function Wx(n){return ey(n.x)||ey(n.y)}function ey(n){return n&&n!=="0%"}function Ss(n,a,o){const l=n-o,c=a*l;return o+c}function ny(n,a,o,l,c){return c!==void 0&&(n=Ss(n,c,l)),Ss(n,o,l)+a}function sd(n,a=0,o=1,l,c){n.min=ny(n.min,a,o,l,c),n.max=ny(n.max,a,o,l,c)}function tv(n,{x:a,y:o}){sd(n.x,a.translate,a.scale,a.originPoint),sd(n.y,o.translate,o.scale,o.originPoint)}const iy=.999999999999,ay=1.0000000000001;function u8(n,a,o,l=!1){const c=o.length;if(!c)return;a.x=a.y=1;let f,d;for(let g=0;g<c;g++){f=o[g],d=f.projectionDelta;const{visualElement:p}=f.options;p&&p.props.style&&p.props.style.display==="contents"||(l&&f.options.layoutScroll&&f.scroll&&f!==f.root&&ka(n,{x:-f.scroll.offset.x,y:-f.scroll.offset.y}),d&&(a.x*=d.x.scale,a.y*=d.y.scale,tv(n,d)),l&&Li(f.latestValues)&&ka(n,f.latestValues))}a.x<ay&&a.x>iy&&(a.x=1),a.y<ay&&a.y>iy&&(a.y=1)}function za(n,a){n.min=n.min+a,n.max=n.max+a}function ry(n,a,o,l,c=.5){const f=kt(n.min,n.max,c);sd(n,a,o,f,l)}function ka(n,a){ry(n.x,a.x,a.scaleX,a.scale,a.originX),ry(n.y,a.y,a.scaleY,a.scale,a.originY)}function ev(n,a){return Jx(c8(n.getBoundingClientRect(),a))}function f8(n,a,o){const l=ev(n,o),{scroll:c}=a;return c&&(za(l.x,c.offset.x),za(l.y,c.offset.y)),l}const oy=()=>({translate:0,scale:1,origin:0,originPoint:0}),Pa=()=>({x:oy(),y:oy()}),ly=()=>({min:0,max:0}),It=()=>({x:ly(),y:ly()}),cd={current:null},nv={current:!1};function d8(){if(nv.current=!0,!!Rd)if(window.matchMedia){const n=window.matchMedia("(prefers-reduced-motion)"),a=()=>cd.current=n.matches;n.addEventListener("change",a),a()}else cd.current=!1}const h8=new WeakMap;function m8(n,a,o){for(const l in a){const c=a[l],f=o[l];if(he(c))n.addValue(l,c);else if(he(f))n.addValue(l,Ga(c,{owner:n}));else if(f!==c)if(n.hasValue(l)){const d=n.getValue(l);d.liveStyle===!0?d.jump(c):d.hasAnimated||d.set(c)}else{const d=n.getStaticValue(l);n.addValue(l,Ga(d!==void 0?d:c,{owner:n}))}}for(const l in o)a[l]===void 0&&n.removeValue(l);return a}const sy=["AnimationStart","AnimationComplete","Update","BeforeLayoutMeasure","LayoutMeasure","LayoutAnimationStart","LayoutAnimationComplete"];class p8{scrapeMotionValuesFromProps(a,o,l){return{}}constructor({parent:a,props:o,presenceContext:l,reducedMotionConfig:c,blockInitialAnimation:f,visualState:d},g={}){this.current=null,this.children=new Set,this.isVariantNode=!1,this.isControllingVariants=!1,this.shouldReduceMotion=null,this.values=new Map,this.KeyframeResolver=Kd,this.features={},this.valueSubscriptions=new Map,this.prevMotionValues={},this.events={},this.propEventSubscriptions={},this.notifyUpdate=()=>this.notify("Update",this.latestValues),this.render=()=>{this.current&&(this.triggerBuild(),this.renderInstance(this.current,this.renderState,this.props.style,this.projection))},this.renderScheduledAt=0,this.scheduleRender=()=>{const b=Se.now();this.renderScheduledAt<b&&(this.renderScheduledAt=b,Lt.render(this.render,!1,!0))};const{latestValues:p,renderState:m}=d;this.latestValues=p,this.baseTarget={...p},this.initialValues=o.initial?{...p}:{},this.renderState=m,this.parent=a,this.props=o,this.presenceContext=l,this.depth=a?a.depth+1:0,this.reducedMotionConfig=c,this.options=g,this.blockInitialAnimation=!!f,this.isControllingVariants=ks(o),this.isVariantNode=Hx(o),this.isVariantNode&&(this.variantChildren=new Set),this.manuallyAnimateOnMount=!!(a&&a.current);const{willChange:x,...A}=this.scrapeMotionValuesFromProps(o,{},this);for(const b in A){const C=A[b];p[b]!==void 0&&he(C)&&C.set(p[b],!1)}}mount(a){this.current=a,h8.set(a,this),this.projection&&!this.projection.instance&&this.projection.mount(a),this.parent&&this.isVariantNode&&!this.isControllingVariants&&(this.removeFromVariantTree=this.parent.addVariantChild(this)),this.values.forEach((o,l)=>this.bindToMotionValue(l,o)),nv.current||d8(),this.shouldReduceMotion=this.reducedMotionConfig==="never"?!1:this.reducedMotionConfig==="always"?!0:cd.current,this.parent&&this.parent.children.add(this),this.update(this.props,this.presenceContext)}unmount(){this.projection&&this.projection.unmount(),si(this.notifyUpdate),si(this.render),this.valueSubscriptions.forEach(a=>a()),this.valueSubscriptions.clear(),this.removeFromVariantTree&&this.removeFromVariantTree(),this.parent&&this.parent.children.delete(this);for(const a in this.events)this.events[a].clear();for(const a in this.features){const o=this.features[a];o&&(o.unmount(),o.isMounted=!1)}this.current=null}bindToMotionValue(a,o){this.valueSubscriptions.has(a)&&this.valueSubscriptions.get(a)();const l=$a.has(a);l&&this.onBindTransform&&this.onBindTransform();const c=o.on("change",g=>{this.latestValues[a]=g,this.props.onUpdate&&Lt.preRender(this.notifyUpdate),l&&this.projection&&(this.projection.isTransformDirty=!0)}),f=o.on("renderRequest",this.scheduleRender);let d;window.MotionCheckAppearSync&&(d=window.MotionCheckAppearSync(this,a,o)),this.valueSubscriptions.set(a,()=>{c(),f(),d&&d(),o.owner&&o.stop()})}sortNodePosition(a){return!this.current||!this.sortInstanceNodePosition||this.type!==a.type?0:this.sortInstanceNodePosition(this.current,a.current)}updateFeatures(){let a="animation";for(a in Ia){const o=Ia[a];if(!o)continue;const{isEnabled:l,Feature:c}=o;if(!this.features[a]&&c&&l(this.props)&&(this.features[a]=new c(this)),this.features[a]){const f=this.features[a];f.isMounted?f.update():(f.mount(),f.isMounted=!0)}}}triggerBuild(){this.build(this.renderState,this.latestValues,this.props)}measureViewportBox(){return this.current?this.measureInstanceViewportBox(this.current,this.props):It()}getStaticValue(a){return this.latestValues[a]}setStaticValue(a,o){this.latestValues[a]=o}update(a,o){(a.transformTemplate||this.props.transformTemplate)&&this.scheduleRender(),this.prevProps=this.props,this.props=a,this.prevPresenceContext=this.presenceContext,this.presenceContext=o;for(let l=0;l<sy.length;l++){const c=sy[l];this.propEventSubscriptions[c]&&(this.propEventSubscriptions[c](),delete this.propEventSubscriptions[c]);const f="on"+c,d=a[f];d&&(this.propEventSubscriptions[c]=this.on(c,d))}this.prevMotionValues=m8(this,this.scrapeMotionValuesFromProps(a,this.prevProps,this),this.prevMotionValues),this.handleChildMotionValue&&this.handleChildMotionValue()}getProps(){return this.props}getVariant(a){return this.props.variants?this.props.variants[a]:void 0}getDefaultTransition(){return this.props.transition}getTransformPagePoint(){return this.props.transformPagePoint}getClosestVariantNode(){return this.isVariantNode?this:this.parent?this.parent.getClosestVariantNode():void 0}addVariantChild(a){const o=this.getClosestVariantNode();if(o)return o.variantChildren&&o.variantChildren.add(a),()=>o.variantChildren.delete(a)}addValue(a,o){const l=this.values.get(a);o!==l&&(l&&this.removeValue(a),this.bindToMotionValue(a,o),this.values.set(a,o),this.latestValues[a]=o.get())}removeValue(a){this.values.delete(a);const o=this.valueSubscriptions.get(a);o&&(o(),this.valueSubscriptions.delete(a)),delete this.latestValues[a],this.removeValueFromRenderState(a,this.renderState)}hasValue(a){return this.values.has(a)}getValue(a,o){if(this.props.values&&this.props.values[a])return this.props.values[a];let l=this.values.get(a);return l===void 0&&o!==void 0&&(l=Ga(o===null?void 0:o,{owner:this}),this.addValue(a,l)),l}readValue(a,o){let l=this.latestValues[a]!==void 0||!this.current?this.latestValues[a]:this.getBaseTargetFromProps(this.props,a)??this.readValueFromInstance(this.current,a,this.options);return l!=null&&(typeof l=="string"&&(K1(l)||Q1(l))?l=parseFloat(l):!TT(l)&&ci.test(o)&&(l=Rx(a,o)),this.setBaseTarget(a,he(l)?l.get():l)),he(l)?l.get():l}setBaseTarget(a,o){this.baseTarget[a]=o}getBaseTarget(a){const{initial:o}=this.props;let l;if(typeof o=="string"||typeof o=="object"){const f=rh(this.props,o,this.presenceContext?.custom);f&&(l=f[a])}if(o&&l!==void 0)return l;const c=this.getBaseTargetFromProps(this.props,a);return c!==void 0&&!he(c)?c:this.initialValues[a]!==void 0&&l===void 0?void 0:this.baseTarget[a]}on(a,o){return this.events[a]||(this.events[a]=new Pd),this.events[a].add(o)}notify(a,...o){this.events[a]&&this.events[a].notify(...o)}scheduleRenderMicrotask(){Zd.render(this.render)}}class iv extends p8{constructor(){super(...arguments),this.KeyframeResolver=hT}sortInstanceNodePosition(a,o){return a.compareDocumentPosition(o)&2?1:-1}getBaseTargetFromProps(a,o){return a.style?a.style[o]:void 0}removeValueFromRenderState(a,{vars:o,style:l}){delete o[a],delete l[a]}handleChildMotionValue(){this.childSubscription&&(this.childSubscription(),delete this.childSubscription);const{children:a}=this.props;he(a)&&(this.childSubscription=a.on("change",o=>{this.current&&(this.current.textContent=`${o}`)}))}}function av(n,{style:a,vars:o},l,c){const f=n.style;let d;for(d in a)f[d]=a[d];c?.applyProjectionStyles(f,l);for(d in o)f.setProperty(d,o[d])}function g8(n){return window.getComputedStyle(n)}class y8 extends iv{constructor(){super(...arguments),this.type="html",this.renderInstance=av}readValueFromInstance(a,o){if($a.has(o))return this.projection?.isProjecting?ed(o):LC(a,o);{const l=g8(a),c=(Nd(o)?l.getPropertyValue(o):l[o])||0;return typeof c=="string"?c.trim():c}}measureInstanceViewportBox(a,{transformPagePoint:o}){return ev(a,o)}build(a,o,l){nh(a,o,l.transformTemplate)}scrapeMotionValuesFromProps(a,o,l){return oh(a,o,l)}}const rv=new Set(["baseFrequency","diffuseConstant","kernelMatrix","kernelUnitLength","keySplines","keyTimes","limitingConeAngle","markerHeight","markerWidth","numOctaves","targetX","targetY","surfaceScale","specularConstant","specularExponent","stdDeviation","tableValues","viewBox","gradientTransform","pathLength","startOffset","textLength","lengthAdjust"]);function x8(n,a,o,l){av(n,a,void 0,l);for(const c in a.attrs)n.setAttribute(rv.has(c)?c:lh(c),a.attrs[c])}class v8 extends iv{constructor(){super(...arguments),this.type="svg",this.isSVGTag=!1,this.measureInstanceViewportBox=It}getBaseTargetFromProps(a,o){return a[o]}readValueFromInstance(a,o){if($a.has(o)){const l=Dx(o);return l&&l.default||0}return o=rv.has(o)?o:lh(o),a.getAttribute(o)}scrapeMotionValuesFromProps(a,o,l){return Kx(a,o,l)}build(a,o,l){qx(a,o,this.isSVGTag,l.transformTemplate,l.style)}renderInstance(a,o,l,c){x8(a,o,l,c)}mount(a){this.isSVGTag=Yx(a.tagName),super.mount(a)}}const b8=(n,a)=>ah(n)?new v8(a):new y8(a,{allowProjection:n!==E.Fragment});function xo(n,a,o){const l=n.getProps();return rh(l,a,o!==void 0?o:l.custom,n)}const ud=n=>Array.isArray(n);function S8(n,a,o){n.hasValue(a)?n.getValue(a).set(o):n.addValue(a,Ga(o))}function A8(n){return ud(n)?n[n.length-1]||0:n}function w8(n,a){const o=xo(n,a);let{transitionEnd:l={},transition:c={},...f}=o||{};f={...f,...l};for(const d in f){const g=A8(f[d]);S8(n,d,g)}}function C8(n){return!!(he(n)&&n.add)}function fd(n,a){const o=n.getValue("willChange");if(C8(o))return o.add(a);if(!o&&zn.WillChange){const l=new zn.WillChange("auto");n.addValue("willChange",l),l.add(a)}}function ov(n){return n.props[$x]}const T8=n=>n!==null;function E8(n,{repeat:a,repeatType:o="loop"},l){const c=n.filter(T8),f=a&&o!=="loop"&&a%2===1?0:c.length-1;return c[f]}const M8={type:"spring",stiffness:500,damping:25,restSpeed:10},j8=n=>({type:"spring",stiffness:550,damping:n===0?2*Math.sqrt(550):30,restSpeed:10}),O8={type:"keyframes",duration:.8},D8={type:"keyframes",ease:[.25,.1,.35,1],duration:.3},R8=(n,{keyframes:a})=>a.length>2?O8:$a.has(n)?n.startsWith("scale")?j8(a[1]):M8:D8;function L8({when:n,delay:a,delayChildren:o,staggerChildren:l,staggerDirection:c,repeat:f,repeatType:d,repeatDelay:g,from:p,elapsed:m,...x}){return!!Object.keys(x).length}const sh=(n,a,o,l={},c,f)=>d=>{const g=$d(l,n)||{},p=g.delay||l.delay||0;let{elapsed:m=0}=l;m=m-sn(p);const x={keyframes:Array.isArray(o)?o:[null,o],ease:"easeOut",velocity:a.getVelocity(),...g,delay:-m,onUpdate:b=>{a.set(b),g.onUpdate&&g.onUpdate(b)},onComplete:()=>{d(),g.onComplete&&g.onComplete()},name:n,motionValue:a,element:f?void 0:c};L8(g)||Object.assign(x,R8(n,x)),x.duration&&(x.duration=sn(x.duration)),x.repeatDelay&&(x.repeatDelay=sn(x.repeatDelay)),x.from!==void 0&&(x.keyframes[0]=x.from);let A=!1;if((x.type===!1||x.duration===0&&!x.repeatDelay)&&(x.duration=0,x.delay===0&&(A=!0)),(zn.instantAnimations||zn.skipAnimations)&&(A=!0,x.duration=0,x.delay=0),x.allowFlatten=!g.type&&!g.ease,A&&!f&&a.get()!==void 0){const b=E8(x.keyframes,g);if(b!==void 0){Lt.update(()=>{x.onUpdate(b),x.onComplete()});return}}return g.isSync?new Xd(x):new eT(x)};function B8({protectedKeys:n,needsAnimating:a},o){const l=n.hasOwnProperty(o)&&a[o]!==!0;return a[o]=!1,l}function lv(n,a,{delay:o=0,transitionOverride:l,type:c}={}){let{transition:f=n.getDefaultTransition(),transitionEnd:d,...g}=a;l&&(f=l);const p=[],m=c&&n.animationState&&n.animationState.getState()[c];for(const x in g){const A=n.getValue(x,n.latestValues[x]??null),b=g[x];if(b===void 0||m&&B8(m,x))continue;const C={delay:o,...$d(f||{},x)},O=A.get();if(O!==void 0&&!A.isAnimating&&!Array.isArray(b)&&b===O&&!C.velocity)continue;let z=!1;if(window.MotionHandoffAnimation){const R=ov(n);if(R){const H=window.MotionHandoffAnimation(R,x,Lt);H!==null&&(C.startTime=H,z=!0)}}fd(n,x),A.start(sh(x,A,b,n.shouldReduceMotion&&Mx.has(x)?{type:!1}:C,n,z));const P=A.animation;P&&p.push(P)}return d&&Promise.all(p).then(()=>{Lt.update(()=>{d&&w8(n,d)})}),p}function dd(n,a,o={}){const l=xo(n,a,o.type==="exit"?n.presenceContext?.custom:void 0);let{transition:c=n.getDefaultTransition()||{}}=l||{};o.transitionOverride&&(c=o.transitionOverride);const f=l?()=>Promise.all(lv(n,l,o)):()=>Promise.resolve(),d=n.variantChildren&&n.variantChildren.size?(p=0)=>{const{delayChildren:m=0,staggerChildren:x,staggerDirection:A}=c;return z8(n,a,p,m,x,A,o)}:()=>Promise.resolve(),{when:g}=c;if(g){const[p,m]=g==="beforeChildren"?[f,d]:[d,f];return p().then(()=>m())}else return Promise.all([f(),d(o.delay)])}function z8(n,a,o=0,l=0,c=0,f=1,d){const g=[],p=n.variantChildren.size,m=(p-1)*c,x=typeof l=="function",A=x?b=>l(b,p):f===1?(b=0)=>b*c:(b=0)=>m-b*c;return Array.from(n.variantChildren).sort(k8).forEach((b,C)=>{b.notify("AnimationStart",a),g.push(dd(b,a,{...d,delay:o+(x?0:l)+A(C)}).then(()=>b.notify("AnimationComplete",a)))}),Promise.all(g)}function k8(n,a){return n.sortNodePosition(a)}function P8(n,a,o={}){n.notify("AnimationStart",a);let l;if(Array.isArray(a)){const c=a.map(f=>dd(n,f,o));l=Promise.all(c)}else if(typeof a=="string")l=dd(n,a,o);else{const c=typeof a=="function"?xo(n,a,o.custom):a;l=Promise.all(lv(n,c,o))}return l.then(()=>{n.notify("AnimationComplete",a)})}function sv(n,a){if(!Array.isArray(a))return!1;const o=a.length;if(o!==n.length)return!1;for(let l=0;l<o;l++)if(a[l]!==n[l])return!1;return!0}const V8=eh.length;function cv(n){if(!n)return;if(!n.isControllingVariants){const o=n.parent?cv(n.parent)||{}:{};return n.props.initial!==void 0&&(o.initial=n.props.initial),o}const a={};for(let o=0;o<V8;o++){const l=eh[o],c=n.props[l];(go(c)||c===!1)&&(a[l]=c)}return a}const U8=[...th].reverse(),N8=th.length;function _8(n){return a=>Promise.all(a.map(({animation:o,options:l})=>P8(n,o,l)))}function H8(n){let a=_8(n),o=cy(),l=!0;const c=p=>(m,x)=>{const A=xo(n,x,p==="exit"?n.presenceContext?.custom:void 0);if(A){const{transition:b,transitionEnd:C,...O}=A;m={...m,...O,...C}}return m};function f(p){a=p(n)}function d(p){const{props:m}=n,x=cv(n.parent)||{},A=[],b=new Set;let C={},O=1/0;for(let P=0;P<N8;P++){const R=U8[P],H=o[R],V=m[R]!==void 0?m[R]:x[R],X=go(V),G=R===p?H.isActive:null;G===!1&&(O=P);let K=V===x[R]&&V!==m[R]&&X;if(K&&l&&n.manuallyAnimateOnMount&&(K=!1),H.protectedKeys={...C},!H.isActive&&G===null||!V&&!H.prevProp||zs(V)||typeof V=="boolean")continue;const F=G8(H.prevProp,V);let Z=F||R===p&&H.isActive&&!K&&X||P>O&&X,lt=!1;const vt=Array.isArray(V)?V:[V];let Bt=vt.reduce(c(R),{});G===!1&&(Bt={});const{prevResolvedValues:_t={}}=H,Xe={..._t,...Bt},Le=Y=>{Z=!0,b.has(Y)&&(lt=!0,b.delete(Y)),H.needsAnimating[Y]=!0;const W=n.getValue(Y);W&&(W.liveStyle=!1)};for(const Y in Xe){const W=Bt[Y],st=_t[Y];if(C.hasOwnProperty(Y))continue;let T=!1;ud(W)&&ud(st)?T=!sv(W,st):T=W!==st,T?W!=null?Le(Y):b.add(Y):W!==void 0&&b.has(Y)?Le(Y):H.protectedKeys[Y]=!0}H.prevProp=V,H.prevResolvedValues=Bt,H.isActive&&(C={...C,...Bt}),l&&n.blockInitialAnimation&&(Z=!1),Z&&(!(K&&F)||lt)&&A.push(...vt.map(Y=>({animation:Y,options:{type:R}})))}if(b.size){const P={};if(typeof m.initial!="boolean"){const R=xo(n,Array.isArray(m.initial)?m.initial[0]:m.initial);R&&R.transition&&(P.transition=R.transition)}b.forEach(R=>{const H=n.getBaseTarget(R),V=n.getValue(R);V&&(V.liveStyle=!0),P[R]=H??null}),A.push({animation:P})}let z=!!A.length;return l&&(m.initial===!1||m.initial===m.animate)&&!n.manuallyAnimateOnMount&&(z=!1),l=!1,z?a(A):Promise.resolve()}function g(p,m){if(o[p].isActive===m)return Promise.resolve();n.variantChildren?.forEach(A=>A.animationState?.setActive(p,m)),o[p].isActive=m;const x=d(p);for(const A in o)o[A].protectedKeys={};return x}return{animateChanges:d,setActive:g,setAnimateFunction:f,getState:()=>o,reset:()=>{o=cy(),l=!0}}}function G8(n,a){return typeof a=="string"?a!==n:Array.isArray(a)?!sv(a,n):!1}function Ri(n=!1){return{isActive:n,protectedKeys:{},needsAnimating:{},prevResolvedValues:{}}}function cy(){return{animate:Ri(!0),whileInView:Ri(),whileHover:Ri(),whileTap:Ri(),whileDrag:Ri(),whileFocus:Ri(),exit:Ri()}}class fi{constructor(a){this.isMounted=!1,this.node=a}update(){}}class I8 extends fi{constructor(a){super(a),a.animationState||(a.animationState=H8(a))}updateAnimationControlsSubscription(){const{animate:a}=this.node.getProps();zs(a)&&(this.unmountControls=a.subscribe(this.node))}mount(){this.updateAnimationControlsSubscription()}update(){const{animate:a}=this.node.getProps(),{animate:o}=this.node.prevProps||{};a!==o&&this.updateAnimationControlsSubscription()}unmount(){this.node.animationState.reset(),this.unmountControls?.()}}let q8=0;class F8 extends fi{constructor(){super(...arguments),this.id=q8++}update(){if(!this.node.presenceContext)return;const{isPresent:a,onExitComplete:o}=this.node.presenceContext,{isPresent:l}=this.node.prevPresenceContext||{};if(!this.node.animationState||a===l)return;const c=this.node.animationState.setActive("exit",!a);o&&!a&&c.then(()=>{o(this.id)})}mount(){const{register:a,onExitComplete:o}=this.node.presenceContext||{};o&&o(this.id),a&&(this.unmount=a(this.id))}unmount(){}}const Y8={animation:{Feature:I8},exit:{Feature:F8}};function vo(n,a,o,l={passive:!0}){return n.addEventListener(a,o,l),()=>n.removeEventListener(a,o)}function Eo(n){return{point:{x:n.pageX,y:n.pageY}}}const X8=n=>a=>Jd(a)&&n(a,Eo(a));function ro(n,a,o,l){return vo(n,a,X8(o),l)}const uv=1e-4,K8=1-uv,$8=1+uv,fv=.01,Q8=0-fv,Z8=0+fv;function pe(n){return n.max-n.min}function J8(n,a,o){return Math.abs(n-a)<=o}function uy(n,a,o,l=.5){n.origin=l,n.originPoint=kt(a.min,a.max,n.origin),n.scale=pe(o)/pe(a),n.translate=kt(o.min,o.max,n.origin)-n.originPoint,(n.scale>=K8&&n.scale<=$8||isNaN(n.scale))&&(n.scale=1),(n.translate>=Q8&&n.translate<=Z8||isNaN(n.translate))&&(n.translate=0)}function oo(n,a,o,l){uy(n.x,a.x,o.x,l?l.originX:void 0),uy(n.y,a.y,o.y,l?l.originY:void 0)}function fy(n,a,o){n.min=o.min+a.min,n.max=n.min+pe(a)}function W8(n,a,o){fy(n.x,a.x,o.x),fy(n.y,a.y,o.y)}function dy(n,a,o){n.min=a.min-o.min,n.max=n.min+pe(a)}function lo(n,a,o){dy(n.x,a.x,o.x),dy(n.y,a.y,o.y)}function qe(n){return[n("x"),n("y")]}const dv=({current:n})=>n?n.ownerDocument.defaultView:null,hy=(n,a)=>Math.abs(n-a);function tE(n,a){const o=hy(n.x,a.x),l=hy(n.y,a.y);return Math.sqrt(o**2+l**2)}class hv{constructor(a,o,{transformPagePoint:l,contextWindow:c=window,dragSnapToOrigin:f=!1,distanceThreshold:d=3}={}){if(this.startEvent=null,this.lastMoveEvent=null,this.lastMoveEventInfo=null,this.handlers={},this.contextWindow=window,this.updatePoint=()=>{if(!(this.lastMoveEvent&&this.lastMoveEventInfo))return;const b=xf(this.lastMoveEventInfo,this.history),C=this.startEvent!==null,O=tE(b.offset,{x:0,y:0})>=this.distanceThreshold;if(!C&&!O)return;const{point:z}=b,{timestamp:P}=se;this.history.push({...z,timestamp:P});const{onStart:R,onMove:H}=this.handlers;C||(R&&R(this.lastMoveEvent,b),this.startEvent=this.lastMoveEvent),H&&H(this.lastMoveEvent,b)},this.handlePointerMove=(b,C)=>{this.lastMoveEvent=b,this.lastMoveEventInfo=yf(C,this.transformPagePoint),Lt.update(this.updatePoint,!0)},this.handlePointerUp=(b,C)=>{this.end();const{onEnd:O,onSessionEnd:z,resumeAnimation:P}=this.handlers;if(this.dragSnapToOrigin&&P&&P(),!(this.lastMoveEvent&&this.lastMoveEventInfo))return;const R=xf(b.type==="pointercancel"?this.lastMoveEventInfo:yf(C,this.transformPagePoint),this.history);this.startEvent&&O&&O(b,R),z&&z(b,R)},!Jd(a))return;this.dragSnapToOrigin=f,this.handlers=o,this.transformPagePoint=l,this.distanceThreshold=d,this.contextWindow=c||window;const g=Eo(a),p=yf(g,this.transformPagePoint),{point:m}=p,{timestamp:x}=se;this.history=[{...m,timestamp:x}];const{onSessionStart:A}=o;A&&A(a,xf(p,this.history)),this.removeListeners=wo(ro(this.contextWindow,"pointermove",this.handlePointerMove),ro(this.contextWindow,"pointerup",this.handlePointerUp),ro(this.contextWindow,"pointercancel",this.handlePointerUp))}updateHandlers(a){this.handlers=a}end(){this.removeListeners&&this.removeListeners(),si(this.updatePoint)}}function yf(n,a){return a?{point:a(n.point)}:n}function my(n,a){return{x:n.x-a.x,y:n.y-a.y}}function xf({point:n},a){return{point:n,delta:my(n,mv(a)),offset:my(n,eE(a)),velocity:nE(a,.1)}}function eE(n){return n[0]}function mv(n){return n[n.length-1]}function nE(n,a){if(n.length<2)return{x:0,y:0};let o=n.length-1,l=null;const c=mv(n);for(;o>=0&&(l=n[o],!(c.timestamp-l.timestamp>sn(a)));)o--;if(!l)return{x:0,y:0};const f=cn(c.timestamp-l.timestamp);if(f===0)return{x:0,y:0};const d={x:(c.x-l.x)/f,y:(c.y-l.y)/f};return d.x===1/0&&(d.x=0),d.y===1/0&&(d.y=0),d}function iE(n,{min:a,max:o},l){return a!==void 0&&n<a?n=l?kt(a,n,l.min):Math.max(n,a):o!==void 0&&n>o&&(n=l?kt(o,n,l.max):Math.min(n,o)),n}function py(n,a,o){return{min:a!==void 0?n.min+a:void 0,max:o!==void 0?n.max+o-(n.max-n.min):void 0}}function aE(n,{top:a,left:o,bottom:l,right:c}){return{x:py(n.x,o,c),y:py(n.y,a,l)}}function gy(n,a){let o=a.min-n.min,l=a.max-n.max;return a.max-a.min<n.max-n.min&&([o,l]=[l,o]),{min:o,max:l}}function rE(n,a){return{x:gy(n.x,a.x),y:gy(n.y,a.y)}}function oE(n,a){let o=.5;const l=pe(n),c=pe(a);return c>l?o=fo(a.min,a.max-l,n.min):l>c&&(o=fo(n.min,n.max-c,a.min)),Bn(0,1,o)}function lE(n,a){const o={};return a.min!==void 0&&(o.min=a.min-n.min),a.max!==void 0&&(o.max=a.max-n.min),o}const hd=.35;function sE(n=hd){return n===!1?n=0:n===!0&&(n=hd),{x:yy(n,"left","right"),y:yy(n,"top","bottom")}}function yy(n,a,o){return{min:xy(n,a),max:xy(n,o)}}function xy(n,a){return typeof n=="number"?n:n[a]||0}const cE=new WeakMap;class uE{constructor(a){this.openDragLock=null,this.isDragging=!1,this.currentDirection=null,this.originPoint={x:0,y:0},this.constraints=!1,this.hasMutatedConstraints=!1,this.elastic=It(),this.latestPointerEvent=null,this.latestPanInfo=null,this.visualElement=a}start(a,{snapToCursor:o=!1,distanceThreshold:l}={}){const{presenceContext:c}=this.visualElement;if(c&&c.isPresent===!1)return;const f=A=>{const{dragSnapToOrigin:b}=this.getProps();b?this.pauseAnimation():this.stopAnimation(),o&&this.snapToCursor(Eo(A).point)},d=(A,b)=>{const{drag:C,dragPropagation:O,onDragStart:z}=this.getProps();if(C&&!O&&(this.openDragLock&&this.openDragLock(),this.openDragLock=yT(C),!this.openDragLock))return;this.latestPointerEvent=A,this.latestPanInfo=b,this.isDragging=!0,this.currentDirection=null,this.resolveConstraints(),this.visualElement.projection&&(this.visualElement.projection.isAnimationBlocked=!0,this.visualElement.projection.target=void 0),qe(R=>{let H=this.getAxisMotionValue(R).get()||0;if(un.test(H)){const{projection:V}=this.visualElement;if(V&&V.layout){const X=V.layout.layoutBox[R];X&&(H=pe(X)*(parseFloat(H)/100))}}this.originPoint[R]=H}),z&&Lt.postRender(()=>z(A,b)),fd(this.visualElement,"transform");const{animationState:P}=this.visualElement;P&&P.setActive("whileDrag",!0)},g=(A,b)=>{this.latestPointerEvent=A,this.latestPanInfo=b;const{dragPropagation:C,dragDirectionLock:O,onDirectionLock:z,onDrag:P}=this.getProps();if(!C&&!this.openDragLock)return;const{offset:R}=b;if(O&&this.currentDirection===null){this.currentDirection=fE(R),this.currentDirection!==null&&z&&z(this.currentDirection);return}this.updateAxis("x",b.point,R),this.updateAxis("y",b.point,R),this.visualElement.render(),P&&P(A,b)},p=(A,b)=>{this.latestPointerEvent=A,this.latestPanInfo=b,this.stop(A,b),this.latestPointerEvent=null,this.latestPanInfo=null},m=()=>qe(A=>this.getAnimationState(A)==="paused"&&this.getAxisMotionValue(A).animation?.play()),{dragSnapToOrigin:x}=this.getProps();this.panSession=new hv(a,{onSessionStart:f,onStart:d,onMove:g,onSessionEnd:p,resumeAnimation:m},{transformPagePoint:this.visualElement.getTransformPagePoint(),dragSnapToOrigin:x,distanceThreshold:l,contextWindow:dv(this.visualElement)})}stop(a,o){const l=a||this.latestPointerEvent,c=o||this.latestPanInfo,f=this.isDragging;if(this.cancel(),!f||!c||!l)return;const{velocity:d}=c;this.startAnimation(d);const{onDragEnd:g}=this.getProps();g&&Lt.postRender(()=>g(l,c))}cancel(){this.isDragging=!1;const{projection:a,animationState:o}=this.visualElement;a&&(a.isAnimationBlocked=!1),this.panSession&&this.panSession.end(),this.panSession=void 0;const{dragPropagation:l}=this.getProps();!l&&this.openDragLock&&(this.openDragLock(),this.openDragLock=null),o&&o.setActive("whileDrag",!1)}updateAxis(a,o,l){const{drag:c}=this.getProps();if(!l||!Xl(a,c,this.currentDirection))return;const f=this.getAxisMotionValue(a);let d=this.originPoint[a]+l[a];this.constraints&&this.constraints[a]&&(d=iE(d,this.constraints[a],this.elastic[a])),f.set(d)}resolveConstraints(){const{dragConstraints:a,dragElastic:o}=this.getProps(),l=this.visualElement.projection&&!this.visualElement.projection.layout?this.visualElement.projection.measure(!1):this.visualElement.projection?.layout,c=this.constraints;a&&Ba(a)?this.constraints||(this.constraints=this.resolveRefConstraints()):a&&l?this.constraints=aE(l.layoutBox,a):this.constraints=!1,this.elastic=sE(o),c!==this.constraints&&l&&this.constraints&&!this.hasMutatedConstraints&&qe(f=>{this.constraints!==!1&&this.getAxisMotionValue(f)&&(this.constraints[f]=lE(l.layoutBox[f],this.constraints[f]))})}resolveRefConstraints(){const{dragConstraints:a,onMeasureDragConstraints:o}=this.getProps();if(!a||!Ba(a))return!1;const l=a.current,{projection:c}=this.visualElement;if(!c||!c.layout)return!1;const f=f8(l,c.root,this.visualElement.getTransformPagePoint());let d=rE(c.layout.layoutBox,f);if(o){const g=o(s8(d));this.hasMutatedConstraints=!!g,g&&(d=Jx(g))}return d}startAnimation(a){const{drag:o,dragMomentum:l,dragElastic:c,dragTransition:f,dragSnapToOrigin:d,onDragTransitionEnd:g}=this.getProps(),p=this.constraints||{},m=qe(x=>{if(!Xl(x,o,this.currentDirection))return;let A=p&&p[x]||{};d&&(A={min:0,max:0});const b=c?200:1e6,C=c?40:1e7,O={type:"inertia",velocity:l?a[x]:0,bounceStiffness:b,bounceDamping:C,timeConstant:750,restDelta:1,restSpeed:10,...f,...A};return this.startAxisValueAnimation(x,O)});return Promise.all(m).then(g)}startAxisValueAnimation(a,o){const l=this.getAxisMotionValue(a);return fd(this.visualElement,a),l.start(sh(a,l,0,o,this.visualElement,!1))}stopAnimation(){qe(a=>this.getAxisMotionValue(a).stop())}pauseAnimation(){qe(a=>this.getAxisMotionValue(a).animation?.pause())}getAnimationState(a){return this.getAxisMotionValue(a).animation?.state}getAxisMotionValue(a){const o=`_drag${a.toUpperCase()}`,l=this.visualElement.getProps(),c=l[o];return c||this.visualElement.getValue(a,(l.initial?l.initial[a]:void 0)||0)}snapToCursor(a){qe(o=>{const{drag:l}=this.getProps();if(!Xl(o,l,this.currentDirection))return;const{projection:c}=this.visualElement,f=this.getAxisMotionValue(o);if(c&&c.layout){const{min:d,max:g}=c.layout.layoutBox[o];f.set(a[o]-kt(d,g,.5))}})}scalePositionWithinConstraints(){if(!this.visualElement.current)return;const{drag:a,dragConstraints:o}=this.getProps(),{projection:l}=this.visualElement;if(!Ba(o)||!l||!this.constraints)return;this.stopAnimation();const c={x:0,y:0};qe(d=>{const g=this.getAxisMotionValue(d);if(g&&this.constraints!==!1){const p=g.get();c[d]=oE({min:p,max:p},this.constraints[d])}});const{transformTemplate:f}=this.visualElement.getProps();this.visualElement.current.style.transform=f?f({},""):"none",l.root&&l.root.updateScroll(),l.updateLayout(),this.resolveConstraints(),qe(d=>{if(!Xl(d,a,null))return;const g=this.getAxisMotionValue(d),{min:p,max:m}=this.constraints[d];g.set(kt(p,m,c[d]))})}addListeners(){if(!this.visualElement.current)return;cE.set(this.visualElement,this);const a=this.visualElement.current,o=ro(a,"pointerdown",p=>{const{drag:m,dragListener:x=!0}=this.getProps();m&&x&&this.start(p)}),l=()=>{const{dragConstraints:p}=this.getProps();Ba(p)&&p.current&&(this.constraints=this.resolveRefConstraints())},{projection:c}=this.visualElement,f=c.addEventListener("measure",l);c&&!c.layout&&(c.root&&c.root.updateScroll(),c.updateLayout()),Lt.read(l);const d=vo(window,"resize",()=>this.scalePositionWithinConstraints()),g=c.addEventListener("didUpdate",({delta:p,hasLayoutChanged:m})=>{this.isDragging&&m&&(qe(x=>{const A=this.getAxisMotionValue(x);A&&(this.originPoint[x]+=p[x].translate,A.set(A.get()+p[x].translate))}),this.visualElement.render())});return()=>{d(),o(),f(),g&&g()}}getProps(){const a=this.visualElement.getProps(),{drag:o=!1,dragDirectionLock:l=!1,dragPropagation:c=!1,dragConstraints:f=!1,dragElastic:d=hd,dragMomentum:g=!0}=a;return{...a,drag:o,dragDirectionLock:l,dragPropagation:c,dragConstraints:f,dragElastic:d,dragMomentum:g}}}function Xl(n,a,o){return(a===!0||a===n)&&(o===null||o===n)}function fE(n,a=10){let o=null;return Math.abs(n.y)>a?o="y":Math.abs(n.x)>a&&(o="x"),o}class dE extends fi{constructor(a){super(a),this.removeGroupControls=Fe,this.removeListeners=Fe,this.controls=new uE(a)}mount(){const{dragControls:a}=this.node.getProps();a&&(this.removeGroupControls=a.subscribe(this.controls)),this.removeListeners=this.controls.addListeners()||Fe}unmount(){this.removeGroupControls(),this.removeListeners()}}const vy=n=>(a,o)=>{n&&Lt.postRender(()=>n(a,o))};class hE extends fi{constructor(){super(...arguments),this.removePointerDownListener=Fe}onPointerDown(a){this.session=new hv(a,this.createPanHandlers(),{transformPagePoint:this.node.getTransformPagePoint(),contextWindow:dv(this.node)})}createPanHandlers(){const{onPanSessionStart:a,onPanStart:o,onPan:l,onPanEnd:c}=this.node.getProps();return{onSessionStart:vy(a),onStart:vy(o),onMove:l,onEnd:(f,d)=>{delete this.session,c&&Lt.postRender(()=>c(f,d))}}}mount(){this.removePointerDownListener=ro(this.node.current,"pointerdown",a=>this.onPointerDown(a))}update(){this.session&&this.session.updateHandlers(this.createPanHandlers())}unmount(){this.removePointerDownListener(),this.session&&this.session.end()}}const us={hasAnimatedSinceResize:!0,hasEverUpdated:!1};function by(n,a){return a.max===a.min?0:n/(a.max-a.min)*100}const Zr={correct:(n,a)=>{if(!a.target)return n;if(typeof n=="string")if(ot.test(n))n=parseFloat(n);else return n;const o=by(n,a.target.x),l=by(n,a.target.y);return`${o}% ${l}%`}},mE={correct:(n,{treeScale:a,projectionDelta:o})=>{const l=n,c=ci.parse(n);if(c.length>5)return l;const f=ci.createTransformer(n),d=typeof c[0]!="number"?1:0,g=o.x.scale*a.x,p=o.y.scale*a.y;c[0+d]/=g,c[1+d]/=p;const m=kt(g,p,.5);return typeof c[2+d]=="number"&&(c[2+d]/=m),typeof c[3+d]=="number"&&(c[3+d]/=m),f(c)}};let Sy=!1;class pE extends E.Component{componentDidMount(){const{visualElement:a,layoutGroup:o,switchLayoutGroup:l,layoutId:c}=this.props,{projection:f}=a;PT(gE),f&&(o.group&&o.group.add(f),l&&l.register&&c&&l.register(f),Sy&&f.root.didUpdate(),f.addEventListener("animationComplete",()=>{this.safeToRemove()}),f.setOptions({...f.options,onExitComplete:()=>this.safeToRemove()})),us.hasEverUpdated=!0}getSnapshotBeforeUpdate(a){const{layoutDependency:o,visualElement:l,drag:c,isPresent:f}=this.props,{projection:d}=l;return d&&(d.isPresent=f,Sy=!0,c||a.layoutDependency!==o||o===void 0||a.isPresent!==f?d.willUpdate():this.safeToRemove(),a.isPresent!==f&&(f?d.promote():d.relegate()||Lt.postRender(()=>{const g=d.getStack();(!g||!g.members.length)&&this.safeToRemove()}))),null}componentDidUpdate(){const{projection:a}=this.props.visualElement;a&&(a.root.didUpdate(),Zd.postRender(()=>{!a.currentAnimation&&a.isLead()&&this.safeToRemove()}))}componentWillUnmount(){const{visualElement:a,layoutGroup:o,switchLayoutGroup:l}=this.props,{projection:c}=a;c&&(c.scheduleCheckAfterUnmount(),o&&o.group&&o.group.remove(c),l&&l.deregister&&l.deregister(c))}safeToRemove(){const{safeToRemove:a}=this.props;a&&a()}render(){return null}}function pv(n){const[a,o]=Ux(),l=E.useContext(Od);return h.jsx(pE,{...n,layoutGroup:l,switchLayoutGroup:E.useContext(Qx),isPresent:a,safeToRemove:o})}const gE={borderRadius:{...Zr,applyTo:["borderTopLeftRadius","borderTopRightRadius","borderBottomLeftRadius","borderBottomRightRadius"]},borderTopLeftRadius:Zr,borderTopRightRadius:Zr,borderBottomLeftRadius:Zr,borderBottomRightRadius:Zr,boxShadow:mE};function yE(n,a,o){const l=he(n)?n:Ga(n);return l.start(sh("",l,a,o)),l.animation}const xE=(n,a)=>n.depth-a.depth;class vE{constructor(){this.children=[],this.isDirty=!1}add(a){Ld(this.children,a),this.isDirty=!0}remove(a){Bd(this.children,a),this.isDirty=!0}forEach(a){this.isDirty&&this.children.sort(xE),this.isDirty=!1,this.children.forEach(a)}}function bE(n,a){const o=Se.now(),l=({timestamp:c})=>{const f=c-o;f>=a&&(si(l),n(f-a))};return Lt.setup(l,!0),()=>si(l)}const gv=["TopLeft","TopRight","BottomLeft","BottomRight"],SE=gv.length,Ay=n=>typeof n=="string"?parseFloat(n):n,wy=n=>typeof n=="number"||ot.test(n);function AE(n,a,o,l,c,f){c?(n.opacity=kt(0,o.opacity??1,wE(l)),n.opacityExit=kt(a.opacity??1,0,CE(l))):f&&(n.opacity=kt(a.opacity??1,o.opacity??1,l));for(let d=0;d<SE;d++){const g=`border${gv[d]}Radius`;let p=Cy(a,g),m=Cy(o,g);if(p===void 0&&m===void 0)continue;p||(p=0),m||(m=0),p===0||m===0||wy(p)===wy(m)?(n[g]=Math.max(kt(Ay(p),Ay(m),l),0),(un.test(m)||un.test(p))&&(n[g]+="%")):n[g]=m}(a.rotate||o.rotate)&&(n.rotate=kt(a.rotate||0,o.rotate||0,l))}function Cy(n,a){return n[a]!==void 0?n[a]:n.borderRadius}const wE=yv(0,.5,ax),CE=yv(.5,.95,Fe);function yv(n,a,o){return l=>l<n?0:l>a?1:o(fo(n,a,l))}function Ty(n,a){n.min=a.min,n.max=a.max}function Ie(n,a){Ty(n.x,a.x),Ty(n.y,a.y)}function Ey(n,a){n.translate=a.translate,n.scale=a.scale,n.originPoint=a.originPoint,n.origin=a.origin}function My(n,a,o,l,c){return n-=a,n=Ss(n,1/o,l),c!==void 0&&(n=Ss(n,1/c,l)),n}function TE(n,a=0,o=1,l=.5,c,f=n,d=n){if(un.test(a)&&(a=parseFloat(a),a=kt(d.min,d.max,a/100)-d.min),typeof a!="number")return;let g=kt(f.min,f.max,l);n===f&&(g-=a),n.min=My(n.min,a,o,g,c),n.max=My(n.max,a,o,g,c)}function jy(n,a,[o,l,c],f,d){TE(n,a[o],a[l],a[c],a.scale,f,d)}const EE=["x","scaleX","originX"],ME=["y","scaleY","originY"];function Oy(n,a,o,l){jy(n.x,a,EE,o?o.x:void 0,l?l.x:void 0),jy(n.y,a,ME,o?o.y:void 0,l?l.y:void 0)}function Dy(n){return n.translate===0&&n.scale===1}function xv(n){return Dy(n.x)&&Dy(n.y)}function Ry(n,a){return n.min===a.min&&n.max===a.max}function jE(n,a){return Ry(n.x,a.x)&&Ry(n.y,a.y)}function Ly(n,a){return Math.round(n.min)===Math.round(a.min)&&Math.round(n.max)===Math.round(a.max)}function vv(n,a){return Ly(n.x,a.x)&&Ly(n.y,a.y)}function By(n){return pe(n.x)/pe(n.y)}function zy(n,a){return n.translate===a.translate&&n.scale===a.scale&&n.originPoint===a.originPoint}class OE{constructor(){this.members=[]}add(a){Ld(this.members,a),a.scheduleRender()}remove(a){if(Bd(this.members,a),a===this.prevLead&&(this.prevLead=void 0),a===this.lead){const o=this.members[this.members.length-1];o&&this.promote(o)}}relegate(a){const o=this.members.findIndex(c=>a===c);if(o===0)return!1;let l;for(let c=o;c>=0;c--){const f=this.members[c];if(f.isPresent!==!1){l=f;break}}return l?(this.promote(l),!0):!1}promote(a,o){const l=this.lead;if(a!==l&&(this.prevLead=l,this.lead=a,a.show(),l)){l.instance&&l.scheduleRender(),a.scheduleRender(),a.resumeFrom=l,o&&(a.resumeFrom.preserveOpacity=!0),l.snapshot&&(a.snapshot=l.snapshot,a.snapshot.latestValues=l.animationValues||l.latestValues),a.root&&a.root.isUpdating&&(a.isLayoutDirty=!0);const{crossfade:c}=a.options;c===!1&&l.hide()}}exitAnimationComplete(){this.members.forEach(a=>{const{options:o,resumingFrom:l}=a;o.onExitComplete&&o.onExitComplete(),l&&l.options.onExitComplete&&l.options.onExitComplete()})}scheduleRender(){this.members.forEach(a=>{a.instance&&a.scheduleRender(!1)})}removeLeadSnapshot(){this.lead&&this.lead.snapshot&&(this.lead.snapshot=void 0)}}function DE(n,a,o){let l="";const c=n.x.translate/a.x,f=n.y.translate/a.y,d=o?.z||0;if((c||f||d)&&(l=`translate3d(${c}px, ${f}px, ${d}px) `),(a.x!==1||a.y!==1)&&(l+=`scale(${1/a.x}, ${1/a.y}) `),o){const{transformPerspective:m,rotate:x,rotateX:A,rotateY:b,skewX:C,skewY:O}=o;m&&(l=`perspective(${m}px) ${l}`),x&&(l+=`rotate(${x}deg) `),A&&(l+=`rotateX(${A}deg) `),b&&(l+=`rotateY(${b}deg) `),C&&(l+=`skewX(${C}deg) `),O&&(l+=`skewY(${O}deg) `)}const g=n.x.scale*a.x,p=n.y.scale*a.y;return(g!==1||p!==1)&&(l+=`scale(${g}, ${p})`),l||"none"}const vf=["","X","Y","Z"],RE=1e3;let LE=0;function bf(n,a,o,l){const{latestValues:c}=a;c[n]&&(o[n]=c[n],a.setStaticValue(n,0),l&&(l[n]=0))}function bv(n){if(n.hasCheckedOptimisedAppear=!0,n.root===n)return;const{visualElement:a}=n.options;if(!a)return;const o=ov(a);if(window.MotionHasOptimisedAnimation(o,"transform")){const{layout:c,layoutId:f}=n.options;window.MotionCancelOptimisedAnimation(o,"transform",Lt,!(c||f))}const{parent:l}=n;l&&!l.hasCheckedOptimisedAppear&&bv(l)}function Sv({attachResizeListener:n,defaultParent:a,measureScroll:o,checkIsScrollRoot:l,resetTransform:c}){return class{constructor(d={},g=a?.()){this.id=LE++,this.animationId=0,this.animationCommitId=0,this.children=new Set,this.options={},this.isTreeAnimating=!1,this.isAnimationBlocked=!1,this.isLayoutDirty=!1,this.isProjectionDirty=!1,this.isSharedProjectionDirty=!1,this.isTransformDirty=!1,this.updateManuallyBlocked=!1,this.updateBlockedByResize=!1,this.isUpdating=!1,this.isSVG=!1,this.needsReset=!1,this.shouldResetTransform=!1,this.hasCheckedOptimisedAppear=!1,this.treeScale={x:1,y:1},this.eventHandlers=new Map,this.hasTreeAnimated=!1,this.updateScheduled=!1,this.scheduleUpdate=()=>this.update(),this.projectionUpdateScheduled=!1,this.checkUpdateFailed=()=>{this.isUpdating&&(this.isUpdating=!1,this.clearAllSnapshots())},this.updateProjection=()=>{this.projectionUpdateScheduled=!1,this.nodes.forEach(kE),this.nodes.forEach(NE),this.nodes.forEach(_E),this.nodes.forEach(PE)},this.resolvedRelativeTargetAt=0,this.hasProjected=!1,this.isVisible=!0,this.animationProgress=0,this.sharedNodes=new Map,this.latestValues=d,this.root=g?g.root||g:this,this.path=g?[...g.path,g]:[],this.parent=g,this.depth=g?g.depth+1:0;for(let p=0;p<this.path.length;p++)this.path[p].shouldResetTransform=!0;this.root===this&&(this.nodes=new vE)}addEventListener(d,g){return this.eventHandlers.has(d)||this.eventHandlers.set(d,new Pd),this.eventHandlers.get(d).add(g)}notifyListeners(d,...g){const p=this.eventHandlers.get(d);p&&p.notify(...g)}hasListeners(d){return this.eventHandlers.has(d)}mount(d){if(this.instance)return;this.isSVG=Vx(d)&&!wT(d),this.instance=d;const{layoutId:g,layout:p,visualElement:m}=this.options;if(m&&!m.current&&m.mount(d),this.root.nodes.add(this),this.parent&&this.parent.children.add(this),this.root.hasTreeAnimated&&(p||g)&&(this.isLayoutDirty=!0),n){let x,A=0;const b=()=>this.root.updateBlockedByResize=!1;Lt.read(()=>{A=window.innerWidth}),n(d,()=>{const C=window.innerWidth;C!==A&&(A=C,this.root.updateBlockedByResize=!0,x&&x(),x=bE(b,250),us.hasAnimatedSinceResize&&(us.hasAnimatedSinceResize=!1,this.nodes.forEach(Vy)))})}g&&this.root.registerSharedNode(g,this),this.options.animate!==!1&&m&&(g||p)&&this.addEventListener("didUpdate",({delta:x,hasLayoutChanged:A,hasRelativeLayoutChanged:b,layout:C})=>{if(this.isTreeAnimationBlocked()){this.target=void 0,this.relativeTarget=void 0;return}const O=this.options.transition||m.getDefaultTransition()||FE,{onLayoutAnimationStart:z,onLayoutAnimationComplete:P}=m.getProps(),R=!this.targetLayout||!vv(this.targetLayout,C),H=!A&&b;if(this.options.layoutRoot||this.resumeFrom||H||A&&(R||!this.currentAnimation)){this.resumeFrom&&(this.resumingFrom=this.resumeFrom,this.resumingFrom.resumingFrom=void 0);const V={...$d(O,"layout"),onPlay:z,onComplete:P};(m.shouldReduceMotion||this.options.layoutRoot)&&(V.delay=0,V.type=!1),this.startAnimation(V),this.setAnimationOrigin(x,H)}else A||Vy(this),this.isLead()&&this.options.onExitComplete&&this.options.onExitComplete();this.targetLayout=C})}unmount(){this.options.layoutId&&this.willUpdate(),this.root.nodes.remove(this);const d=this.getStack();d&&d.remove(this),this.parent&&this.parent.children.delete(this),this.instance=void 0,this.eventHandlers.clear(),si(this.updateProjection)}blockUpdate(){this.updateManuallyBlocked=!0}unblockUpdate(){this.updateManuallyBlocked=!1}isUpdateBlocked(){return this.updateManuallyBlocked||this.updateBlockedByResize}isTreeAnimationBlocked(){return this.isAnimationBlocked||this.parent&&this.parent.isTreeAnimationBlocked()||!1}startUpdate(){this.isUpdateBlocked()||(this.isUpdating=!0,this.nodes&&this.nodes.forEach(HE),this.animationId++)}getTransformTemplate(){const{visualElement:d}=this.options;return d&&d.getProps().transformTemplate}willUpdate(d=!0){if(this.root.hasTreeAnimated=!0,this.root.isUpdateBlocked()){this.options.onExitComplete&&this.options.onExitComplete();return}if(window.MotionCancelOptimisedAnimation&&!this.hasCheckedOptimisedAppear&&bv(this),!this.root.isUpdating&&this.root.startUpdate(),this.isLayoutDirty)return;this.isLayoutDirty=!0;for(let x=0;x<this.path.length;x++){const A=this.path[x];A.shouldResetTransform=!0,A.updateScroll("snapshot"),A.options.layoutRoot&&A.willUpdate(!1)}const{layoutId:g,layout:p}=this.options;if(g===void 0&&!p)return;const m=this.getTransformTemplate();this.prevTransformTemplateValue=m?m(this.latestValues,""):void 0,this.updateSnapshot(),d&&this.notifyListeners("willUpdate")}update(){if(this.updateScheduled=!1,this.isUpdateBlocked()){this.unblockUpdate(),this.clearAllSnapshots(),this.nodes.forEach(ky);return}if(this.animationId<=this.animationCommitId){this.nodes.forEach(Py);return}this.animationCommitId=this.animationId,this.isUpdating?(this.isUpdating=!1,this.nodes.forEach(UE),this.nodes.forEach(BE),this.nodes.forEach(zE)):this.nodes.forEach(Py),this.clearAllSnapshots();const g=Se.now();se.delta=Bn(0,1e3/60,g-se.timestamp),se.timestamp=g,se.isProcessing=!0,cf.update.process(se),cf.preRender.process(se),cf.render.process(se),se.isProcessing=!1}didUpdate(){this.updateScheduled||(this.updateScheduled=!0,Zd.read(this.scheduleUpdate))}clearAllSnapshots(){this.nodes.forEach(VE),this.sharedNodes.forEach(GE)}scheduleUpdateProjection(){this.projectionUpdateScheduled||(this.projectionUpdateScheduled=!0,Lt.preRender(this.updateProjection,!1,!0))}scheduleCheckAfterUnmount(){Lt.postRender(()=>{this.isLayoutDirty?this.root.didUpdate():this.root.checkUpdateFailed()})}updateSnapshot(){this.snapshot||!this.instance||(this.snapshot=this.measure(),this.snapshot&&!pe(this.snapshot.measuredBox.x)&&!pe(this.snapshot.measuredBox.y)&&(this.snapshot=void 0))}updateLayout(){if(!this.instance||(this.updateScroll(),!(this.options.alwaysMeasureLayout&&this.isLead())&&!this.isLayoutDirty))return;if(this.resumeFrom&&!this.resumeFrom.instance)for(let p=0;p<this.path.length;p++)this.path[p].updateScroll();const d=this.layout;this.layout=this.measure(!1),this.layoutCorrected=It(),this.isLayoutDirty=!1,this.projectionDelta=void 0,this.notifyListeners("measure",this.layout.layoutBox);const{visualElement:g}=this.options;g&&g.notify("LayoutMeasure",this.layout.layoutBox,d?d.layoutBox:void 0)}updateScroll(d="measure"){let g=!!(this.options.layoutScroll&&this.instance);if(this.scroll&&this.scroll.animationId===this.root.animationId&&this.scroll.phase===d&&(g=!1),g&&this.instance){const p=l(this.instance);this.scroll={animationId:this.root.animationId,phase:d,isRoot:p,offset:o(this.instance),wasRoot:this.scroll?this.scroll.isRoot:p}}}resetTransform(){if(!c)return;const d=this.isLayoutDirty||this.shouldResetTransform||this.options.alwaysMeasureLayout,g=this.projectionDelta&&!xv(this.projectionDelta),p=this.getTransformTemplate(),m=p?p(this.latestValues,""):void 0,x=m!==this.prevTransformTemplateValue;d&&this.instance&&(g||Li(this.latestValues)||x)&&(c(this.instance,m),this.shouldResetTransform=!1,this.scheduleRender())}measure(d=!0){const g=this.measurePageBox();let p=this.removeElementScroll(g);return d&&(p=this.removeTransform(p)),YE(p),{animationId:this.root.animationId,measuredBox:g,layoutBox:p,latestValues:{},source:this.id}}measurePageBox(){const{visualElement:d}=this.options;if(!d)return It();const g=d.measureViewportBox();if(!(this.scroll?.wasRoot||this.path.some(XE))){const{scroll:m}=this.root;m&&(za(g.x,m.offset.x),za(g.y,m.offset.y))}return g}removeElementScroll(d){const g=It();if(Ie(g,d),this.scroll?.wasRoot)return g;for(let p=0;p<this.path.length;p++){const m=this.path[p],{scroll:x,options:A}=m;m!==this.root&&x&&A.layoutScroll&&(x.wasRoot&&Ie(g,d),za(g.x,x.offset.x),za(g.y,x.offset.y))}return g}applyTransform(d,g=!1){const p=It();Ie(p,d);for(let m=0;m<this.path.length;m++){const x=this.path[m];!g&&x.options.layoutScroll&&x.scroll&&x!==x.root&&ka(p,{x:-x.scroll.offset.x,y:-x.scroll.offset.y}),Li(x.latestValues)&&ka(p,x.latestValues)}return Li(this.latestValues)&&ka(p,this.latestValues),p}removeTransform(d){const g=It();Ie(g,d);for(let p=0;p<this.path.length;p++){const m=this.path[p];if(!m.instance||!Li(m.latestValues))continue;ld(m.latestValues)&&m.updateSnapshot();const x=It(),A=m.measurePageBox();Ie(x,A),Oy(g,m.latestValues,m.snapshot?m.snapshot.layoutBox:void 0,x)}return Li(this.latestValues)&&Oy(g,this.latestValues),g}setTargetDelta(d){this.targetDelta=d,this.root.scheduleUpdateProjection(),this.isProjectionDirty=!0}setOptions(d){this.options={...this.options,...d,crossfade:d.crossfade!==void 0?d.crossfade:!0}}clearMeasurements(){this.scroll=void 0,this.layout=void 0,this.snapshot=void 0,this.prevTransformTemplateValue=void 0,this.targetDelta=void 0,this.target=void 0,this.isLayoutDirty=!1}forceRelativeParentToResolveTarget(){this.relativeParent&&this.relativeParent.resolvedRelativeTargetAt!==se.timestamp&&this.relativeParent.resolveTargetDelta(!0)}resolveTargetDelta(d=!1){const g=this.getLead();this.isProjectionDirty||(this.isProjectionDirty=g.isProjectionDirty),this.isTransformDirty||(this.isTransformDirty=g.isTransformDirty),this.isSharedProjectionDirty||(this.isSharedProjectionDirty=g.isSharedProjectionDirty);const p=!!this.resumingFrom||this!==g;if(!(d||p&&this.isSharedProjectionDirty||this.isProjectionDirty||this.parent?.isProjectionDirty||this.attemptToResolveRelativeTarget||this.root.updateBlockedByResize))return;const{layout:x,layoutId:A}=this.options;if(!(!this.layout||!(x||A))){if(this.resolvedRelativeTargetAt=se.timestamp,!this.targetDelta&&!this.relativeTarget){const b=this.getClosestProjectingParent();b&&b.layout&&this.animationProgress!==1?(this.relativeParent=b,this.forceRelativeParentToResolveTarget(),this.relativeTarget=It(),this.relativeTargetOrigin=It(),lo(this.relativeTargetOrigin,this.layout.layoutBox,b.layout.layoutBox),Ie(this.relativeTarget,this.relativeTargetOrigin)):this.relativeParent=this.relativeTarget=void 0}if(!(!this.relativeTarget&&!this.targetDelta)&&(this.target||(this.target=It(),this.targetWithTransforms=It()),this.relativeTarget&&this.relativeTargetOrigin&&this.relativeParent&&this.relativeParent.target?(this.forceRelativeParentToResolveTarget(),W8(this.target,this.relativeTarget,this.relativeParent.target)):this.targetDelta?(this.resumingFrom?this.target=this.applyTransform(this.layout.layoutBox):Ie(this.target,this.layout.layoutBox),tv(this.target,this.targetDelta)):Ie(this.target,this.layout.layoutBox),this.attemptToResolveRelativeTarget)){this.attemptToResolveRelativeTarget=!1;const b=this.getClosestProjectingParent();b&&!!b.resumingFrom==!!this.resumingFrom&&!b.options.layoutScroll&&b.target&&this.animationProgress!==1?(this.relativeParent=b,this.forceRelativeParentToResolveTarget(),this.relativeTarget=It(),this.relativeTargetOrigin=It(),lo(this.relativeTargetOrigin,this.target,b.target),Ie(this.relativeTarget,this.relativeTargetOrigin)):this.relativeParent=this.relativeTarget=void 0}}}getClosestProjectingParent(){if(!(!this.parent||ld(this.parent.latestValues)||Wx(this.parent.latestValues)))return this.parent.isProjecting()?this.parent:this.parent.getClosestProjectingParent()}isProjecting(){return!!((this.relativeTarget||this.targetDelta||this.options.layoutRoot)&&this.layout)}calcProjection(){const d=this.getLead(),g=!!this.resumingFrom||this!==d;let p=!0;if((this.isProjectionDirty||this.parent?.isProjectionDirty)&&(p=!1),g&&(this.isSharedProjectionDirty||this.isTransformDirty)&&(p=!1),this.resolvedRelativeTargetAt===se.timestamp&&(p=!1),p)return;const{layout:m,layoutId:x}=this.options;if(this.isTreeAnimating=!!(this.parent&&this.parent.isTreeAnimating||this.currentAnimation||this.pendingAnimation),this.isTreeAnimating||(this.targetDelta=this.relativeTarget=void 0),!this.layout||!(m||x))return;Ie(this.layoutCorrected,this.layout.layoutBox);const A=this.treeScale.x,b=this.treeScale.y;u8(this.layoutCorrected,this.treeScale,this.path,g),d.layout&&!d.target&&(this.treeScale.x!==1||this.treeScale.y!==1)&&(d.target=d.layout.layoutBox,d.targetWithTransforms=It());const{target:C}=d;if(!C){this.prevProjectionDelta&&(this.createProjectionDeltas(),this.scheduleRender());return}!this.projectionDelta||!this.prevProjectionDelta?this.createProjectionDeltas():(Ey(this.prevProjectionDelta.x,this.projectionDelta.x),Ey(this.prevProjectionDelta.y,this.projectionDelta.y)),oo(this.projectionDelta,this.layoutCorrected,C,this.latestValues),(this.treeScale.x!==A||this.treeScale.y!==b||!zy(this.projectionDelta.x,this.prevProjectionDelta.x)||!zy(this.projectionDelta.y,this.prevProjectionDelta.y))&&(this.hasProjected=!0,this.scheduleRender(),this.notifyListeners("projectionUpdate",C))}hide(){this.isVisible=!1}show(){this.isVisible=!0}scheduleRender(d=!0){if(this.options.visualElement?.scheduleRender(),d){const g=this.getStack();g&&g.scheduleRender()}this.resumingFrom&&!this.resumingFrom.instance&&(this.resumingFrom=void 0)}createProjectionDeltas(){this.prevProjectionDelta=Pa(),this.projectionDelta=Pa(),this.projectionDeltaWithTransform=Pa()}setAnimationOrigin(d,g=!1){const p=this.snapshot,m=p?p.latestValues:{},x={...this.latestValues},A=Pa();(!this.relativeParent||!this.relativeParent.options.layoutRoot)&&(this.relativeTarget=this.relativeTargetOrigin=void 0),this.attemptToResolveRelativeTarget=!g;const b=It(),C=p?p.source:void 0,O=this.layout?this.layout.source:void 0,z=C!==O,P=this.getStack(),R=!P||P.members.length<=1,H=!!(z&&!R&&this.options.crossfade===!0&&!this.path.some(qE));this.animationProgress=0;let V;this.mixTargetDelta=X=>{const G=X/1e3;Uy(A.x,d.x,G),Uy(A.y,d.y,G),this.setTargetDelta(A),this.relativeTarget&&this.relativeTargetOrigin&&this.layout&&this.relativeParent&&this.relativeParent.layout&&(lo(b,this.layout.layoutBox,this.relativeParent.layout.layoutBox),IE(this.relativeTarget,this.relativeTargetOrigin,b,G),V&&jE(this.relativeTarget,V)&&(this.isProjectionDirty=!1),V||(V=It()),Ie(V,this.relativeTarget)),z&&(this.animationValues=x,AE(x,m,this.latestValues,G,H,R)),this.root.scheduleUpdateProjection(),this.scheduleRender(),this.animationProgress=G},this.mixTargetDelta(this.options.layoutRoot?1e3:0)}startAnimation(d){this.notifyListeners("animationStart"),this.currentAnimation?.stop(),this.resumingFrom?.currentAnimation?.stop(),this.pendingAnimation&&(si(this.pendingAnimation),this.pendingAnimation=void 0),this.pendingAnimation=Lt.update(()=>{us.hasAnimatedSinceResize=!0,this.motionValue||(this.motionValue=Ga(0)),this.currentAnimation=yE(this.motionValue,[0,1e3],{...d,velocity:0,isSync:!0,onUpdate:g=>{this.mixTargetDelta(g),d.onUpdate&&d.onUpdate(g)},onStop:()=>{},onComplete:()=>{d.onComplete&&d.onComplete(),this.completeAnimation()}}),this.resumingFrom&&(this.resumingFrom.currentAnimation=this.currentAnimation),this.pendingAnimation=void 0})}completeAnimation(){this.resumingFrom&&(this.resumingFrom.currentAnimation=void 0,this.resumingFrom.preserveOpacity=void 0);const d=this.getStack();d&&d.exitAnimationComplete(),this.resumingFrom=this.currentAnimation=this.animationValues=void 0,this.notifyListeners("animationComplete")}finishAnimation(){this.currentAnimation&&(this.mixTargetDelta&&this.mixTargetDelta(RE),this.currentAnimation.stop()),this.completeAnimation()}applyTransformsToTarget(){const d=this.getLead();let{targetWithTransforms:g,target:p,layout:m,latestValues:x}=d;if(!(!g||!p||!m)){if(this!==d&&this.layout&&m&&Av(this.options.animationType,this.layout.layoutBox,m.layoutBox)){p=this.target||It();const A=pe(this.layout.layoutBox.x);p.x.min=d.target.x.min,p.x.max=p.x.min+A;const b=pe(this.layout.layoutBox.y);p.y.min=d.target.y.min,p.y.max=p.y.min+b}Ie(g,p),ka(g,x),oo(this.projectionDeltaWithTransform,this.layoutCorrected,g,x)}}registerSharedNode(d,g){this.sharedNodes.has(d)||this.sharedNodes.set(d,new OE),this.sharedNodes.get(d).add(g);const m=g.options.initialPromotionConfig;g.promote({transition:m?m.transition:void 0,preserveFollowOpacity:m&&m.shouldPreserveFollowOpacity?m.shouldPreserveFollowOpacity(g):void 0})}isLead(){const d=this.getStack();return d?d.lead===this:!0}getLead(){const{layoutId:d}=this.options;return d?this.getStack()?.lead||this:this}getPrevLead(){const{layoutId:d}=this.options;return d?this.getStack()?.prevLead:void 0}getStack(){const{layoutId:d}=this.options;if(d)return this.root.sharedNodes.get(d)}promote({needsReset:d,transition:g,preserveFollowOpacity:p}={}){const m=this.getStack();m&&m.promote(this,p),d&&(this.projectionDelta=void 0,this.needsReset=!0),g&&this.setOptions({transition:g})}relegate(){const d=this.getStack();return d?d.relegate(this):!1}resetSkewAndRotation(){const{visualElement:d}=this.options;if(!d)return;let g=!1;const{latestValues:p}=d;if((p.z||p.rotate||p.rotateX||p.rotateY||p.rotateZ||p.skewX||p.skewY)&&(g=!0),!g)return;const m={};p.z&&bf("z",d,m,this.animationValues);for(let x=0;x<vf.length;x++)bf(`rotate${vf[x]}`,d,m,this.animationValues),bf(`skew${vf[x]}`,d,m,this.animationValues);d.render();for(const x in m)d.setStaticValue(x,m[x]),this.animationValues&&(this.animationValues[x]=m[x]);d.scheduleRender()}applyProjectionStyles(d,g){if(!this.instance||this.isSVG)return;if(!this.isVisible){d.visibility="hidden";return}const p=this.getTransformTemplate();if(this.needsReset){this.needsReset=!1,d.visibility="",d.opacity="",d.pointerEvents=cs(g?.pointerEvents)||"",d.transform=p?p(this.latestValues,""):"none";return}const m=this.getLead();if(!this.projectionDelta||!this.layout||!m.target){this.options.layoutId&&(d.opacity=this.latestValues.opacity!==void 0?this.latestValues.opacity:1,d.pointerEvents=cs(g?.pointerEvents)||""),this.hasProjected&&!Li(this.latestValues)&&(d.transform=p?p({},""):"none",this.hasProjected=!1);return}d.visibility="";const x=m.animationValues||m.latestValues;this.applyTransformsToTarget();let A=DE(this.projectionDeltaWithTransform,this.treeScale,x);p&&(A=p(x,A)),d.transform=A;const{x:b,y:C}=this.projectionDelta;d.transformOrigin=`${b.origin*100}% ${C.origin*100}% 0`,m.animationValues?d.opacity=m===this?x.opacity??this.latestValues.opacity??1:this.preserveOpacity?this.latestValues.opacity:x.opacityExit:d.opacity=m===this?x.opacity!==void 0?x.opacity:"":x.opacityExit!==void 0?x.opacityExit:0;for(const O in yo){if(x[O]===void 0)continue;const{correct:z,applyTo:P,isCSSVariable:R}=yo[O],H=A==="none"?x[O]:z(x[O],m);if(P){const V=P.length;for(let X=0;X<V;X++)d[P[X]]=H}else R?this.options.visualElement.renderState.vars[O]=H:d[O]=H}this.options.layoutId&&(d.pointerEvents=m===this?cs(g?.pointerEvents)||"":"none")}clearSnapshot(){this.resumeFrom=this.snapshot=void 0}resetTree(){this.root.nodes.forEach(d=>d.currentAnimation?.stop()),this.root.nodes.forEach(ky),this.root.sharedNodes.clear()}}}function BE(n){n.updateLayout()}function zE(n){const a=n.resumeFrom?.snapshot||n.snapshot;if(n.isLead()&&n.layout&&a&&n.hasListeners("didUpdate")){const{layoutBox:o,measuredBox:l}=n.layout,{animationType:c}=n.options,f=a.source!==n.layout.source;c==="size"?qe(x=>{const A=f?a.measuredBox[x]:a.layoutBox[x],b=pe(A);A.min=o[x].min,A.max=A.min+b}):Av(c,a.layoutBox,o)&&qe(x=>{const A=f?a.measuredBox[x]:a.layoutBox[x],b=pe(o[x]);A.max=A.min+b,n.relativeTarget&&!n.currentAnimation&&(n.isProjectionDirty=!0,n.relativeTarget[x].max=n.relativeTarget[x].min+b)});const d=Pa();oo(d,o,a.layoutBox);const g=Pa();f?oo(g,n.applyTransform(l,!0),a.measuredBox):oo(g,o,a.layoutBox);const p=!xv(d);let m=!1;if(!n.resumeFrom){const x=n.getClosestProjectingParent();if(x&&!x.resumeFrom){const{snapshot:A,layout:b}=x;if(A&&b){const C=It();lo(C,a.layoutBox,A.layoutBox);const O=It();lo(O,o,b.layoutBox),vv(C,O)||(m=!0),x.options.layoutRoot&&(n.relativeTarget=O,n.relativeTargetOrigin=C,n.relativeParent=x)}}}n.notifyListeners("didUpdate",{layout:o,snapshot:a,delta:g,layoutDelta:d,hasLayoutChanged:p,hasRelativeLayoutChanged:m})}else if(n.isLead()){const{onExitComplete:o}=n.options;o&&o()}n.options.transition=void 0}function kE(n){n.parent&&(n.isProjecting()||(n.isProjectionDirty=n.parent.isProjectionDirty),n.isSharedProjectionDirty||(n.isSharedProjectionDirty=!!(n.isProjectionDirty||n.parent.isProjectionDirty||n.parent.isSharedProjectionDirty)),n.isTransformDirty||(n.isTransformDirty=n.parent.isTransformDirty))}function PE(n){n.isProjectionDirty=n.isSharedProjectionDirty=n.isTransformDirty=!1}function VE(n){n.clearSnapshot()}function ky(n){n.clearMeasurements()}function Py(n){n.isLayoutDirty=!1}function UE(n){const{visualElement:a}=n.options;a&&a.getProps().onBeforeLayoutMeasure&&a.notify("BeforeLayoutMeasure"),n.resetTransform()}function Vy(n){n.finishAnimation(),n.targetDelta=n.relativeTarget=n.target=void 0,n.isProjectionDirty=!0}function NE(n){n.resolveTargetDelta()}function _E(n){n.calcProjection()}function HE(n){n.resetSkewAndRotation()}function GE(n){n.removeLeadSnapshot()}function Uy(n,a,o){n.translate=kt(a.translate,0,o),n.scale=kt(a.scale,1,o),n.origin=a.origin,n.originPoint=a.originPoint}function Ny(n,a,o,l){n.min=kt(a.min,o.min,l),n.max=kt(a.max,o.max,l)}function IE(n,a,o,l){Ny(n.x,a.x,o.x,l),Ny(n.y,a.y,o.y,l)}function qE(n){return n.animationValues&&n.animationValues.opacityExit!==void 0}const FE={duration:.45,ease:[.4,0,.1,1]},_y=n=>typeof navigator<"u"&&navigator.userAgent&&navigator.userAgent.toLowerCase().includes(n),Hy=_y("applewebkit/")&&!_y("chrome/")?Math.round:Fe;function Gy(n){n.min=Hy(n.min),n.max=Hy(n.max)}function YE(n){Gy(n.x),Gy(n.y)}function Av(n,a,o){return n==="position"||n==="preserve-aspect"&&!J8(By(a),By(o),.2)}function XE(n){return n!==n.root&&n.scroll?.wasRoot}const KE=Sv({attachResizeListener:(n,a)=>vo(n,"resize",a),measureScroll:()=>({x:document.documentElement.scrollLeft||document.body.scrollLeft,y:document.documentElement.scrollTop||document.body.scrollTop}),checkIsScrollRoot:()=>!0}),Sf={current:void 0},wv=Sv({measureScroll:n=>({x:n.scrollLeft,y:n.scrollTop}),defaultParent:()=>{if(!Sf.current){const n=new KE({});n.mount(window),n.setOptions({layoutScroll:!0}),Sf.current=n}return Sf.current},resetTransform:(n,a)=>{n.style.transform=a!==void 0?a:"none"},checkIsScrollRoot:n=>window.getComputedStyle(n).position==="fixed"}),$E={pan:{Feature:hE},drag:{Feature:dE,ProjectionNode:wv,MeasureLayout:pv}};function Iy(n,a,o){const{props:l}=n;n.animationState&&l.whileHover&&n.animationState.setActive("whileHover",o==="Start");const c="onHover"+o,f=l[c];f&&Lt.postRender(()=>f(a,Eo(a)))}class QE extends fi{mount(){const{current:a}=this.node;a&&(this.unmount=xT(a,(o,l)=>(Iy(this.node,l,"Start"),c=>Iy(this.node,c,"End"))))}unmount(){}}class ZE extends fi{constructor(){super(...arguments),this.isActive=!1}onFocus(){let a=!1;try{a=this.node.current.matches(":focus-visible")}catch{a=!0}!a||!this.node.animationState||(this.node.animationState.setActive("whileFocus",!0),this.isActive=!0)}onBlur(){!this.isActive||!this.node.animationState||(this.node.animationState.setActive("whileFocus",!1),this.isActive=!1)}mount(){this.unmount=wo(vo(this.node.current,"focus",()=>this.onFocus()),vo(this.node.current,"blur",()=>this.onBlur()))}unmount(){}}function qy(n,a,o){const{props:l}=n;if(n.current instanceof HTMLButtonElement&&n.current.disabled)return;n.animationState&&l.whileTap&&n.animationState.setActive("whileTap",o==="Start");const c="onTap"+(o==="End"?"":o),f=l[c];f&&Lt.postRender(()=>f(a,Eo(a)))}class JE extends fi{mount(){const{current:a}=this.node;a&&(this.unmount=AT(a,(o,l)=>(qy(this.node,l,"Start"),(c,{success:f})=>qy(this.node,c,f?"End":"Cancel")),{useGlobalTarget:this.node.props.globalTapTarget}))}unmount(){}}const md=new WeakMap,Af=new WeakMap,WE=n=>{const a=md.get(n.target);a&&a(n)},t6=n=>{n.forEach(WE)};function e6({root:n,...a}){const o=n||document;Af.has(o)||Af.set(o,{});const l=Af.get(o),c=JSON.stringify(a);return l[c]||(l[c]=new IntersectionObserver(t6,{root:n,...a})),l[c]}function n6(n,a,o){const l=e6(a);return md.set(n,o),l.observe(n),()=>{md.delete(n),l.unobserve(n)}}const i6={some:0,all:1};class a6 extends fi{constructor(){super(...arguments),this.hasEnteredView=!1,this.isInView=!1}startObserver(){this.unmount();const{viewport:a={}}=this.node.getProps(),{root:o,margin:l,amount:c="some",once:f}=a,d={root:o?o.current:void 0,rootMargin:l,threshold:typeof c=="number"?c:i6[c]},g=p=>{const{isIntersecting:m}=p;if(this.isInView===m||(this.isInView=m,f&&!m&&this.hasEnteredView))return;m&&(this.hasEnteredView=!0),this.node.animationState&&this.node.animationState.setActive("whileInView",m);const{onViewportEnter:x,onViewportLeave:A}=this.node.getProps(),b=m?x:A;b&&b(p)};return n6(this.node.current,d,g)}mount(){this.startObserver()}update(){if(typeof IntersectionObserver>"u")return;const{props:a,prevProps:o}=this.node;["amount","margin","root"].some(r6(a,o))&&this.startObserver()}unmount(){}}function r6({viewport:n={}},{viewport:a={}}={}){return o=>n[o]!==a[o]}const o6={inView:{Feature:a6},tap:{Feature:JE},focus:{Feature:ZE},hover:{Feature:QE}},l6={layout:{ProjectionNode:wv,MeasureLayout:pv}},s6={...Y8,...o6,...$E,...l6},gt=l8(s6,b8),c6=()=>h.jsxs("svg",{width:"60",height:"60",viewBox:"0 0 24 24",fill:"none",stroke:"#28a745",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[h.jsx("path",{d:"M22 11.08V12a10 10 0 1 1-5.93-9.14"}),h.jsx("polyline",{points:"22 4 12 14.01 9 11.01"})]}),u6=S(gt.div)`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.6);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1001;
  backdrop-filter: blur(5px);
`,f6=S(gt.div)`
  background-color: white;
  border-radius: 16px;
  width: 90%;
  max-width: 800px;
  display: flex;
  overflow: hidden;
  box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
`,d6=S.div`
  background: #002664 linear-gradient(135deg, #001f5a 0%, #003380 100%);
  color: white;
  padding: 3.5rem;
  width: 40%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  position: relative;
  overflow: hidden;

  // Decorative quote icon for better UI
  &::before {
    content: '“';
    position: absolute;
    top: 1rem;
    left: 2rem;
    font-size: 8rem;
    color: rgba(255, 255, 255, 0.05);
    line-height: 1;
    font-family: Georgia, serif;
    z-index: 0;
  }

  h3 {
    font-size: 2.2rem;
    font-weight: 700;
    margin: 0 0 1rem 0;
    line-height: 1.3;
    z-index: 1;
    color: #d9e7ff;
  }
  p {
    font-size: 1.05rem;
    line-height: 1.7;
    color: #d9e7ff;
    max-width: 300px;
    z-index: 1;
  }

  @media (max-width: 768px) {
    display: none;
  }
`,h6=S.div`
  padding: 3rem;
  width: 60%;
  position: relative;
`,m6=S.button`
  position: absolute;
  top: 1rem;
  right: 1rem;
  background: transparent;
  border: none;
  font-size: 2rem;
  cursor: pointer;
  color: #a0aec0;
  line-height: 1;
`,Kl=S.div`
  margin-bottom: 1.25rem;
`,wf=S.label`
  display: block;
  font-size: 0.9rem;
  font-weight: 500;
  margin-bottom: 0.5rem;
  color: #2d3748;
`,Cf=S.input`
  width: 100%;
  padding: 0.75rem 1rem;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  font-size: 1rem;
  transition: all 0.2s ease;
  &:focus {
    outline: none;
    border-color: #003380;
    box-shadow: 0 0 0 2px rgba(0, 51, 128, 0.2);
  }
`,p6=S.div`
  display: flex;
`,g6=S.select`
  padding: 0.75rem;
  border: 1px solid #e2e8f0;
  border-right: none;
  border-radius: 8px 0 0 8px;
  background-color: #f7f8fc;
  font-size: 1rem;
`,Fy=S.label`
  display: flex;
  align-items: center;
  cursor: pointer;
  font-size: 0.9rem;
  color: #4a5568;
  margin-bottom: 0.75rem;

  input {
    margin-right: 0.75rem;
    height: 18px;
    width: 18px;
    accent-color: #003380;
  }
`,$l=S.p`
  color: #d9534f;
  font-size: 0.85rem;
  margin: 0.25rem 0 0 0;
`,y6=S.button`
  width: 100%;
  padding: 0.9rem;
  border-radius: 8px;
  background-color: #003380;
  color: white;
  font-size: 1rem;
  font-weight: 500;
  border: none;
  cursor: pointer;
  transition: all 0.2s ease;
  &:disabled {
    background-color: #a0aec0;
    cursor: not-allowed;
  }
`,x6=S.div`
  text-align: center;
  color: #2d3748;
  h4 {
    font-size: 1.5rem;
    color: #28a745;
    margin: 1rem 0 0.5rem 0;
  }
`,v6=({setOpen:n})=>{const[a,o]=E.useState({fullName:"",mobileNumber:"",email:""}),[l,c]=E.useState({terms:!1,updates:!1}),[f,d]=E.useState({}),[g,p]=E.useState("idle"),m=C=>{const{name:O,value:z}=C.target;o(P=>({...P,[O]:z}))},x=C=>{const{name:O,checked:z}=C.target;c(P=>({...P,[O]:z}))},A=()=>{let C={};return a.fullName||(C.fullName="Full name is required."),a.mobileNumber?/^\d{10}$/.test(a.mobileNumber)||(C.mobileNumber="Please enter a valid 10-digit number."):C.mobileNumber="Mobile number is required.",a.email?/\S+@\S+\.\S+/.test(a.email)||(C.email="Email is not valid."):C.email="Email is required.",l.terms||(C.terms="You must agree to the terms."),d(C),Object.keys(C).length===0},b=C=>{C.preventDefault(),A()&&(p("submitting"),setTimeout(()=>{p("success")},1500))};return h.jsx(u6,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},onClick:()=>n(!1),children:h.jsxs(f6,{initial:{y:-50,opacity:0},animate:{y:0,opacity:1},exit:{y:50,opacity:0},transition:{type:"spring",stiffness:300,damping:30},onClick:C=>C.stopPropagation(),children:[h.jsxs(d6,{children:[h.jsx("h3",{children:"Request a Callback"}),h.jsx("p",{children:"Just share your details and we will call you back at your convenience."})]}),h.jsxs(h6,{children:[h.jsx(m6,{onClick:()=>n(!1),children:"×"}),g==="success"?h.jsxs(x6,{children:[h.jsx(c6,{}),h.jsx("h4",{children:"Thank You!"}),h.jsx("p",{children:"Your request has been received. We will contact you shortly."})]}):h.jsxs("form",{onSubmit:b,children:[h.jsxs(Kl,{children:[h.jsx(wf,{htmlFor:"fullName",children:"Full Name"}),h.jsx(Cf,{type:"text",id:"fullName",name:"fullName",value:a.fullName,onChange:m}),f.fullName&&h.jsx($l,{children:f.fullName})]}),h.jsxs(Kl,{children:[h.jsx(wf,{htmlFor:"mobileNumber",children:"Mobile Number"}),h.jsxs(p6,{children:[h.jsx(g6,{children:h.jsx("option",{children:"+91"})}),h.jsx(Cf,{type:"tel",id:"mobileNumber",name:"mobileNumber",value:a.mobileNumber,onChange:m,style:{borderRadius:"0 8px 8px 0"}})]}),f.mobileNumber&&h.jsx($l,{children:f.mobileNumber})]}),h.jsxs(Kl,{children:[h.jsx(wf,{htmlFor:"email",children:"Email ID"}),h.jsx(Cf,{type:"email",id:"email",name:"email",value:a.email,onChange:m}),f.email&&h.jsx($l,{children:f.email})]}),h.jsxs(Kl,{children:[h.jsxs(Fy,{children:[h.jsx("input",{type:"checkbox",name:"terms",checked:l.terms,onChange:x}),h.jsxs("span",{children:["By registering I agree to the ",h.jsx("a",{href:"#",children:"Terms of Service"})," and"," ",h.jsx("a",{href:"#",children:"Privacy Policy"}),"."]})]}),f.terms&&h.jsx($l,{children:f.terms}),h.jsxs(Fy,{children:[h.jsx("input",{type:"checkbox",name:"updates",checked:l.updates,onChange:x}),h.jsx("span",{children:"Yes, I would like to receive updates via email."})]})]}),h.jsx(y6,{type:"submit",disabled:g==="submitting",children:g==="submitting"?"Submitting...":"Submit"})]})]})]})})},b6=S.section`
  padding: 4rem 2rem;
`,S6=S.div`
  max-width: 1200px;
  margin: 0 auto;
  background: linear-gradient(135deg, #001f5a, #003380); // Rich blue gradient
  border-radius: 20px;
  padding: 3rem 4rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: relative;
  overflow: hidden;
  box-shadow: 0 20px 40px rgba(0, 31, 90, 0.3);

  @media (max-width: 992px) {
    flex-direction: column;
    text-align: center;
    padding: 3rem 2rem;
  }
`,A6=S.div`
  z-index: 2;
  max-width: 50%;

  @media (max-width: 992px) {
    max-width: 100%;
    margin-bottom: 2.5rem;
  }
`,w6=S.h2`
  color: #ffffff;
  font-size: 2.8rem;
  font-weight: bold;
  margin: 0 0 1rem 0;
  line-height: 1.2;
`,C6=S.p`
  color: #cce0ff; // Lighter blue for soft contrast
  font-size: 1.1rem;
  line-height: 1.6;
  margin: 0 0 2rem 0;
  max-width: 450px;

  @media (max-width: 992px) {
    margin-left: auto;
    margin-right: auto;
  }
`,T6=S.a`
  display: inline-block;
  background-color: #ffffff;
  color: #003380;
  padding: 0.9rem 2.2rem;
  border-radius: 50px; // Pill-shaped button
  text-decoration: none;
  font-weight: bold;
  font-size: 1rem;
  transition: all 0.3s ease;
  box-shadow: 0 5px 15px rgba(255, 255, 255, 0.2);

  &:hover {
    background-color: #f0f8ff;
    transform: translateY(-3px) scale(1.05);
    box-shadow: 0 8px 20px rgba(255, 255, 255, 0.3);
  }
`,E6=S.div`
  z-index: 1;
  position: relative;
  width: 300px;
  height: 300px;

  @media (max-width: 992px) {
    width: 250px;
    height: 250px;
  }
`,M6=S.img`
  width: 100%;
  height: 100%;
  object-fit: contain;
  position: relative;
  z-index: 2;
  border-radius: 50%;
`,ch=S.div`
  position: absolute;
  width: 100%;
  height: 100%;
  border-radius: 50%;
  border: 2px solid rgba(255, 255, 255, 0.2);
  top: 0;
  left: 0;
  z-index: 1;
  transform: scale(0.9);
`,j6=S(ch)`
  transform: scale(1.1);
  border-style: dashed;
`,O6=S(ch)`
  width: 120%;
  height: 120%;
  top: -10%;
  left: -10%;
  border-color: rgba(217, 83, 79, 0.5); // Subtle red accent
  transform: scale(1);
`,Cv=()=>{const[n,a]=E.useState(!1);return h.jsxs(h.Fragment,{children:[h.jsx(b6,{children:h.jsxs(S6,{children:[h.jsxs(A6,{children:[h.jsx(w6,{children:"Connect with us"}),h.jsx(C6,{children:"Just share your details and we will contact you at your convenience."}),h.jsx(T6,{onClick:()=>a(!0),children:"Request a Callback →"})]}),h.jsxs(E6,{children:[h.jsx(ch,{}),h.jsx(j6,{}),h.jsx(O6,{}),h.jsx(M6,{src:"https://placehold.co/300x300/ffffff/333?text=Agent&font=png",alt:"Support agent",style:{backgroundColor:"transparent"}})]})]})}),h.jsx(po,{children:n&&h.jsx(v6,{setOpen:a})})]})},D6=S.section`
  height: 75vh;
  width: 100%;
  position: relative;
  display: flex;
  align-items: flex-end; /* Aligns content to the bottom */
  justify-content: flex-start; /* Aligns content to the left */
  padding: 3rem;
  background-color: #e0e0e0; // Fallback color
  background-image: url('https://placehold.co/1920x1080/a29bfe/ffffff?text=Your+Inspiring+Background+Image');
  background-image: url('/hero.jpg');
  background-size: contain;
  background-position: center;
  background-repeat: no-repeat;
  font-family:
    -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;

  aspect-ratio: 16/9;
  min-height: 50vh;
  max-height: 80vh;

  @media (max-width: 768px) {
    padding: 2rem;
    align-items: center;
    justify-content: center;
    text-align: center;

    min-height: 40vh;
  }
`,R6=S.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(to top, rgba(0, 0, 0, 0.4) 0%, transparent 50%);
`,L6=S(gt.a)`
  padding: 1rem 2.5rem;
  background-color: #ffffff;
  color: #000080;
  border: none;
  border-radius: 50px;
  font-size: 1.1rem;
  font-weight: 600;
  cursor: pointer;
  text-decoration: none;
  z-index: 1;
  box-shadow: 0 5px 20px rgba(0, 0, 0, 0.2);
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-3px) scale(1.05);
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
    background-color: #f0f8ff;
  }
`,B6=()=>h.jsxs(D6,{children:[h.jsx(R6,{}),h.jsx(L6,{href:"/recommendations",initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.8,ease:"easeOut",delay:.5},children:"Get Started →"})]}),Yy=[{name:"EY",logo:"/images/partners/EY.webp"},{name:"Partner 2",logo:"/images/partners/EY.webp"},{name:"Partner 3",logo:"/images/partners/BARCLAYS.jpg"},{name:"Partner 4",logo:"/images/partners/GENPACT.jpg"},{name:"Partner 5",logo:"/images/partners/HDFC.jpeg"},{name:"Partner 6",logo:"/images/partners/MCX.jpg"},{name:"Partner 7",logo:"/images/partners/OSWAL.png"},{name:"Partner 8",logo:"/images/partners/SAP.jpg"}],z6=[...Yy,...Yy],k6=S.section`
  background-color: #ffffff;
  padding: 6rem 0;
  font-family:
    -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  text-align: center;
`,P6=S(gt.div)`
  margin-bottom: 4rem;
`,V6=S.h2`
  font-size: 2.5rem;
  font-weight: 700;
  color: #000080;
  margin: 0;
`,U6=q1`
  0% {
    transform: translateX(0);
  }
  100% {
    transform: translateX(calc(-250px * 8)); 
  }
`,N6=S.div`
  max-width: 1200px;
  margin: 0 auto;
  overflow: hidden;
  position: relative;
  -webkit-mask-image: linear-gradient(to right, transparent, black 20%, black 80%, transparent);
  mask-image: linear-gradient(to right, transparent, black 20%, black 80%, transparent);
`,_6=S.div`
  display: flex;
  width: calc(250px * 16);
  animation: ${U6} 40s linear infinite;

  &:hover {
    animation-play-state: paused;
  }
`,H6=S.a`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 250px;
  padding: 0 2rem;
  flex-shrink: 0;

  img {
    height: 100px;
    max-width: 100%;

    opacity: 0.85;
    transition: all 0.3s ease;
  }

  &:hover img {
    opacity: 1;
    transform: scale(1.05);
  }
`,G6=()=>h.jsxs(k6,{children:[h.jsx(P6,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.5},transition:{duration:.6},children:h.jsx(V6,{children:"Our Online Prodegree Partners"})}),h.jsx(N6,{children:h.jsx(_6,{children:z6.map((n,a)=>h.jsx(H6,{href:"#","aria-label":n.name,children:h.jsx("img",{src:n.logo,alt:n.name})},a))})})]}),I6=[{name:"Alliance Partner A",logo:"/images/alliances/cisi.png"},{name:"Alliance Partner B",logo:"/images/alliances/nsdc.png"},{name:"Alliance Partner C",logo:"/images/alliances/iiba.jpeg"},{name:"Alliance Partner D",logo:"/images/alliances/nse.jpg"}],q6=S.section`
  background-color: #f8f9fa;
  padding: 6rem 2rem;
  font-family:
    -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
`,F6=S(gt.div)`
  text-align: center;
  margin-bottom: 4rem;
`,Y6=S.h2`
  font-size: 2.5rem;
  font-weight: 700;
  color: #000080;
  margin: 0;
`,X6=S(gt.div)`
  max-width: 1200px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
`,K6=S(gt.a)`
  background-color: #ffffff;
  border-radius: 16px;
  padding: 2rem;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px solid #e2e8f0;
  transition: all 0.3s ease;
  aspect-ratio: 16 / 9;
  text-decoration: none;

  img {
    max-width: 80%;
    max-height: 100px; // Ensures logos are of a considerable size
    transition: transform 0.3s ease;
  }

  &:hover {
    transform: translateY(-10px);
    box-shadow: 0 15px 30px rgba(0, 51, 128, 0.1);
    border-color: #003380;

    img {
      transform: scale(1.05);
    }
  }
`,$6={hidden:{opacity:0},visible:{opacity:1,transition:{staggerChildren:.1,delayChildren:.2}}},Q6={hidden:{y:20,opacity:0},visible:{y:0,opacity:1,transition:{duration:.5,ease:"easeOut"}}},Z6=()=>h.jsxs(q6,{children:[h.jsx(F6,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.5},transition:{duration:.6},children:h.jsx(Y6,{children:"Our Alliances"})}),h.jsx(X6,{variants:$6,initial:"hidden",whileInView:"visible",viewport:{once:!0,amount:.2},children:I6.map((n,a)=>h.jsx(K6,{href:"#",variants:Q6,"aria-label":`Visit ${n.name}`,children:h.jsx("img",{src:n.logo,alt:`${n.name} logo`})},a))})]});function J6(){return h.jsxs(h.Fragment,{children:[h.jsx(B6,{}),h.jsx(l4,{}),h.jsx(P4,{}),h.jsx(eA,{}),h.jsx(mA,{}),h.jsx(MA,{}),h.jsx(NA,{}),h.jsx(rw,{}),h.jsx(Ow,{}),h.jsx(G6,{}),h.jsx(Z6,{}),h.jsx(Cv,{})]})}const W6={colors:{primary:"#3A86FF",secondary:"#8338EC",success:"#06D6A0",danger:"#EF476F",warning:"#FFD166",info:"#118AB2",light:"#F9FAFB",dark:"#1E1E1E",background:"#FFFFFF",text:"#1F2937",muted:"#9CA3AF"},space:{xs:"0.25rem",sm:"0.5rem",md:"1rem",lg:"1.5rem",xl:"2rem",xxl:"3rem"},fontSizes:{xs:"0.75rem",sm:"0.875rem",md:"1rem",lg:"1.25rem",xl:"1.5rem",xxl:"2rem",xxxl:"2.5rem"},breakpoints:{sm:"576px",md:"768px",lg:"992px",xl:"1200px",xxl:"1400px"},shadows:{sm:"0 1px 3px rgba(0, 0, 0, 0.06)",md:"0 4px 6px rgba(0, 0, 0, 0.1)",lg:"0 10px 15px rgba(0, 0, 0, 0.1)"},radii:{sm:"0.25rem",md:"0.5rem",lg:"1rem",full:"9999px"}};var Tf={exports:{}},Ef,Xy;function tM(){if(Xy)return Ef;Xy=1;var n="SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";return Ef=n,Ef}var Mf,Ky;function eM(){if(Ky)return Mf;Ky=1;var n=tM();function a(){}function o(){}return o.resetWarningCache=a,Mf=function(){function l(d,g,p,m,x,A){if(A!==n){var b=new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");throw b.name="Invariant Violation",b}}l.isRequired=l;function c(){return l}var f={array:l,bigint:l,bool:l,func:l,number:l,object:l,string:l,symbol:l,any:l,arrayOf:c,element:l,elementType:l,instanceOf:c,node:l,objectOf:c,oneOf:c,oneOfType:c,shape:c,exact:c,checkPropTypes:o,resetWarningCache:a};return f.PropTypes=f,f},Mf}var $y;function nM(){return $y||($y=1,Tf.exports=eM()()),Tf.exports}var iM=nM();const aM=n1(iM),Tv=({children:n})=>h.jsx(R5,{theme:W6,children:n});Tv.propTypes={children:aM.node.isRequired};var Ev={color:void 0,size:void 0,className:void 0,style:void 0,attr:void 0},Qy=ie.createContext&&ie.createContext(Ev),rM=["attr","size","title"];function oM(n,a){if(n==null)return{};var o=lM(n,a),l,c;if(Object.getOwnPropertySymbols){var f=Object.getOwnPropertySymbols(n);for(c=0;c<f.length;c++)l=f[c],!(a.indexOf(l)>=0)&&Object.prototype.propertyIsEnumerable.call(n,l)&&(o[l]=n[l])}return o}function lM(n,a){if(n==null)return{};var o={};for(var l in n)if(Object.prototype.hasOwnProperty.call(n,l)){if(a.indexOf(l)>=0)continue;o[l]=n[l]}return o}function As(){return As=Object.assign?Object.assign.bind():function(n){for(var a=1;a<arguments.length;a++){var o=arguments[a];for(var l in o)Object.prototype.hasOwnProperty.call(o,l)&&(n[l]=o[l])}return n},As.apply(this,arguments)}function Zy(n,a){var o=Object.keys(n);if(Object.getOwnPropertySymbols){var l=Object.getOwnPropertySymbols(n);a&&(l=l.filter(function(c){return Object.getOwnPropertyDescriptor(n,c).enumerable})),o.push.apply(o,l)}return o}function ws(n){for(var a=1;a<arguments.length;a++){var o=arguments[a]!=null?arguments[a]:{};a%2?Zy(Object(o),!0).forEach(function(l){sM(n,l,o[l])}):Object.getOwnPropertyDescriptors?Object.defineProperties(n,Object.getOwnPropertyDescriptors(o)):Zy(Object(o)).forEach(function(l){Object.defineProperty(n,l,Object.getOwnPropertyDescriptor(o,l))})}return n}function sM(n,a,o){return a=cM(a),a in n?Object.defineProperty(n,a,{value:o,enumerable:!0,configurable:!0,writable:!0}):n[a]=o,n}function cM(n){var a=uM(n,"string");return typeof a=="symbol"?a:a+""}function uM(n,a){if(typeof n!="object"||!n)return n;var o=n[Symbol.toPrimitive];if(o!==void 0){var l=o.call(n,a);if(typeof l!="object")return l;throw new TypeError("@@toPrimitive must return a primitive value.")}return(a==="string"?String:Number)(n)}function Mv(n){return n&&n.map((a,o)=>ie.createElement(a.tag,ws({key:o},a.attr),Mv(a.child)))}function Qa(n){return a=>ie.createElement(fM,As({attr:ws({},n.attr)},a),Mv(n.child))}function fM(n){var a=o=>{var{attr:l,size:c,title:f}=n,d=oM(n,rM),g=c||o.size||"1em",p;return o.className&&(p=o.className),n.className&&(p=(p?p+" ":"")+n.className),ie.createElement("svg",As({stroke:"currentColor",fill:"currentColor",strokeWidth:"0"},o.attr,l,d,{className:p,style:ws(ws({color:n.color||o.color},o.style),n.style),height:g,width:g,xmlns:"http://www.w3.org/2000/svg"}),f&&ie.createElement("title",null,f),n.children)};return Qy!==void 0?ie.createElement(Qy.Consumer,null,o=>a(o)):a(Ev)}function jv(n){return Qa({attr:{viewBox:"0 0 320 512"},child:[{tag:"path",attr:{d:"M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"},child:[]}]})(n)}function dM(n){return Qa({attr:{viewBox:"0 0 488 512"},child:[{tag:"path",attr:{d:"M488 261.8C488 403.3 391.1 504 248 504 110.8 504 0 393.2 0 256S110.8 8 248 8c66.8 0 123 24.5 166.3 64.9l-67.5 64.9C258.5 52.6 94.3 116.6 94.3 256c0 86.5 69.1 156.6 153.7 156.6 98.2 0 135-70.4 140.8-106.9H248v-85.3h236.1c2.3 12.7 3.9 24.9 3.9 41.4z"},child:[]}]})(n)}function hM(n){return Qa({attr:{viewBox:"0 0 448 512"},child:[{tag:"path",attr:{d:"M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"},child:[]}]})(n)}function mM(n){return Qa({attr:{viewBox:"0 0 448 512"},child:[{tag:"path",attr:{d:"M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z"},child:[]}]})(n)}function pM(n){return Qa({attr:{viewBox:"0 0 512 512"},child:[{tag:"path",attr:{d:"M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z"},child:[]}]})(n)}function gM(n){return Qa({attr:{viewBox:"0 0 576 512"},child:[{tag:"path",attr:{d:"M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z"},child:[]}]})(n)}const yM={"General Management":{"Early Career":[{id:1,title:"Business Fundamentals",logo:"🎓",rating:4.5},{id:2,title:"Intro to Project Management",logo:"📊",rating:4.7}],Executive:[{id:3,title:"Advanced Corporate Strategy",logo:"📈",rating:4.9},{id:4,title:"Global Leadership Program",logo:"🌍",rating:4.8}]},"Technology & Analytics":{"Early Career":[{id:5,title:"Python for Data Science",logo:"🐍",rating:4.9},{id:6,title:"Full-Stack Web Development",logo:"💻",rating:4.8}],Executive:[{id:7,title:"AI for Business Leaders",logo:"🤖",rating:4.9},{id:8,title:"Cybersecurity Strategy",logo:"🔒",rating:4.7}],Online:[{id:9,title:"Machine Learning A-Z",logo:"🧠",rating:4.6}]},"Banking & Finance":{"Early Career":[{id:10,title:"Financial Modeling & Valuation",logo:"💰",rating:4.8}],Executive:[{id:11,title:"Fintech & Digital Banking",logo:"💳",rating:4.9}],Online:[{id:12,title:"Algorithmic Trading Basics",logo:"➗",rating:4.7}]},"Leadership and Strategy":{"Early Career":[{id:13,title:"Emerging Leaders Program",logo:"🌱",rating:4.7}],Executive:[{id:14,title:"Strategic Negotiation",logo:"🤝",rating:4.9},{id:15,title:"C-Suite Leadership Excellence",logo:"👑",rating:4.8}]},"Operations & Supply Chain":{"Early Career":[{id:16,title:"Logistics & Distribution Basics",logo:"🚚",rating:4.6}],Executive:[{id:17,title:"Global Supply Chain Management",logo:"🌐",rating:4.8}],Online:[{id:18,title:"Lean Six Sigma Certification",logo:"⚙️",rating:4.9}]},"Marketing & Sales":{"Early Career":[{id:19,title:"Digital Marketing Fundamentals",logo:"📱",rating:4.8},{id:20,title:"Professional Sales Techniques",logo:"🗣️",rating:4.7}],Executive:[{id:21,title:"Chief Marketing Officer Program",logo:"📣",rating:4.9}]},Healthcare:{"Early Career":[{id:22,title:"Intro to Healthcare Management",logo:"🏥",rating:4.6}],Executive:[{id:23,title:"Hospital Administration Leadership",logo:"🏨",rating:4.8}]},"Product Management":{"Early Career":[{id:24,title:"Associate Product Manager Bootcamp",logo:"🚀",rating:4.8}],Online:[{id:25,title:"Agile & Scrum Masterclass",logo:"🔄",rating:4.7}]},"Human Resources":{"Early Career":[{id:26,title:"Talent Acquisition & Recruitment",logo:"🧑‍💼",rating:4.7}],Executive:[{id:27,title:"Strategic HR Leadership",logo:"👥",rating:4.8}]}},Ov=["General Management","Technology & Analytics","Banking & Finance","Leadership and Strategy","Operations & Supply Chain","Marketing & Sales","Healthcare","Product Management","Human Resources"],xM=({activeCategory:n,setActiveCategory:a})=>{const o=yM[n]||{};return h.jsx(NM,{initial:{opacity:0,y:-10},animate:{opacity:1,y:0},exit:{opacity:0,y:-10},transition:{duration:.2},children:h.jsxs(_M,{children:[h.jsx(HM,{children:Ov.map(l=>h.jsx(GM,{active:n===l,onMouseEnter:()=>a(l),children:l},l))}),h.jsxs(IM,{children:[Object.keys(o).length>0?Object.entries(o).map(([l,c])=>h.jsxs(qM,{children:[h.jsxs(FM,{children:[l," Courses"]}),c.map(f=>h.jsxs(YM,{children:[h.jsx(XM,{children:f.logo}),h.jsxs(KM,{children:[h.jsx("h4",{children:f.title}),h.jsxs("p",{children:["Rating: ",f.rating," ★"]})]})]},f.id))]},l)):h.jsx("p",{children:"Select a category to see courses."}),h.jsx($M,{to:"/courses",children:"View All Courses →"})]})]})})},vM=({setOpen:n})=>h.jsx(QM,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},children:h.jsxs(ZM,{initial:{y:-50,opacity:0},animate:{y:0,opacity:1},exit:{y:50,opacity:0},transition:{type:"spring",stiffness:300,damping:30},children:[h.jsx(JM,{onClick:()=>n(!1),children:"×"}),h.jsx("h3",{children:"Welcome!"}),h.jsx("p",{children:"Sign in or create an account to continue"}),h.jsxs(Jy,{google:!0,children:[h.jsx(dM,{})," Continue with Google"]}),h.jsxs(Jy,{children:[h.jsx(jv,{})," Continue with Facebook"]}),h.jsx(WM,{children:h.jsx("span",{children:"OR"})}),h.jsx("input",{type:"email",placeholder:"Enter your email"}),h.jsx("button",{className:"email-continue",children:"Continue with Email"})]})}),bM=()=>{const[n,a]=E.useState(!1),[o,l]=E.useState(!1),[c,f]=E.useState(Ov[0]),[d,g]=E.useState(!1);return E.useEffect(()=>{const p=()=>{a(window.scrollY>30)};return window.addEventListener("scroll",p),()=>window.removeEventListener("scroll",p)},[]),h.jsxs(SM,{children:[h.jsx(AM,{animate:{backgroundColor:n?"#fffffff2":"transparent",boxShadow:n?"0 4px 20px rgba(0, 0, 0, 0.07)":"none"},transition:{duration:.3,ease:"easeInOut"},children:h.jsxs(wM,{children:[h.jsxs(CM,{children:[h.jsx(TM,{}),h.jsx(EM,{to:"/",children:"Career Counselling Corporation of India"})]}),h.jsxs(MM,{children:[h.jsxs(UM,{onMouseEnter:()=>l(!0),onMouseLeave:()=>l(!1),children:[h.jsx(Ql,{to:"/courses",children:"Courses"}),h.jsx(po,{children:o&&h.jsx(xM,{activeCategory:c,setActiveCategory:f})})]}),h.jsx(Ql,{to:"/training-and-placements",children:"Training & Placements"}),h.jsx(Ql,{to:"/about",children:"About Us"}),h.jsx(Ql,{to:"/recommendations",children:"Recommendations"})]}),h.jsxs(jM,{children:[h.jsx(OM,{type:"text",placeholder:"Search..."}),h.jsx(DM,{as:"button",onClick:()=>g(!0),children:"Login / Register"})]})]})}),h.jsx(RM,{children:h.jsx(W3,{})}),h.jsxs(LM,{children:[h.jsxs(BM,{children:[h.jsxs(Zl,{children:[h.jsx(zM,{children:"Career Counselling Corporation of India"}),h.jsx(kM,{children:"Empowering learners and professionals with curated content and guidance to achieve their career aspirations across diverse industries and skills."}),h.jsxs(PM,{children:[h.jsx("a",{href:"#","aria-label":"Facebook",children:h.jsx(jv,{})}),h.jsx("a",{href:"#","aria-label":"Twitter",children:h.jsx(pM,{})}),h.jsx("a",{href:"#","aria-label":"Instagram",children:h.jsx(hM,{})}),h.jsx("a",{href:"#","aria-label":"LinkedIn",children:h.jsx(mM,{})}),h.jsx("a",{href:"#","aria-label":"YouTube",children:h.jsx(gM,{})})]})]}),h.jsxs(Zl,{children:[h.jsx(jf,{children:"Explore"}),h.jsx(Ze,{to:"/courses",children:"Early Career Courses"}),h.jsx(Ze,{to:"/courses",children:"Executive Education"}),h.jsx(Ze,{to:"/courses",children:"Self-Paced Courses"}),h.jsx(Ze,{to:"/enterprise",children:"Enterprise Solutions"})]}),h.jsxs(Zl,{children:[h.jsx(jf,{children:"Support"}),h.jsx(Ze,{to:"/help",children:"Help Center"}),h.jsx(Ze,{to:"/contact",children:"Contact Us"}),h.jsx(Ze,{to:"/faq",children:"FAQ"})]}),h.jsxs(Zl,{children:[h.jsx(jf,{children:"Company"}),h.jsx(Ze,{to:"/about",children:"About Us"}),h.jsx(Ze,{to:"/careers",children:"Careers"}),h.jsx(Ze,{to:"/terms",children:"Terms & Conditions"}),h.jsx(Ze,{to:"/privacy",children:"Privacy Policy"})]})]}),h.jsxs(VM,{children:["© ",new Date().getFullYear()," Career Counselling Corporation of India. All Rights Reserved."]})]}),h.jsx(po,{children:d&&h.jsx(vM,{setOpen:g})})]})},SM=S.div`
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  background-color: #ffffff;
`,AM=S(gt.nav)`
  position: sticky;
  top: 0;
  width: 100%;
  z-index: 1000;
  backdrop-filter: blur(10px);
  border-bottom: 1px solid transparent;
  transition: border-color 0.3s ease;

  &[style*='background-color: rgb(255, 255, 255)'] {
    border-bottom-color: #e0e0e0;
  }
`,wM=S.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1.2rem 2rem;
  max-width: 1500px;
  margin: 0 auto;
`,CM=S.div`
  display: flex;
  align-items: center;
  /* gap: 1rem; */
  flex-shrink: 0;
  @media (max-width: 768px) {
    gap: 0.5rem;
    flex-shrink: 1;
  }
`,TM=S.img.attrs({src:"/logo.png",alt:"Logo"})`
  width: 50px;
  height: 50px;
  margin-right: 1rem;
  border-radius: 50%;
  object-fit: cover;
  transition: transform 0.3s ease;
  &:hover {
    transform: scale(1.05);
  }
`,EM=S(ui)`
  font-size: 1.3rem;
  font-weight: 400;
  letter-spacing: 1px;
  color: #000080;
  text-decoration: none;
  white-space: nowrap;
`,MM=S.div`
  display: flex;
  align-items: center;
  gap: 2rem;

  @media (max-width: 1024px) {
    display: none; // Example: Hide for a mobile menu implementation
  }
`,Ql=S(ui)`
  font-size: 1rem;
  color: #333;
  font-weight: 500;
  text-decoration: none;
  position: relative;
  padding-bottom: 5px;

  &::after {
    content: '';
    position: absolute;
    width: 0;
    height: 2px;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    background-color: #000080;
    transition: width 0.3s ease;
  }

  &:hover::after {
    width: 100%;
  }
`,jM=S.div`
  display: flex;
  align-items: center;
  gap: 1rem;
`,OM=S.input`
  padding: 0.6rem 1rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 0.9rem;
  transition: all 0.3s ease;
  width: 180px;

  &:focus {
    border-color: #000080;
    outline: none;
    box-shadow: 0 0 0 3px rgba(0, 0, 128, 0.1);
    width: 220px;
  }
`,DM=S(ui)`
  padding: 0.35rem 1.5rem;
  background: #d9534f;
  color: white;
  border-radius: 8px;
  font-weight: 500;
  text-decoration: none;
  transition: all 0.3s ease;
  white-space: nowrap;

  &:hover {
    background: #c9302c;
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(217, 83, 79, 0.3);
    color: #ffffff;
  }
`,RM=S.main`
  flex: 1;
`,LM=S.footer`
  background: #000080;
  color: #e0e0e0;
  padding: 4rem 2rem 2rem 2rem;
`,BM=S.div`
  display: grid;
  grid-template-columns: 2fr 1fr 1fr 1fr;
  gap: 3rem;
  max-width: 1400px;
  margin: 0 auto;
  padding-bottom: 3rem;

  @media (max-width: 992px) {
    grid-template-columns: repeat(2, 1fr);
  }
  @media (max-width: 576px) {
    grid-template-columns: 1fr;
  }
`,Zl=S.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`,zM=S.div`
  font-size: 1.5rem;
  font-weight: 700;
  color: #ffffff;
  margin-bottom: 0.5rem;
`,kM=S.p`
  font-size: 0.95rem;
  line-height: 1.6;
  color: #cce0ff;
  max-width: 350px;
`,PM=S.div`
  display: flex;
  gap: 1rem;
  margin-top: 0.5rem;

  a {
    color: #ffffff;
    font-size: 1.2rem;
    transition: all 0.3s ease;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: rgba(255, 255, 255, 0.1);

    &:hover {
      color: #ffffff;
      background-color: #d9534f;
      transform: translateY(-3px);
    }
  }
`,jf=S.div`
  font-size: 1.1rem;
  font-weight: 600;
  color: #ffffff;
  margin-bottom: 0.5rem;
`,Ze=S(ui)`
  font-size: 0.95rem;
  color: #cce0ff;
  text-decoration: none;
  transition: color 0.2s;

  &:hover {
    color: #ffffff;
  }
`,VM=S.div`
  text-align: center;
  padding-top: 2rem;
  margin-top: 2rem;
  border-top: 1px solid rgba(255, 255, 255, 0.2);
  font-size: 0.9rem;
  color: #cce0ff;
`,UM=S.div`
  position: relative;
`,NM=S(gt.div)`
  position: absolute;
  top: 150%;
  left: -30rem;
  transform: translateX(-50%);
  width: 90vw;
  max-width: 1300px;
  background-color: white;
  border-radius: 0 0 12px 12px;
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.12);
  padding: 2rem;
  z-index: 1;
  border-top: 1px solid #eee;
  /* border: 2px solid red; */
`,_M=S.div`
  display: grid;
  grid-template-columns: 300px 1fr;
  gap: 2rem;
`,HM=S.div`
  border-right: 1px solid #eee;
  padding-right: 2rem;
`,GM=S.div`
  padding: 0.75rem 1rem;
  font-weight: 500;
  border-radius: 8px;
  cursor: pointer;
  color: ${({active:n})=>n?"#000080":"#333"};
  background-color: ${({active:n})=>n?"#f0f2f5":"transparent"};
  transition: all 0.2s ease-in-out;

  &:hover {
    background-color: #f0f2f5;
  }
`,IM=S.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`,qM=S.div``,FM=S.h3`
  font-size: 1rem;
  font-weight: 600;
  color: #777;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin: 0 0 1rem 0;
  border-bottom: 1px solid #eee;
  padding-bottom: 0.5rem;
`,YM=S(ui)`
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 0.75rem;
  border-radius: 8px;
  text-decoration: none;
  color: inherit;
  transition: background-color 0.2s ease;

  &:hover {
    background-color: #f8f9fa;
  }
`,XM=S.div`
  font-size: 1.5rem;
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
`,KM=S.div`
  h4 {
    margin: 0 0 0.25rem 0;
    font-weight: 600;
    color: #2d3748;
  }
  p {
    margin: 0;
    font-size: 0.85rem;
    color: #718096;
  }
`,$M=S(ui)`
  margin-top: 1rem;
  font-weight: 500;
  color: #000080;
  text-decoration: none;
  &:hover {
    text-decoration: underline;
  }
`,QM=S(gt.div)`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1001;
`,ZM=S(gt.div)`
  background-color: white;
  padding: 2.5rem;
  border-radius: 16px;
  width: 90%;
  max-width: 400px;
  position: relative;
  text-align: center;

  h3 {
    margin: 0 0 0.5rem 0;
    font-size: 1.5rem;
    color: #1a202c;
  }
  p {
    margin: 0 0 2rem 0;
    color: #4a5568;
  }
  input {
    width: 100%;
    padding: 0.8rem 1rem;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-size: 1rem;
    margin-bottom: 1rem;
  }
  .email-continue {
    width: 100%;
    padding: 0.8rem 1rem;
    border-radius: 8px;
    background-color: #000080;
    color: white;
    font-size: 1rem;
    font-weight: 500;
    border: none;
    cursor: pointer;
  }
`,JM=S.button`
  position: absolute;
  top: 1rem;
  right: 1rem;
  background: transparent;
  border: none;
  font-size: 2rem;
  cursor: pointer;
  color: #a0aec0;
`,Jy=S.button`
  width: 100%;
  padding: 0.8rem 1rem;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: 500;
  border: 1px solid #ddd;
  background-color: ${n=>n.google?"#F8F8F8":"#fff"};
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.75rem;
  margin-bottom: 1rem;
`,WM=S.div`
  display: flex;
  align-items: center;
  text-align: center;
  color: #a0aec0;
  margin: 1.5rem 0;
  font-size: 0.9rem;

  &::before,
  &::after {
    content: '';
    flex: 1;
    border-bottom: 1px solid #e2e8f0;
  }
  span {
    padding: 0 1rem;
  }
`,Jr=[{id:1,company:"HDFC Bank",title:"Deputy Manager Operational",qualification:"Graduation Any Stream 50%",ageLimit:"21-28",salary:"₹ 5,59,000/-",location:"Pan India",trainingFee:"₹ 3,50,000/- (Finance Facilities available for ₹ 2,57,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"4 Months"},{id:2,company:"HDFC Bank",title:"Assistant Manager Operational",qualification:"Graduation Any Stream 50%",ageLimit:"21-28",salary:"₹ 4,40,000/-",location:"Pan India",trainingFee:"₹ 2,50,000/- (Finance Facilities available for ₹ 1,50,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"45 Days"},{id:3,company:"HDFC Bank",title:"Relationship Manager",qualification:"Graduation Any Stream 50%",ageLimit:"21-32",salary:"₹ 2,08,000 - 3,00,000/-",location:"Pan India",trainingFee:"₹ 59,000/- (Application Fee: ₹ 68,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"7 Days"},{id:4,company:"HDFC Bank",title:"Sales officer CASA",qualification:"Graduation Any Stream 50%",ageLimit:"21-32",salary:"₹ 2,08,000 - 2,80,000/-",location:"Pan India",trainingFee:"₹ 29,000/- (Application Fee: ₹ 49,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"7 Days"},{id:5,company:"HDFC Life",title:"CA Manager Operational",qualification:"Graduation Any Stream 50%",ageLimit:"21-35",salary:"₹ 4,00,000/-",location:"Pan India",trainingFee:"₹ 1,50,000/- (Application Fee: ₹ 88,500/- + GST)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"4 Months"},{id:6,company:"HDFC Bank",title:"VRM Operational",qualification:"Graduation Any Stream 50%",ageLimit:"21-32",salary:"₹ 3,00,000 - 4,50,000/-",location:"Pan India",trainingFee:"₹ 99,000/- (Application Fee: ₹ 1,20,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"3 Months"},{id:7,company:"HDFC Bank",title:"Manager's Operational",qualification:"Graduation Any Stream 50%",ageLimit:"21-32",salary:"₹ 4,00,000 - 9,00,000/-",location:"Pan India",trainingFee:"₹ 1,50,000/- (Finance Facilities available)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"3-6 Months"},{id:8,company:"AXIS BANK",title:"Assistant Manager PO",qualification:"Graduation Any Stream 50%",ageLimit:"21-35",salary:"₹ 4,46,000/-",location:"Pan India",trainingFee:"₹ 2,50,000/- (Finance Facilities available for ₹ 2,80,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"4 Months"},{id:9,company:"AXIS BANK",title:"Assistant Manager PO Female",qualification:"Graduation Any Stream 60%",ageLimit:"21-30",salary:"₹ 4,42,000/-",location:"Pan India",trainingFee:"₹ 1,50,000/- (Finance Facilities available for ₹ 1,65,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"45 Days"},{id:10,company:"AXIS BANK",title:"Assistant Manager AM",qualification:"Graduation Any Stream 50%",ageLimit:"19-35",salary:"₹ 4,50,000/-",location:"Pan India",trainingFee:"₹ 2,00,000/- (Finance Facilities available for ₹ 2,35,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"4 Months"},{id:11,company:"AXIS Bank",title:"Business Development Executive",qualification:"Graduation Any Stream 50%",ageLimit:"18-30",salary:"₹ 2,28,000 - 3,36,000/-",location:"Pan India",trainingFee:"₹ 99,000/- (Application Fee: ₹ 65,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"7 Days"},{id:12,company:"SBI General Insurance",title:"Relationship Manager Branch Chanel",qualification:"Graduation Any Stream 50%",ageLimit:"21-27",salary:"₹ 3,50,000/-",location:"Pan India",trainingFee:"₹ 1,70,000/- (Application Fee: ₹ 99,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"1 Month"},{id:14,company:"Bank Of India Star Union",title:"Relationship Manager Branch Chanel",qualification:"Graduation Any Stream 2021-2024",ageLimit:"18-37",salary:"₹ 3,50,000/-",location:"Pan India",trainingFee:"₹ 1,70,000/- (Application Fee: ₹ 99,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"1 Month Online"},{id:15,company:"Mahindra Finance",title:"Business Executive Female Only",qualification:"Graduation Any Stream 50%",ageLimit:"19-28",salary:"₹ 4,70,000/-",location:"Pan India",trainingFee:"₹ 1,70,000/- (Application Fee: ₹ 42,000/- + GST)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"1 Month Online"},{id:16,company:"TATA AIG",title:"Channel Sales Manager",qualification:"Graduation Any Stream 50%",ageLimit:"21-28",salary:"₹ 4,00,000/-",location:"Pan India",trainingFee:"₹ 1,50,000/- (Application Fee: ₹ 99,000/- + GST)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"5 Months"},{id:17,company:"JANA Small Finance Bank",title:"Assistant Manager",qualification:"Graduation Any Stream 50%",ageLimit:"21-30",salary:"₹ 4,00,000/- + PLP",location:"Pan India",trainingFee:"₹ 1,95,000/- (Application Fee: ₹ 99,000/- + GST)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"1.5 Months"},{id:18,company:"AU Small Finance Bank",title:"Bank Officer",qualification:"Graduation Any Stream 50%",ageLimit:"21-32",salary:"₹ 3,50,000 - 7,00,000/-",location:"Pan India",trainingFee:"₹ 2,50,000/- (Application Fee: ₹ 2,00,000/- + GST Loan)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"3 Months"},{id:19,company:"Green Finch",title:"Credit Associate",qualification:"Graduation Any Stream 50%",ageLimit:"21-37",salary:"₹ 3,43,000/-",location:"Pan India",trainingFee:"₹ 1,65,000/- (Application Fee: ₹ 82,000/- + GST Loan)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"45 Days"},{id:20,company:"Bandhan Bank",title:"Branch Sales Executive",qualification:"Graduation Any Stream 50%",ageLimit:"21-31",salary:"₹ 2,38,000 - 3,16,000/-",location:"Pan India",trainingFee:"₹ 49,000/- (Application Fee: ₹ 90,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"15-30 Days"},{id:21,company:"Bandhan Bank",title:"VRM Operational",qualification:"Graduation Any Stream 50%",ageLimit:"21-32",salary:"₹ 3,00,000/-",location:"Pan India",trainingFee:"₹ 99,000/- (Application Fee: ₹ 1,20,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"1 Month Online"},{id:22,company:"ICICI Bank",title:"Deputy Manager",qualification:"Graduation Any Stream 50%",ageLimit:"19-27",salary:"₹ 5,02,000 - 5,50,000/- (Tab Free)",location:"Pan India",trainingFee:"₹ 3,50,000/- (Application Fee: ₹ 2,55,000/- + GST Loan)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"4 Months"},{id:23,company:"ICICI Bank",title:"Relationship Manager Branch Chanel",qualification:"Graduation Any Stream 50%",ageLimit:"18-26",salary:"₹ 3,00,000 - 3,50,000/-",location:"Pan India",trainingFee:"₹ 90,000/- (Application Fee: ₹ 65,000/- + GST)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"21 Days Online"},{id:24,company:"ICICI Bank",title:"Sales Executive",qualification:"Graduation Any Stream 50%",ageLimit:"18-30",salary:"₹ 2,28,000 - 3,36,000/-",location:"Pan India",trainingFee:"₹ 49,000/- (Application Fee: ₹ 49,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"15 Days Online"},{id:25,company:"Muthooth Finance",title:"CSE",qualification:"Graduation Any Stream",ageLimit:"18-28",salary:"₹ 1,80,000/-",location:"Pan India",trainingFee:"₹ 85,000/- (Application Fee: ₹ 49,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"7 Days Online"},{id:26,company:"Muthooth Fincorp",title:"BDE",qualification:"Graduation Any Stream",ageLimit:"18-28",salary:"₹ 2,50,000/-",location:"Pan India",trainingFee:"₹ 85,000/- (Application Fee: ₹ 65,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"7 Days Online"},{id:27,company:"Utkarsh Bank",title:"TCO & PCO",qualification:"12th Pass",ageLimit:"18-32",salary:"₹ 2,50,000 - 3,00,000/-",location:"Pan India",trainingFee:"₹ 90,000/-",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"1 Month (Lodging & Fooding included)"},{id:28,company:"Utkarsh Bank",title:"Cashier CSO",qualification:"Graduation Any Stream",ageLimit:"18-28",salary:"₹ 2,50,000/- (Room Free)",location:"Pan India",trainingFee:"₹ 90,000/-",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter (Fooding and Lodging Free)",trainingPeriod:"15-30 Days Online"},{id:29,company:"SAFEXPRESS Logistic",title:"Office Assistant",qualification:"12th Pass",ageLimit:"18-32",salary:"₹ 2,00,000 - 2,50,000/-",location:"Pan India",trainingFee:"₹ 75,000/- (Application Fee: ₹ 40,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"7-10 Days"},{id:30,company:"Max Hospital",title:"Frontline Billing Operational",qualification:"12th Pass",ageLimit:"18-32",salary:"₹ 2,40,000 - 3,00,000/-",location:"Pan India",trainingFee:"₹ 80,000/- (Application Fee: ₹ 40,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"2-4 Months"},{id:31,company:"Medanta Hospital",title:"Frontline Billing Operational",qualification:"12th Pass",ageLimit:"18-32",salary:"₹ 2,40,000 - 3,00,000/-",location:"Pan India",trainingFee:"₹ 80,000/- (Application Fee: ₹ 40,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"2-4 Months"},{id:32,company:"Paras Hospital",title:"Frontline Billing Operational",qualification:"12th Pass",ageLimit:"18-32",salary:"₹ 2,40,000 - 3,00,000/-",location:"Pan India",trainingFee:"₹ 80,000/- (Application Fee: ₹ 40,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"2-4 Months"},{id:33,company:"Kotak Mahindra Bank",title:"BRSM AS Deputy Manager",qualification:"Graduation Any Stream 50%",ageLimit:"21-27",salary:"₹ 5,00,000/-",location:"Pan India",trainingFee:"₹ 3,00,000/- (Application Fee: ₹ 2,80,000/- + GST)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"4 Months"},{id:34,company:"GLOBLE ACCA CMA",title:"Global CA (180 Countrys)",qualification:"12th & Graduation Any Stream",ageLimit:"18-45",salary:"₹ 8,00,000 - 24,00,000/-",location:"Global Work From Home",trainingFee:"₹ 1,50,000/- (Application Fee: ₹ 1,60,000 - 2,50,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"6-11 Months Online"},{id:35,company:"CITI, KPMG, EY, YES, IBM, WIPRO, INFOSYS",title:"Financial Planning, AM, Analyst",qualification:"Graduation Any Stream 50%",ageLimit:"18-32",salary:"₹ 4,00,000/-",location:"Pan India",trainingFee:"₹ 1,50,000/- (Application Fee: ₹ 1,20,000/- + GST)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"3-6 Months Online"},{id:36,company:"DCB, JP Morgan, ICICI, Barclays, HSBC",title:"Clearing Settlement, Onboarding Associate",qualification:"Graduation Any Stream 50%",ageLimit:"18-32",salary:"₹ 4,00,000 - 9,00,000/-",location:"Pan India",trainingFee:"₹ 2,00,000/- (Application Fee: ₹ 1,50,000/- + GST)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"3-6 Months"},{id:37,company:"Pay U, CITI BANK, GENPACT, YES BANK, WIPRO",title:"Investment Banking Associate",qualification:"Graduation Any Stream",ageLimit:"18-32",salary:"₹ 2,64,000/-",location:"Pan India",trainingFee:"₹ 85,000/- (Application Fee: ₹ 60,000/- + 18% GST)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"3-3 Months"},{id:38,company:"Lenskart (Non-Sales)",title:"Dispensing Optician, Store Executive",qualification:"12th Pass",ageLimit:"18-40",salary:"₹ 2,50,000 - 3,00,000/-",location:"Pan India",trainingFee:"₹ 90,000/- (Application Fee: ₹ 1,50,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"3-6 Months"},{id:39,company:"Domino's",title:"Store Executive",qualification:"12th Pass",ageLimit:"18-40",salary:"₹ 2,50,000 - 3,00,000/-",location:"Pan India",trainingFee:"₹ 90,000/- (Application Fee: ₹ 1,50,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"3-6 Months"},{id:40,company:"Radisson Blu Hotel",title:"Store Executive",qualification:"12th Pass",ageLimit:"18-40",salary:"₹ 2,50,000 - 3,00,000/-",location:"Pan India",trainingFee:"₹ 99,000/- (Application Fee: ₹ 1,50,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"3-6 Months"},{id:41,company:"Seairo Shipping Logistics",title:"Supply Chain Management Logistics",qualification:"BBA/MBA",ageLimit:"21-32",salary:"₹ 7,00,000/- (Stipend: 18,000 PM for 6 Months)",location:"Pan India",trainingFee:"₹ 1,70,000/- (Application Fee: ₹ 90,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"6 Month Working Training"},{id:42,company:"Seairo Shipping Logistics",title:"Supply Chain Management Logistics",qualification:"Graduation",ageLimit:"21-32",salary:"₹ 6,00,000/- (Stipend: 15,000 PM for 6 Months)",location:"Pan India",trainingFee:"₹ 1,50,000/- (Application Fee: ₹ 90,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"6 Month Working Training"},{id:43,company:"OM Logistics",title:"Billing Executive/Operations Coordinator",qualification:"12th/Graduation",ageLimit:"21-30",salary:"₹ 2,40,000 - 2,80,000/-",location:"Pan India",trainingFee:"₹ 99,000/- (Application Fee: ₹ 31,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"7 Days Online"},{id:44,company:"Axis Bank",title:"Deputy Managers",qualification:"Graduation Any Stream",ageLimit:"21-28",salary:"₹ 6,50,000 - 6,80,000/-",location:"Pan India",trainingFee:"₹ 3,50,000/- (Application Fee: ₹ 2,25,000/- + Loan 18% GST)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"3-4 Months"},{id:45,company:"Kotak Bank",title:"Relationship Managers",qualification:"Graduation Any Stream",ageLimit:"18-25.9",salary:"₹ 3,50,000/-",location:"Pan India",trainingFee:"₹ 99,000/- (Application Fee: ₹ 50,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"30 Days"},{id:46,company:"HDFC Bank",title:"Teller/Cashier/Handyman",qualification:"Graduation Any Stream (Female Only)",ageLimit:"21-28",salary:"₹ 3,00,000/-",location:"Pan India",trainingFee:"₹ 1,50,000/- (Application Fee: ₹ 65,000/- + 18% GST)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"5 Hours Online"},{id:47,company:"Air India",title:"Ramp Executive",qualification:"12th Pass",ageLimit:"18-30",salary:"₹ 23,000/- P/M",location:"Maharashtra",trainingFee:"₹ 2,50,000/-",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"1 Month Classroom (Gurugram)"},{id:48,company:"Air India",title:"Customer Service Associate",qualification:"Graduation Any Stream",ageLimit:"21-30",salary:"₹ 23,000/- P/M",location:"Maharashtra",trainingFee:"₹ 2,75,000/-",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"1. Delhi, 2. OJT"},{id:49,company:"Air India",title:"Load Control Agent",qualification:"Graduation Any Stream",ageLimit:"21-30",salary:"₹ 25,000/- P/M",location:"Maharashtra",trainingFee:"₹ 2,85,000/-",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"1. Delhi, 2. OJT"},{id:50,company:"Air India",title:"Flight Dispatch Associate",qualification:"Any Degree with Physics & Math",ageLimit:"21-30",salary:"₹ 28,000/- P/M",location:"Maharashtra",trainingFee:"₹ 2,90,000/-",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"1. Delhi, 2. OJT"},{id:51,company:"Air India",title:"TSM",qualification:"Graduation Any Stream",ageLimit:"21-30",salary:"₹ 75,000/- P/M",location:"Maharashtra",trainingFee:"₹ 3,50,000/-",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"2 Month Classroom, 3. OJT"},{id:52,company:"Himalaya Wellness",title:"TSM",qualification:"Graduation Any Stream",ageLimit:"21-35",salary:"₹ 3,00,000/- CTC",location:"Pan India",trainingFee:"₹ 99,000/- (Application Fee: ₹ 90,000/-)",selectionProcess:"1. Online Application, 2. Online Exam, 3. Online Interview, 4. Get Offer Letter",trainingPeriod:"2 Months"}],tj=()=>h.jsxs("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[h.jsx("circle",{cx:"11",cy:"11",r:"8"}),h.jsx("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"})]}),ej=()=>h.jsx("svg",{width:"20",height:"20",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:h.jsx("polyline",{points:"6 9 12 15 18 9"})}),nj=({job:n})=>{const[a,o]=E.useState(!1),l=c=>c.charAt(0);return h.jsx(gj,{layout:!0,children:h.jsxs(yj,{children:[h.jsxs(xj,{onClick:()=>o(!a),children:[h.jsx(vj,{children:l(n.company)}),h.jsxs(bj,{children:[h.jsx(Sj,{children:n.title}),h.jsxs(Aj,{children:[n.company," • ",n.location]})]}),h.jsx(wj,{animate:{rotate:a?180:0},children:h.jsx(ej,{})})]}),h.jsx(po,{children:a&&h.jsxs(Cj,{initial:{opacity:0,height:0},animate:{opacity:1,height:"auto"},exit:{opacity:0,height:0},transition:{duration:.3,ease:"easeInOut"},children:[h.jsxs(Tj,{children:[h.jsxs(ja,{children:[h.jsx(Oa,{children:"Salary"}),n.salary]}),h.jsxs(ja,{children:[h.jsx(Oa,{children:"Qualification"}),n.qualification]}),h.jsxs(ja,{children:[h.jsx(Oa,{children:"Age Limit"}),n.ageLimit]}),h.jsxs(ja,{children:[h.jsx(Oa,{children:"Training Period"}),n.trainingPeriod]}),h.jsxs(ja,{style:{gridColumn:"1 / -1"},children:[h.jsx(Oa,{children:"Training Fee"}),n.trainingFee]}),h.jsxs(ja,{style:{gridColumn:"1 / -1"},children:[h.jsx(Oa,{children:"Selection Process"}),n.selectionProcess]})]}),h.jsx(Ej,{href:"#",children:"Apply Now"})]})})]})})},ij=()=>{const[n,a]=E.useState(""),[o,l]=E.useState([]),[c,f]=E.useState([]),d=E.useMemo(()=>[...new Set(Jr.map(b=>b.company.split(",")[0].split(" ")[0]))],[Jr]),g=E.useMemo(()=>[...new Set(Jr.map(b=>b.qualification.includes("12th")?"12th Pass":"Graduation"))],[Jr]),p=b=>{const{value:C,checked:O}=b.target;l(z=>O?[...z,C]:z.filter(P=>P!==C))},m=b=>{const{value:C,checked:O}=b.target;f(z=>O?[...z,C]:z.filter(P=>P!==C))},x=()=>{a(""),l([]),f([])},A=E.useMemo(()=>Jr.filter(b=>{const C=n===""||b.title.toLowerCase().includes(n.toLowerCase())||b.company.toLowerCase().includes(n.toLowerCase()),O=o.length===0||o.some(P=>b.company.toLowerCase().includes(P.toLowerCase())),z=c.length===0||c.some(P=>P==="12th Pass"?b.qualification.includes("12th"):P==="Graduation"?b.qualification.includes("Graduation"):!1);return C&&O&&z}),[n,o,c]);return h.jsxs(aj,{children:[h.jsxs(rj,{children:[h.jsx(oj,{children:"Find Your Next Career"}),h.jsx(lj,{children:"Explore our curated list of job openings and find your perfect match."})]}),h.jsxs(sj,{children:[h.jsxs(cj,{children:[h.jsxs(Of,{children:[h.jsx(Df,{children:"Search"}),h.jsxs(uj,{children:[h.jsx(dj,{children:h.jsx(tj,{})}),h.jsx(fj,{type:"text",placeholder:"Job title or company...",value:n,onChange:b=>a(b.target.value)})]})]}),h.jsxs(Of,{children:[h.jsx(Df,{children:"Industry"}),h.jsx(Wy,{children:d.map(b=>h.jsxs(t1,{children:[h.jsx(e1,{type:"checkbox",value:b,checked:o.includes(b),onChange:p}),b]},b))})]}),h.jsxs(Of,{children:[h.jsx(Df,{children:"Qualification"}),h.jsx(Wy,{children:g.map(b=>h.jsxs(t1,{children:[h.jsx(e1,{type:"checkbox",value:b,checked:c.includes(b),onChange:m}),b]},b))})]}),h.jsx(hj,{onClick:x,children:"Reset Filters"})]}),h.jsxs(mj,{children:[h.jsxs(pj,{children:[A.length," Jobs Found"]}),A.length>0?A.map(b=>h.jsx(nj,{job:b},b.id)):h.jsx(Mj,{children:"No job openings match your criteria."})]})]})]})},aj=S.div`
  font-family:
    -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  background-color: #f7f8fc;
  min-height: 100vh;
  padding: 2rem;
`,rj=S.header`
  text-align: center;
  margin-bottom: 2.5rem;
`,oj=S.h1`
  font-size: 2.5rem;
  font-weight: 700;
  color: #1a202c;
  margin: 0 0 0.5rem 0;
`,lj=S.p`
  font-size: 1.1rem;
  color: #4a5568;
  max-width: 600px;
  margin: 0 auto;
`,sj=S.div`
  display: grid;
  grid-template-columns: 280px 1fr;
  gap: 2rem;
  max-width: 1400px;
  margin: 0 auto;
  align-items: flex-start;

  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
  }
`,cj=S.aside`
  background-color: #ffffff;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
  position: sticky;
  top: 2rem;
`,Of=S.div`
  margin-bottom: 2rem;
  &:last-child {
    margin-bottom: 0;
  }
`,Df=S.h3`
  font-size: 1.1rem;
  font-weight: 600;
  color: #2d3748;
  margin: 0 0 1rem 0;
`,uj=S.div`
  position: relative;
`,fj=S.input`
  width: 100%;
  padding: 0.7rem 1rem 0.7rem 2.5rem;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  font-size: 0.95rem;
  color: #2d3748;
  transition: all 0.2s ease;
  &:focus {
    outline: none;
    border-color: #003380;
    box-shadow: 0 0 0 2px rgba(0, 51, 128, 0.2);
  }
`,dj=S.div`
  position: absolute;
  top: 50%;
  left: 0.8rem;
  transform: translateY(-50%);
  color: #a0aec0;
`,Wy=S.div`
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
`,t1=S.label`
  display: flex;
  align-items: center;
  cursor: pointer;
  font-size: 0.95rem;
  color: #4a5568;
`,e1=S.input`
  margin-right: 0.75rem;
  height: 18px;
  width: 18px;
  accent-color: #003380;
`,hj=S.button`
  width: 100%;
  padding: 0.7rem;
  background-color: #e2e8f0;
  color: #4a5568;
  border: none;
  border-radius: 8px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
  &:hover {
    background-color: #cbd5e0;
  }
`,mj=S.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`,pj=S.div`
  background-color: #fff;
  padding: 1rem 1.5rem;
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
  margin-bottom: 0.5rem;
  font-weight: 500;
  color: #2d3748;
`,gj=S(gt.div)``,yj=S.div`
  background-color: #ffffff;
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
  border: 1px solid #e2e8f0;
  overflow: hidden;
  transition: box-shadow 0.3s ease;
  &:hover {
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
  }
`,xj=S.div`
  padding: 1.5rem;
  display: grid;
  grid-template-columns: auto 1fr auto;
  align-items: center;
  gap: 1rem;
  cursor: pointer;
`,vj=S.div`
  width: 50px;
  height: 50px;
  border-radius: 8px;
  background-color: #f7f8fc;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 600;
  font-size: 1.2rem;
  color: #003380;
  border: 1px solid #e2e8f0;
`,bj=S.div``,Sj=S.h2`
  font-size: 1.2rem;
  font-weight: 600;
  color: #1a202c;
  margin: 0 0 0.25rem 0;
`,Aj=S.p`
  font-size: 0.95rem;
  color: #4a5568;
  margin: 0;
`,wj=S(gt.div)`
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background-color: #f7f8fc;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #4a5568;
`,Cj=S(gt.div)`
  padding: 0 1.5rem 1.5rem 1.5rem;
  border-top: 1px solid #e2e8f0;
  color: #2d3748;
`,Tj=S.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.25rem;
  padding-top: 1.5rem;
`,ja=S.div`
  font-size: 0.95rem;
  line-height: 1.5;
`,Oa=S.strong`
  display: block;
  color: #003380;
  font-weight: 600;
  margin-bottom: 0.25rem;
`,Ej=S.a`
  display: inline-block;
  margin-top: 1.5rem;
  padding: 0.7rem 1.5rem;
  background-color: #003380;
  color: white;
  text-decoration: none;
  font-weight: 500;
  border-radius: 8px;
  transition: all 0.3s ease;
  &:hover {
    background-color: #001f5a;
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(0, 51, 128, 0.2);
  }
`,Mj=S.div`
  text-align: center;
  padding: 3rem;
  color: #718096;
  background-color: #fff;
  border-radius: 12px;
`,jj=S.section`
  background-color: #f8f9fa;
  padding: 6rem 2rem;
  font-family:
    -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
`,Oj=S.div`
  max-width: 1200px;
  margin: 0 auto;
`,Dj=S(gt.div)`
  text-align: center;
  margin-bottom: 2rem;
`,Rj=S.h2`
  font-size: 2.5rem;
  font-weight: 700;
  color: #000080;
  margin: 0;
`,Lj=S(gt.p)`
  font-size: 1.1rem;
  color: #4a5568;
  max-width: 800px;
  margin: 1rem auto 4rem auto;
  line-height: 1.7;
`,Bj=S.div`
  text-align: center;
`,zj=S.h3`
  font-size: 1.2rem;
  font-weight: 500;
  color: #718096;
  margin-bottom: 2.5rem;
  text-transform: uppercase;
  letter-spacing: 1px;
`,kj=S(gt.div)`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
  gap: 3rem;
`,Pj=S(gt.div)`
  flex-shrink: 0;

  img {
    height: 40px; // Unified height for logos
    max-width: 150px;
    filter: grayscale(100%) opacity(0.6);
    transition: all 0.3s ease;
  }

  &:hover img {
    filter: grayscale(0%) opacity(1);
    transform: scale(1.1);
  }
`,Vj=[{name:"Partner 1",logo:"https://placehold.co/300x100/f0f0f0/999?text=Partner+A"},{name:"Partner 2",logo:"https://placehold.co/300x100/f0f0f0/999?text=Partner+B"},{name:"Partner 3",logo:"https://placehold.co/300x100/f0f0f0/999?text=Partner+C"},{name:"Partner 4",logo:"https://placehold.co/300x100/f0f0f0/999?text=Partner+D"},{name:"Partner 5",logo:"https://placehold.co/300x100/f0f0f0/999?text=Partner+E"}],Uj={hidden:{opacity:0},visible:{opacity:1,transition:{staggerChildren:.1,delayChildren:.2}}},Nj={hidden:{y:20,opacity:0},visible:{y:0,opacity:1,transition:{duration:.5,ease:"easeOut"}}},_j=()=>h.jsx(jj,{children:h.jsxs(Oj,{children:[h.jsx(Dj,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.5},transition:{duration:.6},children:h.jsx(Rj,{children:"About Career Counselling Corporation of India"})}),h.jsx(Lj,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.5},transition:{duration:.6,delay:.2},children:"With a rich legacy of knowledge and learning, the Career Counselling Corporation of India (CCCI) is one of the nation's most recognized brands in professional development. We are a leading conglomerate with a strong leadership presence across all sectors and verticals that are powering India’s transformation into a knowledge economy. Trusted by millions, CCCI prides itself in leveraging its intellectual capital and unmatched credibility to acquire, create, disseminate, and apply knowledge to facilitate economic and social development globally."}),h.jsxs(Bj,{children:[h.jsx(zj,{children:"Our Esteemed Partners & Collaborators"}),h.jsx(kj,{variants:Uj,initial:"hidden",whileInView:"visible",viewport:{once:!0,amount:.2},children:Vj.map((n,a)=>h.jsx(Pj,{variants:Nj,children:h.jsx("img",{src:n.logo,alt:n.name})},a))})]})]})}),Hj=()=>h.jsx("svg",{width:"28",height:"28",viewBox:"0 0 24 24",fill:"currentColor",children:h.jsx("path",{d:"M8 5v14l11-7z"})}),Gj=()=>h.jsxs("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[h.jsx("rect",{x:"2",y:"7",width:"20",height:"14",rx:"2",ry:"2"}),h.jsx("path",{d:"M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"})]}),Ij=()=>h.jsx("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:h.jsx("polygon",{points:"12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"})}),qj=()=>h.jsxs("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[h.jsx("path",{d:"M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"}),h.jsx("circle",{cx:"9",cy:"7",r:"4"}),h.jsx("path",{d:"M23 21v-2a4 4 0 0 0-3-3.87"}),h.jsx("path",{d:"M16 3.13a4 4 0 0 1 0 7.75"})]}),Fj=S.section`
  background-color: #f8f9fa;
  padding: 6rem 2rem;
  font-family:
    -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  position: relative;
  overflow: hidden;

  // Subtle background decorative shape
  &::before {
    content: '';
    position: absolute;
    top: -10%;
    right: -15%;
    width: 400px;
    height: 400px;
    background: radial-gradient(circle, rgba(0, 51, 128, 0.05), transparent 70%);
    border-radius: 50%;
    z-index: 0;
  }
`,Yj=S.div`
  max-width: 1200px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: 1.1fr 0.9fr; // Give slightly more space to text
  align-items: center;
  gap: 3rem;
  position: relative;
  z-index: 1;

  @media (max-width: 992px) {
    grid-template-columns: 1fr;
    gap: 3rem;
    text-align: center;
  }
`,Xj=S.div``,Kj=S.p`
  color: #4a5568;
  font-size: 0.9rem;
  margin-bottom: 1rem;
  a {
    color: #003380;
    text-decoration: none;
    &:hover {
      text-decoration: underline;
    }
  }
`,$j=S(gt.h1)`
  font-size: 3rem; // Reduced font size
  font-weight: 700;
  color: #000080;
  margin: 0 0 1.5rem 0;
  line-height: 1.25;
`,Qj=S(gt.p)`
  font-size: 1.05rem; // Reduced font size
  color: #4a5568;
  line-height: 1.7;
  max-width: 500px;
  margin-bottom: 2.5rem;
  @media (max-width: 992px) {
    margin-left: auto;
    margin-right: auto;
  }
`,Zj=S.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: 1rem;
`,Rf=S(gt.div)`
  background-color: #ffffff;
  padding: 1rem 1.25rem;
  border-radius: 12px;
  border: 1px solid #e2e8f0;
  display: flex;
  align-items: center;
  gap: 1rem;
`,Lf=S.div`
  color: #003380;
`,Bf=S.div``,zf=S.div`
  font-size: 1.5rem; // Reduced font size
  font-weight: 700;
  color: #1a202c;
`,kf=S.div`
  font-size: 0.85rem; // Reduced font size
  color: #718096;
`,Jj=S(gt.div)`
  position: relative;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 20px 40px rgba(0, 31, 90, 0.15);
  aspect-ratio: 16 / 10; // Enforces a landscape aspect ratio

  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
  }
`,Wj=S.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(to top, rgba(0, 0, 0, 0.6), transparent 60%);
  display: flex;
  align-items: flex-end;
  padding: 1.5rem;
`,tO=S.div`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 70px;
  height: 70px;
  border-radius: 50%;
  background-color: rgba(255, 255, 255, 0.9);
  color: #003380;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.3s ease;
  backdrop-filter: blur(5px);

  &:hover {
    transform: translate(-50%, -50%) scale(1.1);
    background-color: white;
  }
`,eO=S.div`
  color: white;
`,nO=S.h3`
  font-size: 1.1rem;
  font-weight: 600;
  margin: 0;
  text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5);
`,iO=S.p`
  font-size: 0.9rem;
  margin: 0.25rem 0 0 0;
  opacity: 0.9;
  text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5);
`,aO={hidden:{opacity:0},visible:{opacity:1,transition:{staggerChildren:.15}}},Wr={hidden:{y:20,opacity:0},visible:{y:0,opacity:1,transition:{duration:.6,ease:"easeOut"}}},rO=()=>h.jsx(Fj,{children:h.jsxs(Yj,{children:[h.jsx(Xj,{children:h.jsxs(gt.div,{variants:aO,initial:"hidden",animate:"visible",children:[h.jsxs(gt.div,{variants:Wr,children:[h.jsxs(Kj,{children:[h.jsx("a",{href:"/",children:"Home"})," > About Us"]}),h.jsx($j,{children:"Guiding Your Path to Professional Success."}),h.jsx(Qj,{children:"Learning has the power to mould and transform. Be a lifelong learner and fulfill all your career aspirations with the Career Counselling Corporation of India, a premier platform that equips you with the knowledge, skills, and confidence to thrive in a competitive world."})]}),h.jsxs(Zj,{children:[h.jsxs(Rf,{variants:Wr,children:[h.jsx(Lf,{children:h.jsx(Ij,{})}),h.jsxs(Bf,{children:[h.jsx(zf,{children:"95%+"}),h.jsx(kf,{children:"Success Rate"})]})]}),h.jsxs(Rf,{variants:Wr,children:[h.jsx(Lf,{children:h.jsx(Gj,{})}),h.jsxs(Bf,{children:[h.jsx(zf,{children:"500+"}),h.jsx(kf,{children:"Industry Partners"})]})]}),h.jsxs(Rf,{variants:Wr,children:[h.jsx(Lf,{children:h.jsx(qj,{})}),h.jsxs(Bf,{children:[h.jsx(zf,{children:"1.75L+"}),h.jsx(kf,{children:"Careers Guided"})]})]})]})]})}),h.jsxs(Jj,{variants:Wr,initial:"hidden",animate:"visible",children:[h.jsx("img",{src:"https://placehold.co/800x500/a29bfe/ffffff?text=Our+Story",alt:"Founder of Career Counselling Corporation of India"}),h.jsxs(Wj,{children:[h.jsx(tO,{children:h.jsx(Hj,{})}),h.jsxs(eO,{children:[h.jsx(nO,{children:"Director's Name"}),h.jsx(iO,{children:"Executive Director, CCCI"})]})]})]})]})}),oO=()=>h.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",width:"32",height:"32",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[h.jsx("path",{d:"M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"}),h.jsx("path",{d:"M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"})]}),lO=()=>h.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",width:"32",height:"32",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[h.jsx("path",{d:"M14 17l-3.5-3.5a1 1 0 0 1 0-1.4l3.5-3.5"}),h.jsx("path",{d:"M18 14H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h13l4 4-4 4z"})]}),sO=()=>h.jsx("svg",{xmlns:"http://www.w3.org/2000/svg",width:"32",height:"32",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:h.jsx("path",{d:"M20 16V7a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v9m16 0H4m16 0l-2 5H6l-2-5"})}),cO=()=>h.jsx("svg",{xmlns:"http://www.w3.org/2000/svg",width:"32",height:"32",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:h.jsx("path",{d:"M6 3h12M6 8h12M4 13h16M4 18h16M11 21V3"})}),uO=()=>h.jsx("svg",{xmlns:"http://www.w3.org/2000/svg",width:"32",height:"32",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:h.jsx("path",{d:"M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"})}),fO=S.section`
  background-color: #ffffff;
  padding: 6rem 2rem;
  font-family:
    -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
`,dO=S(gt.div)`
  text-align: center;
  margin-bottom: 4rem;
`,hO=S.h2`
  font-size: 2.5rem;
  font-weight: 700;
  color: #000080;
  margin: 0;
`,mO=S.div`
  max-width: 1200px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
`,pO=S(gt.div)`
  background-color: #f8f9fa;
  border: 1px solid #e2e8f0;
  border-radius: 16px;
  padding: 2.5rem 2rem;
  text-align: center;
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-10px);
    box-shadow: 0 15px 30px rgba(0, 51, 128, 0.1);
    border-color: #003380;
  }
`,gO=S.div`
  width: 70px;
  height: 70px;
  margin: 0 auto 1.5rem auto;
  border-radius: 50%;
  background-color: #003380;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 5px 15px rgba(0, 51, 128, 0.2);
`,yO=S.h3`
  font-size: 1.2rem;
  font-weight: 600;
  color: #1a202c;
  margin: 0 0 0.75rem 0;
`,xO=S.p`
  font-size: 0.95rem;
  color: #4a5568;
  line-height: 1.6;
  margin: 0;
`,vO=[{icon:h.jsx(oO,{}),title:"Expert-Curated Curriculum",description:"Well-created and curated curriculum delivered by best-in-class faculty and industry professionals."},{icon:h.jsx(lO,{}),title:"Strong Hiring Network",description:"A robust network of academic and corporate hiring partners to connect you with premier opportunities."},{icon:h.jsx(sO,{}),title:"Advanced Tech Platform",description:"A modern, seamless Direct-to-Device (D2D) learning platform for an accessible and engaging experience."},{icon:h.jsx(cO,{}),title:"Flexible & Fair Pricing",description:"Value-for-money pricing structures coupled with flexible finance options to support your journey."},{icon:h.jsx(uO,{}),title:"Legacy of Trust",description:"Built upon a foundation of decades of experience in career counselling and educational excellence."}],bO={hidden:{opacity:0},visible:{opacity:1,transition:{staggerChildren:.1,delayChildren:.2}}},SO={hidden:{y:30,opacity:0},visible:{y:0,opacity:1,transition:{duration:.5,ease:"easeOut"}}},AO=()=>h.jsxs(fO,{children:[h.jsx(dO,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.5},transition:{duration:.6},children:h.jsx(hO,{children:"How We Deliver Excellence"})}),h.jsx(mO,{as:gt.div,variants:bO,initial:"hidden",whileInView:"visible",viewport:{once:!0,amount:.2},children:vO.map((n,a)=>h.jsxs(pO,{variants:SO,children:[h.jsx(gO,{children:n.icon}),h.jsx(yO,{children:n.title}),h.jsx(xO,{children:n.description})]},a))})]}),wO=()=>h.jsx("svg",{xmlns:"http://www.w3.org/2000/svg",width:"20",height:"20",viewBox:"0 0 24 24",fill:"currentColor",children:h.jsx("path",{d:"M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"})}),CO=S.section`
  background-color: #ffffff;
  padding: 6rem 2rem;
  font-family:
    -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
`,TO=S(gt.div)`
  text-align: center;
  margin-bottom: 4rem;
`,EO=S.h2`
  font-size: 2.5rem;
  font-weight: 700;
  color: #000080;
  margin: 0;
`,MO=S(gt.div)`
  max-width: 1200px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2.5rem;
`,jO=S(gt.div)`
  text-align: center;
  display: flex;
  flex-direction: column;
  align-items: center;
`,OO=S.div`
  width: 160px;
  height: 160px;
  border-radius: 50%;
  margin-bottom: 1.5rem;
  position: relative;
  box-shadow: 0 10px 25px rgba(0, 51, 128, 0.1);
  transition: transform 0.3s ease;

  img {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    object-fit: cover;
  }

  &:hover {
    transform: scale(1.05);
  }
`,DO=S.a`
  position: absolute;
  bottom: 5px;
  right: 5px;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background-color: #003380;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  text-decoration: none;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
  transition: all 0.3s ease;

  &:hover {
    background-color: #d9534f;
    transform: scale(1.1);
    color: white;
  }
`,RO=S.h3`
  font-size: 1.25rem;
  font-weight: 600;
  color: #1a202c;
  margin: 0 0 0.5rem 0;
`,LO=S.p`
  font-size: 0.95rem;
  color: #4a5568;
  line-height: 1.5;
  margin: 0 0 1rem 0;
  min-height: 40px; // To align cards with different title lengths
`,BO=S.a`
  font-size: 0.9rem;
  font-weight: 500;
  color: #003380;
  text-decoration: none;

  &:hover {
    text-decoration: underline;
  }
`,zO=[{name:"Priya Sharma",title:"President & CEO",img:"https://placehold.co/200x200/E6E6FA/333?text=PS"},{name:"Rohan Gupta",title:"President, Enterprise & Skilling Business, CFO",img:"https://placehold.co/200x200/D8BFD8/333?text=RG"},{name:"Dr. Alisha Khan",title:"Chief People Officer & Head - People, Places & HR",img:"https://placehold.co/200x200/DDA0DD/333?text=AK"},{name:"Vikram Singh",title:"Chief Digital Strategy Officer",img:"https://placehold.co/200x200/DA70D6/333?text=VS"},{name:"Sunita Reddy",title:"Business Head, Platforms",img:"https://placehold.co/200x200/BA55D3/333?text=SR"},{name:"Anil Mehta",title:"Vice President - Finance & Accounts",img:"https://placehold.co/200x200/9932CC/333?text=AM"}],kO={hidden:{opacity:0},visible:{opacity:1,transition:{staggerChildren:.1,delayChildren:.2}}},PO={hidden:{y:20,opacity:0},visible:{y:0,opacity:1,transition:{duration:.5,ease:"easeOut"}}},VO=()=>h.jsxs(CO,{children:[h.jsx(TO,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.5},transition:{duration:.6},children:h.jsx(EO,{children:"The Flag Bearers"})}),h.jsx(MO,{variants:kO,initial:"hidden",whileInView:"visible",viewport:{once:!0,amount:.2},children:zO.map((n,a)=>h.jsxs(jO,{variants:PO,children:[h.jsxs(OO,{children:[h.jsx("img",{src:n.img,alt:`Portrait of ${n.name}`}),h.jsx(DO,{href:"#",target:"_blank",rel:"noopener noreferrer","aria-label":`LinkedIn profile of ${n.name}`,children:h.jsx(wO,{})})]}),h.jsx(RO,{children:n.name}),h.jsx(LO,{children:n.title}),h.jsx(BO,{href:"#",children:"Know More →"})]},a))})]}),UO=()=>h.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[h.jsx("path",{d:"M6 12L2 18l6-4m14-6l-6 4-4-6 4-4 6 6zM2 6l4 4"}),h.jsx("path",{d:"M12 12l6 6"})]}),NO=()=>h.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[h.jsx("circle",{cx:"12",cy:"12",r:"10"}),h.jsx("circle",{cx:"12",cy:"12",r:"6"}),h.jsx("circle",{cx:"12",cy:"12",r:"2"})]}),_O=()=>h.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[h.jsx("path",{d:"M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"}),h.jsx("path",{d:"m9 12 2 2 4-4"})]}),HO=()=>h.jsx("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:h.jsx("path",{d:"M9 18h6M10 22h4M12 2a7 7 0 0 0-7 7c0 2.05.84 3.9 2.15 5.19L6 16h12l-1.15-1.81A6.98 6.98 0 0 0 19 9a7 7 0 0 0-7-7z"})}),GO=()=>h.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[h.jsx("path",{d:"M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.72"}),h.jsx("path",{d:"M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.72-1.72"})]}),IO=S.section`
  background-color: #f8f9fa;
  padding: 6rem 2rem;
  font-family:
    -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  position: relative;
  overflow: hidden;
`,qO=S.div`
  max-width: 1100px;
  margin: 0 auto;
  text-align: center;
`,FO=S(gt.div)`
  margin-bottom: 4rem;
`,YO=S.h2`
  font-size: 2.5rem;
  font-weight: 700;
  color: #000080;
  margin: 0 0 1rem 0;
`,XO=S.p`
  font-size: 1.1rem;
  color: #4a5568;
  max-width: 700px;
  margin: 0 auto;
  line-height: 1.6;
`,KO=S(gt.div)`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
  justify-content: center;
`,$O=S(gt.div)`
  background-color: #ffffff;
  border-radius: 12px;
  padding: 2rem;
  border: 1px solid #e2e8f0;
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-8px);
    box-shadow: 0 12px 25px rgba(0, 51, 128, 0.08);
  }
`,QO=S.div`
  color: #d9534f; // Red accent color
  margin-bottom: 1rem;
`,ZO=S.h3`
  font-size: 1.1rem;
  font-weight: 600;
  color: #1a202c;
  margin: 0;
`,JO=[{icon:h.jsx(UO,{}),text:"Speed with Execution Excellence"},{icon:h.jsx(NO,{}),text:"Learner Centricity"},{icon:h.jsx(_O,{}),text:"Integrity"},{icon:h.jsx(HO,{}),text:"Innovation Culture"},{icon:h.jsx(GO,{}),text:"Enduring Engagement"}],WO={hidden:{opacity:0},visible:{opacity:1,transition:{staggerChildren:.1,delayChildren:.3}}},t9={hidden:{y:20,opacity:0},visible:{y:0,opacity:1,transition:{duration:.5,ease:"easeOut"}}},e9=()=>h.jsx(IO,{children:h.jsxs(qO,{children:[h.jsxs(FO,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0,amount:.5},transition:{duration:.6},children:[h.jsx(YO,{children:"Our Vision & Values"}),h.jsx(XO,{children:"Fulfilling the aspirations of millions of learners by making excellence accessible through learner-centric innovations and global collaborations."})]}),h.jsx(KO,{variants:WO,initial:"hidden",whileInView:"visible",viewport:{once:!0,amount:.2},children:JO.map((n,a)=>h.jsxs($O,{variants:t9,children:[h.jsx(QO,{children:n.icon}),h.jsx(ZO,{children:n.text})]},a))})]})});function n9(){return h.jsxs(h.Fragment,{children:[h.jsx(rO,{}),h.jsx(AO,{}),h.jsx(e9,{}),h.jsx(VO,{}),h.jsx(_j,{}),h.jsx(Cv,{})]})}const i9=[{id:"exp1",text:"Fresh Graduate"},{id:"exp2",text:"0-2 Years"},{id:"exp3",text:"2-5 Years"},{id:"exp4",text:"5-10 Years"},{id:"exp5",text:"10-15 Years"}],a9=[{id:"obj1",text:"Programmes with Placement Assistance"},{id:"obj2",text:"Upskilling for Promotion"},{id:"obj3",text:"Career Change / Transition"},{id:"obj4",text:"Domain Specialization"}],r9=[{id:"int1",text:"Technology & Analytics"},{id:"int2",text:"Banking & Finance"},{id:"int3",text:"Management & Leadership"},{id:"int4",text:"Logistics & Supply Chain"},{id:"int5",text:"Healthcare Management"},{id:"int6",text:"Digital Marketing"}],o9=[{id:"c1",title:"Executive Programme in Business Management",university:"IIM Calcutta"},{id:"c2",title:"Advanced Certificate in Data Science",university:"IIT Madras"},{id:"c3",title:"Professional Certificate in Fintech",university:"IIM Kozhikode"},{id:"c4",title:"Digital Marketing & Analytics",university:"ISB Hyderabad"}],l9=S.div`
  font-family:
    -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  background-color: #f8f9fa;
  min-height: 100vh;
  padding: 3rem 2rem;
  display: flex;
  justify-content: center;
  align-items: flex-start;
`,s9=S.div`
  width: 100%;
  max-width: 800px;
  background-color: #ffffff;
  border-radius: 16px;
  box-shadow: 0 10px 35px rgba(0, 0, 0, 0.08);
  padding: 2.5rem;
`,c9=S.div`
  margin-bottom: 2.5rem;
`,u9=S.div`
  height: 4px;
  background-color: #e2e8f0;
  border-radius: 2px;
  position: relative;
`,f9=S(gt.div)`
  height: 100%;
  background-color: #003380;
  border-radius: 2px;
  position: absolute;
`,d9=S.div`
  display: flex;
  justify-content: space-between;
  position: relative;
  top: -16px;
`,h9=S.div`
  width: 28px;
  height: 28px;
  border-radius: 50%;
  background-color: ${({active:n})=>n?"#003380":"#e2e8f0"};
  border: 4px solid #ffffff;
  transition: background-color 0.3s ease;
  position: relative;
`,m9=S.span`
  position: absolute;
  top: 35px;
  left: 50%;
  transform: translateX(-50%);
  font-size: 0.85rem;
  color: ${({active:n})=>n?"#1a202c":"#a0aec0"};
  font-weight: 500;
  white-space: nowrap;
`,Pf=S(gt.div)`
  text-align: center;
`,Jl=S.h2`
  font-size: 1.75rem;
  font-weight: 600;
  color: #1a202c;
  margin: 0 0 2rem 0;
`,Vf=S.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1.5rem;
`,Uf=S(gt.div)`
  padding: 1.5rem;
  border: 2px solid ${({selected:n})=>n?"#003380":"#e2e8f0"};
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.2s ease;
  font-weight: 500;
  color: ${({selected:n})=>n?"#003380":"#2d3748"};
  box-shadow: ${({selected:n})=>n?"0 4px 15px rgba(0, 51, 128, 0.1)":"none"};

  &:hover {
    transform: translateY(-5px);
    border-color: #003380;
  }
`,p9=S.div`
  display: flex;
  justify-content: space-between;
  margin-top: 3rem;
  border-top: 1px solid #e2e8f0;
  padding-top: 1.5rem;
`,Wl=S.button`
  padding: 0.8rem 2rem;
  border-radius: 8px;
  font-weight: 500;
  font-size: 1rem;
  cursor: pointer;
  transition: all 0.2s ease;
  border: 1px solid transparent;

  &.primary {
    background-color: #003380;
    color: white;
    &:disabled {
      background-color: #a0aec0;
      cursor: not-allowed;
    }
    &:hover:not(:disabled) {
      background-color: #001f5a;
    }
  }

  &.secondary {
    background-color: transparent;
    color: #4a5568;
    border-color: #e2e8f0;
    &:hover {
      background-color: #f7f8fc;
    }
  }
`,g9=S(gt.div)`
  text-align: center;
`,y9=S.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.5rem;
  margin-top: 2rem;
  text-align: left;
`,x9=S.div`
  background-color: #f8f9fa;
  padding: 1.5rem;
  border-radius: 12px;
  border: 1px solid #e2e8f0;
`,v9=S.h3`
  font-size: 1.2rem;
  font-weight: 600;
  color: #003380;
  margin: 0 0 0.5rem 0;
`,b9=S.p`
  font-size: 1rem;
  color: #4a5568;
  margin: 0;
`,S9=()=>{const[n,a]=E.useState(1),[o,l]=E.useState({experience:null,objective:null,interest:null}),c=E.useMemo(()=>(n-1)/3*100,[n]),f=["Experience","Objective","Interests","Result"],d=(b,C)=>{l(O=>({...O,[b]:C}))},g=()=>a(b=>b<4?b+1:b),p=()=>a(b=>b>1?b-1:b),m=()=>{l({experience:null,objective:null,interest:null}),a(1)},x=()=>n===1?!o.experience:n===2?!o.objective:n===3?!o.interest:!1,A=()=>{switch(n){case 1:return h.jsxs(Pf,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},children:[h.jsx(Jl,{children:"What is your work experience?"}),h.jsx(Vf,{children:i9.map(b=>h.jsx(Uf,{selected:o.experience===b.id,onClick:()=>d("experience",b.id),children:b.text},b.id))})]},1);case 2:return h.jsxs(Pf,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},children:[h.jsx(Jl,{children:"What is your primary learning objective?"}),h.jsx(Vf,{children:a9.map(b=>h.jsx(Uf,{selected:o.objective===b.id,onClick:()=>d("objective",b.id),children:b.text},b.id))})]},2);case 3:return h.jsxs(Pf,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},children:[h.jsx(Jl,{children:"What are your areas of interest?"}),h.jsx(Vf,{children:r9.map(b=>h.jsx(Uf,{selected:o.interest===b.id,onClick:()=>d("interest",b.id),children:b.text},b.id))})]},3);case 4:return h.jsxs(g9,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},children:[h.jsx(Jl,{children:"Your Recommended Courses"}),h.jsx("p",{children:"Based on your selections, here are some courses you might like."}),h.jsx(y9,{children:o9.map(b=>h.jsxs(x9,{children:[h.jsx(v9,{children:b.title}),h.jsx(b9,{children:b.university})]},b.id))})]},4);default:return null}};return h.jsx(l9,{children:h.jsxs(s9,{children:[h.jsxs(c9,{children:[h.jsx(u9,{children:h.jsx(f9,{style:{width:`${c}%`}})}),h.jsx(d9,{children:f.map((b,C)=>h.jsx(h9,{active:n>C,children:h.jsx(m9,{active:n>C,children:b})},C))})]}),h.jsx(po,{mode:"wait",children:A()}),h.jsxs(p9,{children:[n>1&&n<4&&h.jsx(Wl,{className:"secondary",onClick:p,children:"Back"}),n===4&&h.jsx(Wl,{className:"secondary",onClick:m,children:"Start Over"}),n<3&&h.jsx(Wl,{className:"primary",onClick:g,disabled:x(),children:"Next Step"}),n===3&&h.jsx(Wl,{className:"primary",onClick:g,disabled:x(),children:"Recommend Courses"})]})]})})};function A9(){return h.jsxs(Tv,{children:[h.jsx(k5,{}),h.jsx(CS,{children:h.jsx(eS,{children:h.jsxs(Da,{path:"/",element:h.jsx(bM,{}),children:[h.jsx(Da,{path:"",element:h.jsx(J6,{})}),h.jsx(Da,{path:"training-and-placements",element:h.jsx(ij,{})}),h.jsx(Da,{path:"about",element:h.jsx(n9,{})}),h.jsx(Da,{path:"recommendations",element:h.jsx(S9,{})})]})})})]})}l3.createRoot(document.getElementById("root")).render(h.jsx(E.StrictMode,{children:h.jsx(A9,{})}));
